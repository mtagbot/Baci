<?php
/** Durable text-notification transport. Private to each installation: NEVER add these tables
 * to DeskSync's generic snapshot/reconcile tables. Delivery is at-least-once; a provider
 * accepting a message immediately before a process/network failure can cause a retry. */
function bot_outbox_desktop() {
    static $desktop;
    if ($desktop === null) {
        $file=dirname(__DIR__).'/config/release.php';
        $cfg=is_file($file)?require $file:[];
        $desktop=($cfg['distribution']??'')==='desktop' || PHP_SAPI==='cli-server';
    }
    return $desktop;
}
function bot_outbox_schema() {
    static $ready=false;if($ready)return;
    $pdo=DB::getInstance()->getPdo();
    try {
        $pdo->query('SELECT job_id FROM bot_outbox LIMIT 0');
        $pdo->query('SELECT platform FROM bot_outbox_limits LIMIT 0');
        $ready=true;return;
    } catch(PDOException $missing) {
        // MySQL DDL implicitly commits: never migrate inside a business transaction.
        if($pdo->inTransaction())throw new RuntimeException('Initialize notification queue before opening a transaction');
    }
    $mysql=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql';
    $pdo->exec("CREATE TABLE IF NOT EXISTS bot_outbox (
        job_id VARCHAR(32) PRIMARY KEY, platform VARCHAR(16) NOT NULL,
        payload TEXT NOT NULL, payload_hash VARCHAR(64) NOT NULL,
        owner VARCHAR(8) NOT NULL, state VARCHAR(16) NOT NULL DEFAULT 'pending',
        attempts INTEGER NOT NULL DEFAULT 0, next_try BIGINT NOT NULL DEFAULT 0,
        lease_until BIGINT NOT NULL DEFAULT 0, claim_token VARCHAR(32) NOT NULL DEFAULT '',
        created_at BIGINT NOT NULL, sent_at BIGINT NOT NULL DEFAULT 0,
        message_id VARCHAR(80) NOT NULL DEFAULT '', last_error TEXT NOT NULL
        ".($mysql?", KEY bot_outbox_due (owner,state,next_try)":"").")".($mysql?' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4':''));
    if(!$mysql)$pdo->exec('CREATE INDEX IF NOT EXISTS bot_outbox_due ON bot_outbox(owner,state,next_try)');
    $pdo->exec("CREATE TABLE IF NOT EXISTS bot_outbox_limits (platform VARCHAR(16) PRIMARY KEY, next_try BIGINT NOT NULL DEFAULT 0)".($mysql?' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4':''));
    $ready=true;
}
function bot_outbox_sql($sql,$params=[]) {
    $st=DB::getInstance()->getPdo()->prepare($sql);$st->execute($params);return $st;
}
function bot_outbox_payload($platform,$payload) {
    if(!in_array($platform,['telegram','bale'],true)||!is_array($payload))throw new InvalidArgumentException('Invalid notification platform/payload');
    if(array_diff(array_keys($payload),['chat_id','text','reply_markup']))throw new InvalidArgumentException('Invalid notification fields');
    if(!isset($payload['chat_id'],$payload['text'])||!is_string($payload['chat_id'])||!is_string($payload['text'])||$payload['chat_id']===''||strlen($payload['chat_id'])>80||$payload['text']==='')throw new InvalidArgumentException('Invalid notification recipient/text');
    if(isset($payload['reply_markup'])&&!is_array($payload['reply_markup']))throw new InvalidArgumentException('Invalid keyboard');
    // Stable field order on both sides; reject oversize input rather than truncating a message.
    $p=['chat_id'=>$payload['chat_id'],'text'=>$payload['text']];if(isset($payload['reply_markup']))$p['reply_markup']=$payload['reply_markup'];
    $json=json_encode($p,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
    if(strlen($json)>60000)throw new InvalidArgumentException('Notification payload too large');
    return $json;
}
function bot_outbox_store($id,$platform,$payload,$owner='local') {
    if(!preg_match('/^[a-f0-9]{32}$/D',(string)$id)||!in_array($owner,['local','relay'],true))throw new InvalidArgumentException('Invalid notification identity');
    $json=bot_outbox_payload($platform,$payload);$hash=hash('sha256',$platform."\n".$json);
    bot_outbox_schema();
    try {
        bot_outbox_sql("INSERT INTO bot_outbox (job_id,platform,payload,payload_hash,owner,created_at,last_error) VALUES (?,?,?,?,?,?,?)",[$id,$platform,$json,$hash,$owner,time(),'']);
    } catch(PDOException $e) {
        // Only an IDENTICAL existing event is an acknowledgement. Never hide disk/SQL errors.
        $old=bot_outbox_sql('SELECT payload_hash,owner FROM bot_outbox WHERE job_id=?',[$id])->fetch(PDO::FETCH_ASSOC);
        if(!$old)throw $e;
        if(!hash_equals($old['payload_hash'],$hash)||$old['owner']!==$owner)throw new RuntimeException('Notification identity conflict');
    }
    return $id;
}
function bot_outbox_log_state($id,$state) {
    // Existing log table is optional; the outbox itself is the authoritative receipt.
    try { bot_outbox_sql('UPDATE bot_message_logs SET status=? WHERE response=?',[$state==='sent'?'sent':'queued','outbox:'.$id]); }catch(PDOException $e){}
}
function bot_outbox_enqueue($platform,$payload) {
    $owner='local';
    if(bot_outbox_desktop()) {
        require_once __DIR__.'/desk_sync.php';
        if(DeskSync::enabled())$owner='relay';
    }
    $id=bot_outbox_store(bin2hex(random_bytes(16)),$platform,$payload,$owner);
    /* v4.165.0: پیام تازه برای چتی که قبلاً مسدود شناخته شده، مستقیم با
       state='blocked' ثبت می‌شود — صفر تلاش بی‌نتیجه؛ با رفع مسدودی بیدار می‌شود.
       v4.171.0: در همان لحظه سقف صفِ آن چت اعمال می‌شود تا انباشت بی‌پایان
       پیش نیاید (فقط jobهای محلیِ پارک‌شده). */
    if($owner==='local' && bot_outbox_chat_is_blocked($platform,(string)($payload['chat_id']??''))) {
        bot_outbox_sql("UPDATE bot_outbox SET state='blocked' WHERE job_id=? AND state='pending'",[$id]);
        bot_outbox_prune_blocked_chat($platform,(string)($payload['chat_id']??''));
    }
    // Enqueue the ENTIRE recipient loop before any site network I/O. A single offline
    // recipient must never prevent later recipients from even entering the queue.
    static $scheduled=false;
    if(!bot_outbox_desktop()&&!$scheduled) {
        $scheduled=true;
        register_shutdown_function(function(){
            try {
                if(DB::getInstance()->getPdo()->inTransaction())return;
                if(session_status()===PHP_SESSION_ACTIVE)session_write_close();
                if(function_exists('fastcgi_finish_request'))fastcgi_finish_request();
                bot_outbox_drain(3,8);
            }catch(Throwable $e){error_log('Notification queue retained; worker will retry.');}
        });
    }
    $row=bot_outbox_sql('SELECT state FROM bot_outbox WHERE job_id=?',[$id])->fetch(PDO::FETCH_ASSOC);
    $GLOBALS['bot_outbox_last']=['id'=>$id,'platform'=>$platform,'chat_id'=>$payload['chat_id'],'state'=>$row['state']];
    return ['ok'=>true,'queued'=>true,'outbox_id'=>$id];
}
function bot_outbox_clean_error($e,$platform) {
    $message=$e->getMessage();$token=(string)get_setting(bot_token_key($platform),'');
    if($token!=='')$message=str_replace($token,'[redacted]',$message);
    return mb_substr($message,0,700,'UTF-8');
}
function bot_outbox_deliver($id) {
    bot_outbox_schema();$now=time();
    $row=bot_outbox_sql('SELECT * FROM bot_outbox WHERE job_id=?',[$id])->fetch(PDO::FETCH_ASSOC);
    if(!$row||$row['owner']!=='local')return null;
    $limit=bot_outbox_sql('SELECT next_try FROM bot_outbox_limits WHERE platform=?',[$row['platform']])->fetch(PDO::FETCH_ASSOC);
    if((int)($limit['next_try']??0)>$now)return null;
    $claim=bin2hex(random_bytes(16));
    $n=bot_outbox_sql("UPDATE bot_outbox SET state='sending',claim_token=?,lease_until=?,attempts=attempts+1 WHERE job_id=? AND owner='local' AND next_try<=? AND (state='pending' OR (state='sending' AND lease_until<?))",[$claim,$now+300,$id,$now,$now])->rowCount();
    if(!$n)return null;
    try {
        $payload=json_decode($row['payload'],true,512,JSON_THROW_ON_ERROR);
        $result=bot_api_request($row['platform'],'sendMessage',$payload,false);
        // Success must be explicit; an HTML page, malformed JSON or HTTP 200 error isn't delivery.
        if(!is_array($result)||($result['ok']??null)!==true)throw new RuntimeException('Bot did not confirm delivery');
        bot_outbox_sql("UPDATE bot_outbox SET state='sent',sent_at=?,lease_until=0,claim_token='',last_error='',message_id=? WHERE job_id=? AND claim_token=?",[time(),(string)($result['result']['message_id']??''),$id,$claim]);
        bot_outbox_log_state($id,'sent');return $result;
    } catch(Throwable $e) {
        /* v4.165.0: سه ۴۰۳ پشت‌سرهم یعنی کاربر ربات را مسدود کرده است. job از
           چرخهٔ تلاش خارج می‌شود (state='blocked') تا worker بی‌خودی API را
           نکوبد؛ پیام سالم می‌ماند و با اولین پیام کاربر پس از رفع مسدودی
           (bot_outbox_unblock_chat در وب‌هوک) خودکار به چرخه برمی‌گردد. */
        if($row['owner']==='local' && (int)$row['attempts']+1>=3 && preg_match('/HTTP 403\b/',$e->getMessage())) {
            bot_outbox_sql("UPDATE bot_outbox SET state='blocked',next_try=0,lease_until=0,claim_token='',last_error=? WHERE job_id=? AND claim_token=?", [bot_outbox_clean_error($e,$row['platform']),$id,$claim]);
            bot_outbox_log_state($id,'blocked');return null;
        }
        $retry=min(60,10*(2**min(3,(int)$row['attempts'])));
        if(preg_match('/HTTP (?:400|401|403)\b/',$e->getMessage()))$retry=min(3600,10*(2**min(9,(int)$row['attempts'])));
        $pausePlatform=(bool)preg_match('/خطای ارتباط|توکن ربات تنظیم نشده|HTTP (?:5\d\d|401)\b/u',$e->getMessage());
        if(preg_match('/"retry_after"\s*:\s*(\d+)/',$e->getMessage(),$m)) {
            $retry=max($retry,min(86400,(int)$m[1]));$pausePlatform=true;
        }
        if($pausePlatform) {
            try { bot_outbox_sql('INSERT INTO bot_outbox_limits (platform,next_try) VALUES (?,0)',[$row['platform']]); }catch(PDOException $duplicate){}
            bot_outbox_sql('UPDATE bot_outbox_limits SET next_try=CASE WHEN next_try>? THEN next_try ELSE ? END WHERE platform=?',[$now+$retry,$now+$retry,$row['platform']]);
        }
        bot_outbox_sql("UPDATE bot_outbox SET state='pending',next_try=?,lease_until=0,claim_token='',last_error=? WHERE job_id=? AND claim_token=?",[$now+$retry,bot_outbox_clean_error($e,$row['platform']),$id,$claim]);
        bot_outbox_log_state($id,'pending');return null;
    }
}
function bot_outbox_drain($limit=10,$seconds=20) {
    bot_outbox_schema();$start=microtime(true);$sent=0;$now=time();
    // Long-lived desktop workers must see token/relay corrections without restarting.
    unset($GLOBALS['__settings_cache_loaded'],$GLOBALS['__settings_cache']);
    $limit=max(1,min(100,(int)$limit));
    $rows=bot_outbox_sql("SELECT job_id FROM bot_outbox WHERE owner='local' AND next_try<=? AND (state='pending' OR (state='sending' AND lease_until<?)) AND NOT EXISTS (SELECT 1 FROM bot_outbox_limits l WHERE l.platform=bot_outbox.platform AND l.next_try>?) ORDER BY next_try,created_at,job_id LIMIT $limit",[$now,$now,$now])->fetchAll(PDO::FETCH_ASSOC);
    foreach($rows as $r) {
        if(microtime(true)-$start>=$seconds)break;
        if(bot_outbox_deliver($r['job_id']))$sent++;
    }
    return $sent;
}
/** Authenticated sync endpoint calls this only AFTER validating the installation key. */
function bot_outbox_accept($jobs) {
    if(!is_array($jobs)||count($jobs)>20)throw new InvalidArgumentException('Invalid notification batch');
    $ids=[];
    foreach($jobs as $j) {
        if(!is_array($j))throw new InvalidArgumentException('Invalid notification');
        $ids[]=bot_outbox_store($j['id']??'', $j['platform']??'', $j['payload']??null, 'local');
    }
    return $ids;
}
function bot_outbox_receipts($ids) {
    $result=[];
    foreach($ids as $id) {
        $r=bot_outbox_sql('SELECT job_id,state,last_error,message_id,sent_at,attempts FROM bot_outbox WHERE job_id=?',[$id])->fetch(PDO::FETCH_ASSOC);
        if($r)$result[]=$r;
    }
    return $result;
}
/** A response loss never changes IDs or causes a fallback to local sending. */
function bot_outbox_relay_jobs($limit=20) {
    bot_outbox_schema();$limit=max(1,min(20,(int)$limit));
    $rows=bot_outbox_sql("SELECT job_id,platform,payload FROM bot_outbox WHERE owner='relay' AND state IN ('pending','relayed') AND next_try<=? ORDER BY next_try,created_at,job_id LIMIT $limit",[time()])->fetchAll(PDO::FETCH_ASSOC);
    return array_map(function($r){return ['id'=>$r['job_id'],'platform'=>$r['platform'],'payload'=>json_decode($r['payload'],true)];},$rows);
}
function bot_outbox_apply_receipts($jobs,$receipts) {
    if(!is_array($receipts))throw new RuntimeException('Invalid notification acknowledgements');
    $expected=array_fill_keys(array_column($jobs,'id'),true);$seen=[];
    foreach($receipts as $r) {
        $id=$r['job_id']??'';
        if(!isset($expected[$id])||isset($seen[$id])||!in_array($r['state']??'', ['pending','sending','sent'],true))throw new RuntimeException('Invalid notification acknowledgement');
        $seen[$id]=true;
        $state=$r['state']==='sent'?'sent':'relayed';
        bot_outbox_sql("UPDATE bot_outbox SET state=?,next_try=?,sent_at=?,message_id=?,last_error=?,attempts=? WHERE job_id=? AND owner='relay' AND state<>'sent'",[$state,time()+30,(int)($r['sent_at']??0),mb_substr((string)($r['message_id']??''),0,80),mb_substr((string)($r['last_error']??''),0,700),max(0,(int)($r['attempts']??0)),$id]);
        bot_outbox_log_state($id,$state);
    }
    if(count($seen)!==count($expected))throw new RuntimeException('Incomplete notification acknowledgements');
}

/* v4.164.0: گزارش «چه کسی ربات را مسدود کرده؟» — چت‌هایی که پاسخ HTTP 403
   (permission_denied) گرفته‌اند از صف ارسال‌نشده بیرون کشیده می‌شوند و
   دانش‌آموزان متصلِ هر چت از جدول اتصال همان پلتفرم نشان داده می‌شوند.
   این تابع فقط گزارش می‌دهد؛ صف و وضعیت jobها را تغییر نمی‌دهد. */
function bot_outbox_blocked_chats($platform) {
    if (!in_array($platform, ['telegram', 'bale'], true)) return [];
    bot_outbox_schema();
    $rows = bot_outbox_sql("SELECT payload, attempts FROM bot_outbox WHERE platform=? AND state<>'sent' AND last_error LIKE '%HTTP 403%'", [$platform])->fetchAll(PDO::FETCH_ASSOC);
    $chats = [];
    foreach ($rows as $r) {
        $p = json_decode((string)$r['payload'], true);
        $chat = is_array($p) ? trim((string)($p['chat_id'] ?? '')) : '';
        if ($chat === '') continue;
        if (!isset($chats[$chat])) $chats[$chat] = ['chat_id' => $chat, 'jobs' => 0, 'attempts' => 0, 'students' => []];
        $chats[$chat]['jobs']++;
        $chats[$chat]['attempts'] = max($chats[$chat]['attempts'], (int)$r['attempts']);
    }
    if (!$chats) return [];
    /* همان قرارداد نام‌گذاری bot_user_table() — عمداً محلی نگه داشته شده تا این
       گزارش بدون بارگذاری کامل هلپرهای ربات هم کار کند. */
    $table   = $platform === 'telegram' ? 'telegram_bot_users' : 'bale_bot_users';
    $chatCol = $platform === 'telegram' ? 'telegram_chat_id' : 'bale_chat_id';
    $marks = implode(',', array_fill(0, count($chats), '?'));
    try {
        $srows = DB::fetchAll("SELECT b.`$chatCol` AS chat_id, s.first_name, s.last_name, s.class_name FROM `$table` b JOIN students s ON s.id=b.student_id WHERE b.`$chatCol` IN ($marks)", array_keys($chats));
    } catch (Throwable $e) { $srows = []; }
    foreach ($srows as $sr) {
        $chat = (string)$sr['chat_id'];
        if (!isset($chats[$chat])) continue;
        $name = trim((string)$sr['first_name'] . ' ' . (string)$sr['last_name']);
        $label = $name !== '' ? $name : 'بدون نام';
        if (trim((string)($sr['class_name'] ?? '')) !== '') $label .= ' — ' . trim((string)$sr['class_name']);
        if (!in_array($label, $chats[$chat]['students'], true)) $chats[$chat]['students'][] = $label;
    }
    $out = array_values($chats);
    usort($out, function ($a, $b) { return $b['attempts'] <=> $a['attempts']; });
    return $out;
}

/* v4.171.0: سقف‌های بهداشت صفِ چت‌های مسدود. دو عدد عمداً کوچک نگه داشته شده
   تا روی هاست ضعیف هم ارزان بماند:
     BOT_OUTBOX_WAKE_LIMIT  → با رفع مسدودی فقط N پیام *آخر* بیدار می‌شود؛
        چتی که ۲۰۰ پیام معوق داشته یک‌جا ۲۰۰ پیام نمی‌گیرد (جلوگیری از رگبار و
        مسدودی/ریپورت دوبارهٔ کاربر). بقیه پارک می‌مانند و با پیام بعدیِ همان
        کاربر یا اصلاح مسدودی، دوبارهٔ تازه‌ترین‌ها بیدار می‌شوند.
     BOT_OUTBOX_BLOCKED_CAP → صف پارک‌شدهٔ هر چت بیشتر از این نمی‌شود؛ قدیمی‌ترها
        حذف می‌شوند تا جدول صف برای یک چت مسدود قدیمی بی‌پایان رشد نکند. */
if(!defined('BOT_OUTBOX_WAKE_LIMIT'))define('BOT_OUTBOX_WAKE_LIMIT',10);
if(!defined('BOT_OUTBOX_BLOCKED_CAP'))define('BOT_OUTBOX_BLOCKED_CAP',50);

/* v4.171.0: پیشوند پایدار payload برای تطبیق chat_id — ترتیب کلیدها همیشه
   chat_id,text است (bot_outbox_payload) پس تطبیق prefix دقیق است. یک تعریف
   مشترک برای blocked/unblock/prune تا هر سه دقیقاً یک زبان حرف بزنند. */
function bot_outbox_chat_like($chatId) {
    return '{"chat_id":' . json_encode(trim((string)$chatId), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ',%';
}

/* v4.165.0: آیا این چت قبلاً مسدود شناخته شده؟ (یک job با state='blocked'
   برای همان chat_id کافی است). */
function bot_outbox_chat_is_blocked($platform, $chatId) {
    $chatId = trim((string)$chatId);
    if ($chatId === '' || !in_array($platform, ['telegram', 'bale'], true)) return false;
    try {
        $hit = bot_outbox_sql("SELECT job_id FROM bot_outbox WHERE platform=? AND owner='local' AND state='blocked' AND payload LIKE ? LIMIT 1", [$platform, bot_outbox_chat_like($chatId)])->fetch(PDO::FETCH_ASSOC);
        return (bool)$hit;
    } catch (Throwable $e) { return false; }
}

/* v4.171.0: سقف صف پارک‌شدهٔ یک چت — قدیمی‌ترها حذف می‌شوند تا جدول صف برای
   یک چت مسدود قدیمی بی‌سرانجام رشد نکند (ماجرای ۲۱۵ پیام معوق یک چت).
   فقط jobهای محلی و پارک‌شده؛ jobهای رله (دسکتاپ) و ارسال‌شده هرگز حذف
   یا تغییر نمی‌شوند. */
function bot_outbox_prune_blocked_chat($platform, $chatId, $cap = BOT_OUTBOX_BLOCKED_CAP) {
    $chatId = trim((string)$chatId);
    if ($chatId === '' || !in_array($platform, ['telegram', 'bale'], true)) return 0;
    bot_outbox_schema();
    $cap = max(1, (int)$cap);
    $like = bot_outbox_chat_like($chatId);
    try {
        $total = (int)bot_outbox_sql("SELECT COUNT(*) FROM bot_outbox WHERE platform=? AND owner='local' AND state='blocked' AND payload LIKE ?", [$platform, $like])->fetchColumn();
        if ($total <= $cap) return 0;
        // تازه‌ترین‌ها می‌مانند؛ انتخاب با job_id قطعی می‌شود تا created_at برابر
        // (ثانیه) نتیجه را نامعین نکند.
        $keep = bot_outbox_sql("SELECT job_id FROM bot_outbox WHERE platform=? AND owner='local' AND state='blocked' AND payload LIKE ? ORDER BY created_at DESC, job_id DESC LIMIT $cap", [$platform, $like])->fetchAll(PDO::FETCH_COLUMN);
        if (count($keep) >= $total) return 0;
        $marks = implode(',', array_fill(0, count($keep), '?'));
        $n = bot_outbox_sql("DELETE FROM bot_outbox WHERE platform=? AND owner='local' AND state='blocked' AND payload LIKE ? AND job_id NOT IN ($marks)", array_merge([$platform, $like], $keep))->rowCount();
        return (int)$n;
    } catch (Throwable $e) { return 0; }
}

/* v4.165.0: کاربر پس از رفع مسدودی پیامی می‌فرستد (شامل /start) ← پیام‌های
   پارک‌شدهٔ او بدون دخالت مدیر به چرخهٔ ارسال برمی‌گردند.
   v4.171.0: فقط BOT_OUTBOX_WAKE_LIMIT پیام آخر بیدار می‌شود تا رفع مسدودی
   به رگبار پیام تبدیل نشود؛ بقیه پارک می‌مانند.
   این تابع از وب‌هوک داخل try/catch جدا صدا زده می‌شود و هرگز نباید روی
   جریان اتصال اولیا اثر بگذارد. jobهای رله (دسکتاپ) دست‌نخورده می‌مانند. */
function bot_outbox_unblock_chat($platform, $chatId, $limit = BOT_OUTBOX_WAKE_LIMIT) {
    $chatId = trim((string)$chatId);
    if ($chatId === '' || !in_array($platform, ['telegram', 'bale'], true)) return 0;
    bot_outbox_schema();
    $limit = max(1, min(200, (int)$limit));
    $like = bot_outbox_chat_like($chatId);
    /* ابتدا تازه‌ترین‌ها انتخاب و بعد UPDATE با IN(...) می‌شود: UPDATE با
       زیرپرومانهٔ LIMIT روی MySQL و SQLite یکسان کار نمی‌کند. */
    try {
        $ids = bot_outbox_sql("SELECT job_id FROM bot_outbox WHERE platform=? AND owner='local' AND state='blocked' AND payload LIKE ? ORDER BY created_at DESC, job_id DESC LIMIT $limit", [$platform, $like])->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) { return 0; }
    if (!$ids) return 0;
    $marks = implode(',', array_fill(0, count($ids), '?'));
    $n = bot_outbox_sql("UPDATE bot_outbox SET state='pending',next_try=0,attempts=0,last_error='' WHERE platform=? AND owner='local' AND state='blocked' AND job_id IN ($marks)", array_merge([$platform], $ids))->rowCount();
    return (int)$n;
}
