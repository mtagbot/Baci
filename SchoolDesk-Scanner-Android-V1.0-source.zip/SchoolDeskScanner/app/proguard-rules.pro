# Keep ML Kit / CameraX public API
-keep class com.google.mlkit.** { *; }
-keep class androidx.camera.** { *; }
