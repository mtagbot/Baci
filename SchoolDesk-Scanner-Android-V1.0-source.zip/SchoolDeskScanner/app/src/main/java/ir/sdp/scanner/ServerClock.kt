package ir.sdp.scanner

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * ساعت همسان با سرور — به وقت تهران.
 *
 * مبدأ: هدر HTTP «Date» که هر پاسخ سرور دارد و همیشه به وقت GMT است. اختلاف آن با ساعت
 * دستگاه نگه داشته می‌شود، پس حتی اگر ساعت گوشی اشتباه یا تنظیم‌نشده باشد، زمانِ نمایش‌داده‌شده
 * همان زمانِ سرور است.
 *
 * منطقهٔ زمانی: تهران از سال ۱۴۰۱ ساعت تابستانی ندارد و ثابت روی ۳:۳۰+ است. استفاده از
 * «GMT+3:30» به‌جای «Asia/Tehran» عمدی است، چون پایگاه زمانیِ اندرویدهای قدیمی هنوز DST
 * ایران را اعمال می‌کند و ساعت را یک جلو می‌انداخت.
 */
object ServerClock {

    @Volatile private var offsetMs = 0L
    @Volatile private var synced = false

    private val httpDate = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", Locale.US)
        .apply { timeZone = TimeZone.getTimeZone("GMT") }

    /** زمان سرور را از هدر Date یک پاسخ HTTP می‌گیرد. */
    fun updateFromHeader(dateHeader: String?) {
        if (dateHeader.isNullOrEmpty()) return
        try {
            val d = httpDate.parse(dateHeader) ?: return
            offsetMs = d.time - System.currentTimeMillis()
            synced = true
        } catch (_: Exception) {}
    }

    fun isSynced(): Boolean = synced

    /** هم‌اکنون به وقت سرور (میلی‌ثانیه). */
    fun nowMs(): Long = System.currentTimeMillis() + offsetMs

    /** ساعت به شکل HH:mm:ss به وقت تهران. */
    fun timeString(): String {
        val f = SimpleDateFormat("HH:mm:ss", Locale.US)
        f.timeZone = TimeZone.getTimeZone("GMT+3:30")
        return f.format(Date(nowMs()))
    }
}
