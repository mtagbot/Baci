package ir.sdp.scanner

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * ارسال اسکن به سامانه از طریق API رسمی خودِ سایت:
 *     <site>/attendance-scan-api.php   با بدنهٔ JSON
 *     {"key":"<کلید اسکنر>","action":"scan","payload":"<متن خام QR>"}
 *
 * همان endpoint که اسکنر وب استفاده می‌کند؛ پس هیچ فایل اضافه‌ای روی سرور لازم نیست.
 * اگر آدرس سرور خالی باشد => حالت آفلاین: فقط کد تگ نمایش داده می‌شود.
 *
 * سرعت در صف: چند رشتهٔ موازی => اگر چند دانش‌آموز پشت‌سرهم اسکن شوند، درخواست‌ها
 * در صفِ هم نمی‌مانند و هم‌زمان ثبت می‌شوند. اسکن بعدی هم هرگز منتظر سرور نمی‌ماند.
 */
object CheckIn {
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    /** @param cb نام، وضعیت (حضور/تأخیر/تکراری)، پیام سرور */
    fun submit(ctx: Context, tag: String, cb: (String, String, String) -> Unit, err: (String) -> Unit = {}) {
        val base = AppPreferences.serverUrl(ctx).trim()
        if (base.isEmpty()) { cb(tag, "", ""); return }
        val key = AppPreferences.scannerKey(ctx).trim()
        pool.execute {
            val r = post(endpoint(base), key, tag)
            if (r == null) {
                main.post { cb(tag, "", ""); err("اتصال به سرور برقرار نشد") }
            } else {
                val (code, name, status, message) = r
                if (code == 200) main.post { cb(name.ifEmpty { tag }, status, message) }
                else main.post { cb(name.ifEmpty { tag }, status, message.ifEmpty { "پاسخ سرور: HTTP $code" }) }
            }
        }
    }

    private fun endpoint(base: String): String {
        val b = base.trim().trimEnd('/')
        return if (b.endsWith(".php", true)) b else "$b/attendance-scan-api.php"
    }

    /** @return (HTTP code, student, status, message) یا null اگر اتصال برقرار نشد. */
    private fun post(url: String, key: String, tag: String): Quadruple? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 3000
        c.readTimeout = 3000
        c.useCaches = false
        c.setRequestProperty("Content-Type", "application/json")
        val body = JSONObject()
            .put("key", key)
            .put("action", "scan")
            .put("payload", tag)
            .toString()
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val text = try {
            (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.readText() ?: ""
        } catch (_: Exception) { "" }
        c.disconnect()
        val j = try { JSONObject(text) } catch (_: Exception) { null }
        if (j == null) Quadruple(code, "", "", "") else Quadruple(
            code,
            j.optString("student", ""),
            j.optString("status", "").ifEmpty { j.optString("code", "") },
            j.optString("message", "")
        )
    } catch (e: Exception) { null }

    private data class Quadruple(val code: Int, val name: String, val status: String, val message: String)
}
