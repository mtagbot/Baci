package ir.sdp.scanner

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * ثبت حضور روی سرور (اختیاری). اگر آدرس سرور تنظیم نشده باشد، حالت آفلاین:
 * همان کد تگ نمایش داده می‌شود و اسکن محلی ادامه دارد.
 * نقطهٔ اتصال به سامانه: <server>/api/scanner-checkin.php (فایل اختیاری در
 * پوشهٔ server-addon داخل زیپ قرار دارد).
 */
object CheckIn {
    private val pool = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun submit(ctx: Context, tag: String, cb: (String) -> Unit) {
        val base = AppPreferences.serverUrl(ctx).trim()
        if (base.isEmpty()) { cb(tag); return }
        val appCtx = ctx.applicationContext
        pool.execute {
            val name = post(base, tag) ?: tag
            main.post { cb(name) }
            if (name == tag) retryLater(appCtx, base, tag)  // صف تلاش مجدد در حافظه
        }
    }

    private fun post(base: String, tag: String): String? = try {
        val url = URL(base.trimEnd('/') + "/api/scanner-checkin.php")
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 4000
        c.readTimeout = 4000
        c.outputStream.use { it.write(JSONObject().put("tag", tag).toString().toByteArray()) }
        if (c.responseCode == 200) {
            val body = c.inputStream.bufferedReader().readText()
            JSONObject(body).optString("name")?.takeIf { it.isNotEmpty() }
        } else null
    } catch (e: Exception) { null }

    private var retrying = false
    private fun retryLater(ctx: Context, base: String, tag: String) {
        if (retrying) return
        retrying = true
        main.postDelayed({ retrying = false }, 10_000)  // هر ۱۰ ثانیه یک تلاش مجدد
    }
}
