package ir.sdp.scanner

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.util.concurrent.Executors

/** پاسخ سرور. apiCode همان «code» در JSON سامانه است: present|late|duplicate|invalid|auth|error */
data class ScanReply(
    val http: Int,
    val apiCode: String,
    val name: String,
    val status: String,
    val message: String
)

/**
 * ارسال اسکن به API رسمی خودِ سایت:
 *     <site>/attendance-scan-api.php   با بدنهٔ JSON
 *     {"key":"<کلید اسکنر>","action":"scan","payload":"<متن خام QR>"}
 *
 * همان endpoint که اسکنر وب استفاده می‌کند؛ پس هیچ فایل اضافه‌ای روی سرور لازم نیست.
 */
object CheckIn {
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    /** @param cb پاسخ سرور؛ «null» یعنی درخواست اصلاً به سرور نرسید (خطای شبکه) */
    fun submit(ctx: Context, tag: String, cb: (ScanReply?) -> Unit, err: (String) -> Unit = {}) {
        val base = AppPreferences.serverUrl(ctx).trim()
        if (base.isEmpty()) { cb(ScanReply(0, "offline", tag, "", "")); return }
        val key = AppPreferences.scannerKey(ctx).trim()
        val url = endpoint(base)
        val insecure = AppPreferences.compatMode(ctx)
        pool.execute {
            var a = post(url, key, tag, insecure)
            if (a.first == null) a = post(url, key, tag, insecure)      // یک تلاش مجدد
            val reply = a.first
            if (reply == null) {
                val msg = a.second ?: "خطای شبکه"
                main.post { err(hint(msg)); cb(null) }
            } else {
                main.post { cb(reply) }
            }
        }
    }

    /**
     * آزمایش اتصال با action=status (چیزی ثبت نمی‌کند) — برای اینکه بدون اسکنِ واقعی
     * بفهمیم مشکل دقیقاً کجاست: گواهی، پروتکل، آدرس، یا کلید.
     */
    fun testConnection(ctx: Context, cb: (String) -> Unit) {
        val base = AppPreferences.serverUrl(ctx).trim()
        if (base.isEmpty()) { cb("آدرس سرور خالی است."); return }
        val key = AppPreferences.scannerKey(ctx).trim()
        val url = endpoint(base)
        val insecure = AppPreferences.compatMode(ctx)
        pool.execute {
            val out = try {
                val c = Net.open(url, insecure)
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use {
                    it.write(JSONObject().put("key", key).put("action", "status").toString().toByteArray())
                }
                val code = c.responseCode
                ServerClock.updateFromHeader(c.getHeaderField("Date"))   // همسان‌سازی ساعت با سرور
                val text = try {
                    (if (code in 200..299) c.inputStream else c.errorStream)
                        ?.bufferedReader()?.readText() ?: ""
                } catch (_: Exception) { "" }
                c.disconnect()
                val j = try { JSONObject(text) } catch (_: Exception) { null }
                when {
                    code !in 200..299 -> "سرور پاسخ داد ولی HTTP $code — ${text.take(120)}"
                    j == null -> "سرور پاسخ داد (HTTP 200) ولی JSON نبود — ${text.take(120)}"
                    j.optString("code", "") == "auth" -> "کلید اسکنر معتبر نیست (ارتباط برقرار است)."
                    j.optBoolean("ok", false) ->
                        "اتصال برقرار است ✅  حاضر: ${j.optInt("present")}  تأخیر: ${j.optInt("late")}  غیبت: ${j.optInt("absent")}"
                    else -> "پاسخ سرور: ${j.optString("message", text.take(120))}"
                }
            } catch (e: Exception) {
                hint("خطا: " + Net.describe(e))
            }
            main.post { cb(out) }
        }
    }

    /** اگر علت، گواهیِ تأییدنشده بود، راه‌حل را هم کنارِ پیام بگو. */
    private fun hint(msg: String): String =
        if (msg.contains("Trust anchor", true) || msg.contains("CertPath", true) ||
            msg.contains("certificate", true))
            msg + "  |  راه‌حل: «حالت سازگاری» را در اپ روشن کنید، یا از آدرس http:// استفاده کنید."
        else msg

    private fun endpoint(base: String): String {
        val b = base.trim().trimEnd('/')
        return if (b.endsWith(".php", true)) b else "$b/attendance-scan-api.php"
    }

    /** @return (پاسخ سرور یا null, متن خطای شبکه) */
    private fun post(url: String, key: String, tag: String, insecure: Boolean): Pair<ScanReply?, String?> {
        var conn: HttpURLConnection? = null
        return try {
            conn = Net.open(url, insecure)
            conn.requestMethod = "POST"
            conn.doOutput = true
            // تایم‌اوت بلندتر: گوشی قدیمی برای handshake کندتر است و نباید اسکن از دست برود
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.useCaches = false
            conn.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject()
                .put("key", key)
                .put("action", "scan")
                .put("payload", tag)
                .toString()
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            ServerClock.updateFromHeader(conn.getHeaderField("Date"))     // همسان‌سازی ساعت با سرور
            val text = try {
                (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.readText() ?: ""
            } catch (_: Exception) { "" }
            val j = try { JSONObject(text) } catch (_: Exception) { null }
            if (j == null) {
                Pair(ScanReply(code, "", "", "", "پاسخ نامعتبر از سرور (HTTP $code)"), null)
            } else {
                Pair(
                    ScanReply(
                        code,
                        j.optString("code", ""),
                        j.optString("student", ""),
                        j.optString("status", ""),
                        j.optString("message", "")
                    ), null
                )
            }
        } catch (e: Exception) {
            // زنجیرهٔ کامل علت‌ها: دقیقاً می‌گوید مشکل گواهی است یا پروتکل یا DNS
            Pair(null, Net.describe(e))
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }
}
