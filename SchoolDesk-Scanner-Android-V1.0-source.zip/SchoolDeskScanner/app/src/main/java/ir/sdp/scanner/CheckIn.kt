package ir.sdp.scanner

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.util.concurrent.Executors

/** پاسخ سرور. apiCode همان «code» در JSON سامانه است: present|late|duplicate|invalid|auth|error */
data class ScanReply(
    val http: Int,
    val apiCode: String,
    val name: String,
    val status: String,
    val message: String
)

/**
 * ارسال اسکن به API رسمی خودِ سایت:
 *     <site>/attendance-scan-api.php   با بدنهٔ JSON
 *     {"key":"<کلید اسکنر>","action":"scan","payload":"<متن خام QR>"}
 *
 * سازگاری با گوشی قدیمی: اگر خطا از نوع «گواهی» باشد (Trust anchor) — که فروشگاه گواهیِ
 * اندروید قدیمی ریشهٔ سایت را ندارد — اپ **به‌صورت خودکار یک‌بار بدون بررسی گواهی SSL**
 * تلاش می‌کند تا اسکن و ثبت حضور متوقف نشود. این همان رفتار «بدون SSL» است که برای
 * دستگاه قدیمی لازم است؛ برای بقیهٔ دستگاه‌ها بررسی گواهی سرِ جایش می‌ماند.
 */
object CheckIn {
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    /** @param cb پاسخ سرور؛ «null» یعنی درخواست اصلاً به سرور نرسید (خطای شبکه) */
    fun submit(ctx: Context, tag: String, cb: (ScanReply?) -> Unit, err: (String) -> Unit = {}) {
        val base = AppPreferences.serverUrl(ctx).trim()
        if (base.isEmpty()) { cb(ScanReply(0, "offline", tag, "", "")); return }
        val key = AppPreferences.scannerKey(ctx).trim()
        val url = endpoint(base)
        pool.execute {
            var insecure = AppPreferences.compatMode(ctx)
            var a = post(url, key, tag, insecure)
            if (a.first == null) {
                // خطای گواهیِ دستگاه قدیمی => خودکار بدون بررسی SSL تلاش کن
                if (!insecure && isCertError(a.second)) {
                    insecure = true
                    a = post(url, key, tag, true)
                } else {
                    a = post(url, key, tag, insecure)      // یک تلاش مجدد
                }
            }
            val reply = a.first
            if (reply == null) {
                val msg = a.second ?: "خطای شبکه"
                main.post { err(hint(msg)); cb(null) }
            } else {
                main.post { cb(reply) }
            }
        }
    }

    /**
     * آزمایش اتصال با action=status (چیزی ثبت نمی‌کند). اگر علت خطا، گواهی باشد،
     * به‌صورت خودکار «بدون بررسی SSL» هم آزمایش می‌کند و نتیجه را گزارش می‌دهد.
     */
    fun testConnection(ctx: Context, cb: (String) -> Unit) {
        val base = AppPreferences.serverUrl(ctx).trim()
        if (base.isEmpty()) { cb("آدرس سرور خالی است."); return }
        val key = AppPreferences.scannerKey(ctx).trim()
        val url = endpoint(base)
        pool.execute {
            var r = runTest(url, key, AppPreferences.compatMode(ctx))
            if (!r.ok && r.certError) {
                val bypass = runTest(url, key, true)
                if (bypass.ok) r = TestResult(true, false, bypass.text + "  (بدون بررسی گواهی SSL)")
            }
            main.post { cb(r.text) }
        }
    }

    private data class TestResult(val ok: Boolean, val certError: Boolean, val text: String)

    private fun runTest(url: String, key: String, insecure: Boolean): TestResult = try {
        val c = Net.open(url, insecure)
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 10000
        c.readTimeout = 10000
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use {
            it.write(JSONObject().put("key", key).put("action", "status").toString().toByteArray())
        }
        val code = c.responseCode
        ServerClock.updateFromHeader(c.getHeaderField("Date"))
        val text = try {
            (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.readText() ?: ""
        } catch (_: Exception) { "" }
        c.disconnect()
        val j = parseJsonLoose(text)
        when {
            code !in 200..299 -> TestResult(false, false, "سرور پاسخ داد ولی HTTP $code — ${text.take(120)}")
            j == null -> TestResult(false, false, "سرور پاسخ داد (HTTP 200) ولی JSON نبود — ${text.take(120)}")
            j.optString("code", "") == "auth" -> TestResult(true, false, "اتصال برقرار است ولی کلید اسکنر معتبر نیست.")
            j.optBoolean("ok", false) -> TestResult(true, false,
                "اتصال برقرار است ✅  حاضر: ${j.optInt("present")}  تأخیر: ${j.optInt("late")}  غیبت: ${j.optInt("absent")}")
            else -> TestResult(false, false, "پاسخ سرور: ${j.optString("message", text.take(120))}")
        }
    } catch (e: Exception) {
        val d = Net.describe(e)
        TestResult(false, isCertError(d), hint("خطا: " + d))
    }

    /**
     * پارس مقاومِ JSON: تفاوت رفتار اندروید قدیمی/جدید (BOM، فاصله، یا خروجی noticeٔ PHP
     * پیش از JSON) نباید پاسخ سرور را نامعتبر کند. ابتدا BOM و فاصله حذف می‌شود، سپس اگر
     * چیزی قبل/بعد از بدنهٔ JSON باشد، فقط بخشِ «{...}» جدا و پارس می‌شود.
     */
    private fun parseJsonLoose(text: String): JSONObject? {
        var t = text.trim()
        if (t.startsWith("\uFEFF")) t = t.substring(1).trim()
        if (t.isEmpty()) return null
        val first = t.indexOf('{'); val last = t.lastIndexOf('}')
        if (first >= 0 && last > first) {
            try { return JSONObject(t.substring(first, last + 1)) } catch (_: Exception) {}
        }
        return try { JSONObject(t) } catch (_: Exception) { null }
    }

    private fun isCertError(msg: String?): Boolean =
        msg != null && (msg.contains("Trust anchor", true) || msg.contains("CertPath", true) ||
            msg.contains("certificate", true) || msg.contains("SSLHandshake", true))

    /** اگر علت، گواهیِ تأییدنشده بود، راه‌حل را هم کنارِ پیام بگو. */
    private fun hint(msg: String): String =
        if (msg.contains("Trust anchor", true) || msg.contains("CertPath", true) ||
            msg.contains("certificate", true))
            msg + "  |  راه‌حل: «حالت سازگاری» را در اپ روشن کنید، یا از آدرس http:// استفاده کنید."
        else msg

    private fun endpoint(base: String): String {
        val b = base.trim().trimEnd('/')
        return if (b.endsWith(".php", true)) b else "$b/attendance-scan-api.php"
    }

    /** @return (پاسخ سرور یا null, متن خطای شبکه) */
    private fun post(url: String, key: String, tag: String, insecure: Boolean): Pair<ScanReply?, String?> {
        var conn: HttpURLConnection? = null
        return try {
            conn = Net.open(url, insecure)
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.useCaches = false
            conn.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject()
                .put("key", key)
                .put("action", "scan")
                .put("payload", tag)
                .toString()
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            ServerClock.updateFromHeader(conn.getHeaderField("Date"))
            val text = try {
                (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.readText() ?: ""
            } catch (_: Exception) { "" }
            val j = parseJsonLoose(text)
            if (j == null) {
                Pair(ScanReply(code, "", "", "", "پاسخ نامعتبر از سرور (HTTP $code) — ${text.take(120)}"), null)
            } else {
                Pair(
                    ScanReply(
                        code,
                        j.optString("code", ""),
                        j.optString("student", ""),
                        j.optString("status", ""),
                        j.optString("message", "")
                    ), null
                )
            }
        } catch (e: Exception) {
            Pair(null, Net.describe(e))
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }
}
