package ir.sdp.scanner

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.util.concurrent.Executors

/** پاسخ سرور. apiCode همان «code» در JSON سامانه است: present|late|duplicate|invalid|auth|error */
data class ScanReply(
    val http: Int,
    val apiCode: String,
    val name: String,
    val status: String,
    val message: String
)

/**
 * ارسال اسکن به API رسمی خودِ سایت:
 *     <site>/attendance-scan-api.php   با بدنهٔ JSON
 *     {"key":"<کلید اسکنر>","action":"scan","payload":"<متن خام QR>"}
 *
 * همان endpoint که اسکنر وب استفاده می‌کند؛ پس هیچ فایل اضافه‌ای روی سرور لازم نیست.
 *
 * سرعت در صف: چند رشتهٔ موازی => چند دانش‌آموز هم‌زمان ثبت می‌شوند و اسکن بعدی
 * هرگز منتظر سرور نمی‌ماند. در صورت خطای شبکه یک بار تلاش مجدد می‌شود (مثل نسخهٔ وب).
 */
object CheckIn {
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    /** @param cb پاسخ سرور؛ «null» یعنی درخواست اصلاً به سرور نرسید (خطای شبکه) */
    fun submit(ctx: Context, tag: String, cb: (ScanReply?) -> Unit, err: (String) -> Unit = {}) {
        val base = AppPreferences.serverUrl(ctx).trim()
        if (base.isEmpty()) { cb(ScanReply(0, "offline", tag, "", "")); return }
        val key = AppPreferences.scannerKey(ctx).trim()
        val url = endpoint(base)
        pool.execute {
            var a = post(url, key, tag)
            if (a.first == null) a = post(url, key, tag)          // یک تلاش مجدد
            val reply = a.first
            if (reply == null) {
                val msg = a.second ?: "خطای شبکه"
                main.post { err(msg); cb(null) }
            } else {
                main.post { cb(reply) }
            }
        }
    }

    private fun endpoint(base: String): String {
        val b = base.trim().trimEnd('/')
        return if (b.endsWith(".php", true)) b else "$b/attendance-scan-api.php"
    }

    /** @return (پاسخ سرور یا null, متن خطای شبکه) */
    private fun post(url: String, key: String, tag: String): Pair<ScanReply?, String?> {
        var conn: HttpURLConnection? = null
        return try {
            conn = Net.open(url)
            conn.requestMethod = "POST"
            conn.doOutput = true
            // تایم‌اوت بلندتر: گوشی قدیمی برای handshake کندتر است و نباید اسکن از دست برود
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.useCaches = false
            conn.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject()
                .put("key", key)
                .put("action", "scan")
                .put("payload", tag)
                .toString()
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            val text = try {
                (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.readText() ?: ""
            } catch (_: Exception) { "" }
            val j = try { JSONObject(text) } catch (_: Exception) { null }
            if (j == null) {
                Pair(ScanReply(code, "", "", "", "پاسخ نامعتبر از سرور (HTTP $code)"), null)
            } else {
                Pair(
                    ScanReply(
                        code,
                        j.optString("code", ""),
                        j.optString("student", ""),
                        j.optString("status", ""),
                        j.optString("message", "")
                    ), null
                )
            }
        } catch (e: Exception) {
            // نام استثنا دقیقاً می‌گوید مشکل کجاست (TLS، DNS، timeout، ...)
            Pair(null, "خطای شبکه: " + e.javaClass.simpleName)
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }
}
