package ir.sdp.scanner

import android.content.Context
import android.content.SharedPreferences

/** تنظیمات سادهٔ اسکنر — همهٔ کلیدهای بهینه‌سازی این‌جا متمرکزند. */
object AppPreferences {
    private const val NAME = "sdp_scanner_prefs"

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    /** بازهٔ نادیده‌گرفتن اسکن تکراریِ همان تگ (میلی‌ثانیه) — ضد تکرار و ضد مصرف بیهوده. */
    fun cooldownMs(ctx: Context): Long = prefs(ctx).getLong("cooldown_ms", 5000L)

    /** آدرس پایهٔ سرور مدرسه برای ثبت حضور و گرفتن نام (اختیاری؛ خالی = حالت آفلاین). */
    fun serverUrl(ctx: Context): String = prefs(ctx).getString("server_url", "") ?: ""
    fun setServerUrl(ctx: Context, url: String) = prefs(ctx).edit().putString("server_url", url).apply()

    fun soundOn(ctx: Context): Boolean = prefs(ctx).getBoolean("sound", true)
    fun vibrateOn(ctx: Context): Boolean = prefs(ctx).getBoolean("vibrate", true)
}
