package ir.sdp.scanner

import android.content.Context
import android.content.SharedPreferences

/** تنظیمات سادهٔ اسکنر — همهٔ کلیدهای بهینه‌سازی این‌جا متمرکزند. */
object AppPreferences {
    private const val NAME = "sdp_scanner_prefs"

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    /**
     * بازهٔ نادیده‌گرفتن اسکن تکراریِ «همان تگ» (میلی‌ثانیه).
     * فقط جلوی دوباره‌خوانی یک دانش‌آموز را می‌گیرد؛ دانش‌آموز بعدی هیچ تأخیری ندارد.
     */
    fun cooldownMs(ctx: Context): Long = prefs(ctx).getLong("cooldown_ms", 2000L)

    /** آدرس پایهٔ سایت مدرسه (اختیاری؛ خالی = حالت آفلاین، فقط نمایش کد). */
    fun serverUrl(ctx: Context): String = prefs(ctx).getString("server_url", "") ?: ""
    fun setServerUrl(ctx: Context, url: String) = prefs(ctx).edit().putString("server_url", url).apply()

    /** کلید اسکنر — همان کلیدی که در آدرس اسکنر وب با ?key=... می‌آید
     *  (تنظیم attendance_scanner_key در سایت). */
    fun scannerKey(ctx: Context): String = prefs(ctx).getString("scanner_key", "") ?: ""
    fun setScannerKey(ctx: Context, key: String) = prefs(ctx).edit().putString("scanner_key", key).apply()

    fun soundOn(ctx: Context): Boolean = prefs(ctx).getBoolean("sound", true)
    fun vibrateOn(ctx: Context): Boolean = prefs(ctx).getBoolean("vibrate", true)

    /** چراغ خودکار بر اساس نورسنجی فریم (روشن در نور کم، خاموش در نور زیاد). */
    fun autoTorch(ctx: Context): Boolean = prefs(ctx).getBoolean("auto_torch", true)

    /** مدت نمایش نام روی صفحهٔ بیدار/قفل (میلی‌ثانیه) — بعد از آن دوباره standby. */
    fun wakeMs(ctx: Context): Long = prefs(ctx).getLong("wake_ms", 4000L)
}
