package ir.sdp.scanner

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * پنجرهٔ شناور برای نمایش نام دانش‌آموز روی صفحهٔ قفل.
 *
 * چرا لازم است؟ از اندروید ۱۰ به بعد، شروع «فعالیت» از پس‌زمینه محدود شده و ممکن است
 * WakeActivity روی قفل بالا نیاید. این پنجره با دسترسی «نمایش روی سایر برنامه‌ها»
 * مستقل از آن محدودیت کار می‌کند و روی گوشی‌های قدیمی هم پشتیبانی می‌شود.
 */
object LockOverlay {
    private var view: View? = null
    private var wm: WindowManager? = null
    private val handler = Handler(Looper.getMainLooper())
    private var hideTask: Runnable? = null

    fun canDraw(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(ctx)

    fun show(ctx: Context, name: String, time: String, status: String) {
        handler.post {
            try {
                hide()
                val w = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val root = build(ctx, name, time, status)
                val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
                val p = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT)
                p.gravity = Gravity.CENTER
                w.addView(root, p)
                wm = w
                view = root
                val t = Runnable { hide() }
                hideTask = t
                handler.postDelayed(t, AppPreferences.wakeMs(ctx))
            } catch (_: Exception) {}
        }
    }

    fun hide() {
        hideTask?.let { handler.removeCallbacks(it) }
        hideTask = null
        try { view?.let { wm?.removeView(it) } } catch (_: Exception) {}
        view = null
    }

    private fun dp(ctx: Context, v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, ctx.resources.displayMetrics).toInt()

    private fun build(ctx: Context, name: String, time: String, status: String): View {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 24f), dp(ctx, 40f), dp(ctx, 24f), dp(ctx, 40f))
        }
        box.addView(TextView(ctx).apply {
            text = name
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 42f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        box.addView(TextView(ctx).apply {
            text = status.ifEmpty { ctx.getString(R.string.read_ok) }
            setTextColor(Color.parseColor("#35D07F"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 16f), 0, 0)
        })
        box.addView(TextView(ctx).apply {
            text = time
            setTextColor(Color.parseColor("#7C5CFF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 12f), 0, 0)
        })
        return box
    }
}
