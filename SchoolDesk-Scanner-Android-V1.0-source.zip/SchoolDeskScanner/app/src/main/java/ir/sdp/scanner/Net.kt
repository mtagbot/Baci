package ir.sdp.scanner

import android.os.Build
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.Socket
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * لایهٔ شبکهٔ سازگار با گوشی‌های قدیمی.
 *
 * چرا لازم است؟ روی اندروید ۵ و ۶، پروتکل TLS 1.2 به‌صورت پیش‌فرض در SSLSocket فعال نیست
 * و سایت‌های HTTPS (مخصوصاً با گواهی Let's Encrypt) با خطای handshake رد می‌شوند؛ در نتیجه
 * اسکن خوانده می‌شد ولی حضور ثبت نمی‌شد. این‌جا TLS 1.2 به‌صورت صریح فعال می‌شود.
 */
object Net {

    private val tls12: SSLSocketFactory? by lazy { buildTls12() }

    fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        if (c is HttpsURLConnection && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
            tls12?.let { c.sslSocketFactory = it }
        }
        return c
    }

    private fun buildTls12(): SSLSocketFactory? = try {
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, null, null)
        Tls12SocketFactory(ctx.socketFactory)
    } catch (e: Exception) {
        null
    }

    private class Tls12SocketFactory(private val d: SSLSocketFactory) : SSLSocketFactory() {
        private val wanted = arrayOf("TLSv1.2", "TLSv1.1", "TLSv1")

        override fun getDefaultCipherSuites(): Array<String> = d.defaultCipherSuites
        override fun getSupportedCipherSuites(): Array<String> = d.supportedCipherSuites

        override fun createSocket(s: Socket?, h: String, p: Int, ac: Boolean): Socket =
            patch(d.createSocket(s, h, p, ac))

        override fun createSocket(h: String, p: Int): Socket = patch(d.createSocket(h, p))

        override fun createSocket(h: String, p: Int, lh: InetAddress, lp: Int): Socket =
            patch(d.createSocket(h, p, lh, lp))

        override fun createSocket(h: InetAddress, p: Int): Socket = patch(d.createSocket(h, p))

        override fun createSocket(a: InetAddress, p: Int, la: InetAddress, lp: Int): Socket =
            patch(d.createSocket(a, p, la, lp))

        private fun patch(s: Socket): Socket {
            if (s is SSLSocket) {
                try {
                    val ok = s.supportedProtocols.filter { it in wanted }
                    if (ok.isNotEmpty()) s.enabledProtocols = ok.toTypedArray()
                } catch (_: Exception) {}
            }
            return s
        }
    }
}
