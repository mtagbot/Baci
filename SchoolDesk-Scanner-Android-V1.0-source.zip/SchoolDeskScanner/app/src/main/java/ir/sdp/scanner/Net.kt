package ir.sdp.scanner

import android.os.Build
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.Socket
import java.net.URL
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.X509TrustManager

/**
 * لایهٔ شبکهٔ سازگار با گوشی‌های قدیمی.
 *
 * مشکلِ اندروید ۵ و ۶ با HTTPS دو علت متفاوت دارد:
 *  ۱) پروتکل TLS 1.2 روی بعضی نسخه‌ها به‌صورت پیش‌فرض فعال نیست → این‌جا صریحاً فعال می‌شود.
 *  ۲) فروشگاه گواهیِ دستگاه قدیمی، ریشهٔ گواهی‌های جدید (مثل Let's Encrypt) را ندارد →
 *     خطای «Trust anchor for certification path not found». این با کدِ سمت اپ حل نمی‌شود؛
 *     برای همین «حالت سازگاری» گذاشته شده که بررسی گواهی را نادیده می‌گیرد (فقط با
 *     انتخاب کاربر، فقط برای دستگاه قدیمی روی شبکهٔ مدرسه).
 *
 * نکته: این کد روی اندروید زیر ۶٫۰ (API < 23) اعمال می‌شود؛ قبلاً فقط API < 22 بود و
 * اندروید ۵٫۱ را جا می‌انداخت.
 */
object Net {

    private val tls12: SSLSocketFactory? by lazy { buildTls(false)?.first }
    private val insecurePair: Pair<SSLSocketFactory, HostnameVerifier>? by lazy { buildTls(true) }

    fun open(url: String, insecure: Boolean): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        if (c is HttpsURLConnection) {
            if (insecure) {
                insecurePair?.let {
                    c.sslSocketFactory = it.first
                    c.hostnameVerifier = it.second
                }
            } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                tls12?.let { c.sslSocketFactory = it }
            }
        }
        return c
    }

    /** متن خطای خوانا با زنجیرهٔ علت‌ها — تا ریشهٔ مشکل از روی خودِ پیام پیدا شود. */
    fun describe(e: Throwable): String {
        val parts = ArrayList<String>()
        var t: Throwable? = e
        var n = 0
        while (t != null && n < 3) {
            val m = t.message?.trim()?.take(140)
            parts.add(t.javaClass.simpleName + if (m.isNullOrEmpty()) "" else ": " + m)
            t = t.cause
            n++
        }
        return parts.joinToString("  ←  ")
    }

    private fun buildTls(insecure: Boolean): Pair<SSLSocketFactory, HostnameVerifier>? = try {
        val ctx = SSLContext.getInstance("TLS")
        if (insecure) ctx.init(null, arrayOf<X509TrustManager>(TrustAll()), SecureRandom())
        else ctx.init(null, null, null)
        Pair(
            Tls12SocketFactory(ctx.socketFactory),
            if (insecure) HostnameVerifier { _, _ -> true }
            else HttpsURLConnection.getDefaultHostnameVerifier()
        )
    } catch (e: Exception) {
        null
    }

    private class TrustAll : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }

    private class Tls12SocketFactory(private val d: SSLSocketFactory) : SSLSocketFactory() {
        private val wanted = arrayOf("TLSv1.2", "TLSv1.1", "TLSv1")

        override fun getDefaultCipherSuites(): Array<String> = d.defaultCipherSuites
        override fun getSupportedCipherSuites(): Array<String> = d.supportedCipherSuites

        override fun createSocket(s: Socket?, h: String, p: Int, ac: Boolean): Socket =
            patch(d.createSocket(s, h, p, ac))

        override fun createSocket(h: String, p: Int): Socket = patch(d.createSocket(h, p))

        override fun createSocket(h: String, p: Int, lh: InetAddress, lp: Int): Socket =
            patch(d.createSocket(h, p, lh, lp))

        override fun createSocket(h: InetAddress, p: Int): Socket = patch(d.createSocket(h, p))

        override fun createSocket(a: InetAddress, p: Int, la: InetAddress, lp: Int): Socket =
            patch(d.createSocket(a, p, la, lp))

        private fun patch(s: Socket): Socket {
            if (s is SSLSocket) {
                try {
                    val ok = s.supportedProtocols.filter { it in wanted }
                    if (ok.isNotEmpty()) s.enabledProtocols = ok.toTypedArray()
                } catch (_: Exception) {}
            }
            return s
        }
    }
}
