package ir.sdp.scanner

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.camera.core.Camera
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

/**
 * سرویس اسکن: دوربین + ML Kit بدون پیش‌نمایش => نمایشگر می‌تواند خاموش (standby) بماند
 * در حالی که CPU با PARTIAL_WAKE_LOCK و دوربین در این سرویسِ foreground فعال‌اند.
 * به محض دیدنِ تگ، نمایشگر آنی روشن شده و نام نمایش داده می‌شود.
 */
class ScannerService : LifecycleService() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_TORCH = "torch"
        const val EVENT = "ir.sdp.scanner.EVENT"
        const val EXTRA_TYPE = "type"
        const val EXTRA_LAST = "last"
        private const val CHANNEL = "sdp_scan"
        private const val NOTIF = 1
        var running = false
    }

    private lateinit var wake: PowerManager.WakeLock
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val scanner = BarcodeScanning.getClient()
    private val cooldown = HashMap<String, Long>()
    private var lastLum = -1
    private var skip = 0
    private var torchOn = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sdp:scan")
        wake.acquire()                       // CPU روشن بماند حتی با صفحهٔ خاموش
        startForeground(NOTIF, buildNotif())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START -> startScan()
            ACTION_STOP -> { stopScan(); stopForeground(true); stopSelf() }
            ACTION_TORCH -> toggleTorch()
        }
        return START_STICKY
    }

    private fun startScan() {
        if (running) return
        running = true
        broadcast("running", null)
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            try {
                val provider = fut.get()
                cameraProvider = provider
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(android.util.Size(640, 480))   // رزولوشن کم = مصرف کم
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, analysis)
            } catch (e: Exception) {
                broadcast("error", e.message)
            }
        }, executor)
    }

    /** پردازش فریم با تنظیم تطبیقی: وقتی حرکت کم است، فقط هر چند فریم یک‌بار decode کن. */
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null) { proxy.close(); return }
        val lum = meanLuma(media)
        val delta = if (lastLum < 0) 999 else Math.abs(lum - lastLum)
        lastLum = lum
        if (delta < 2) { skip++; if (skip % 3 != 0) { proxy.close(); return } } else skip = 0

        val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        scanner.process(image)
            .addOnSuccessListener { codes ->
                if (codes.isNotEmpty()) onCode(codes[0].rawValue ?: (codes[0].displayValue ?: ""))
            }
            .addOnCompleteListener { proxy.close() }
    }

    private fun meanLuma(img: android.media.Image): Int {
        val buf = img.planes[0].buffer
        val step = Math.max(1, buf.remaining() / 64)
        var sum = 0L; var n = 0; var i = 0
        while (i < buf.remaining()) { sum += (buf.get(i).toInt() and 0xFF); n++; i += step }
        return if (n > 0) (sum / n).toInt() else 0
    }

    private fun onCode(tag: String) {
        if (tag.isEmpty()) return
        val now = System.currentTimeMillis()
        if (now - (cooldown[tag] ?: 0L) < AppPreferences.cooldownMs(this)) return  // ضد تکرار
        cooldown[tag] = now
        feedback()
        CheckIn.submit(this, tag) { name ->
            broadcast("scan", name)
            wakeScreen(name)
        }
    }

    private fun feedback() {
        if (AppPreferences.vibrateOn(this)) vibrate()
        if (AppPreferences.soundOn(this)) beep()
    }

    /** روشن‌کردنِ آنیِ نمایشگر + نمایش نام؛ بعد از چند ثانیه خودش به standby برمی‌گردد. */
    private fun wakeScreen(name: String) {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        val wl = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "sdp:wake")
        wl.acquire(WakeActivity.SHOW_MS + 500)
        startActivity(Intent(this, WakeActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(WakeActivity.EXTRA_NAME, name))
    }

    private fun toggleTorch() {
        torchOn = !torchOn
        camera?.cameraControl?.enableTorch(torchOn)
    }

    private fun stopScan() {
        running = false
        cameraProvider?.unbindAll()
        broadcast("idle", null)
    }

    override fun onDestroy() {
        if (wake.isHeld) wake.release()
        scanner.close()
        super.onDestroy()
    }

    private fun broadcast(type: String, last: String?) =
        sendBroadcast(Intent(EVENT).putExtra(EXTRA_TYPE, type).putExtra(EXTRA_LAST, last))

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.notif_title),
                    NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotif(): Notification {
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    private fun vibrate() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                (getSystemService(VibratorManager::class.java)).defaultVibrator
            else @Suppress("DEPRECATION") (getSystemService(VIBRATOR_SERVICE) as Vibrator)
            v.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    private fun beep() {
        try {
            val t = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
            t.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            Handler(Looper.getMainLooper()).postDelayed({ t.release() }, 300)
        } catch (_: Exception) {}
    }
}
