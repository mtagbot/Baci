package ir.sdp.scanner

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.camera.core.Camera
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

/**
 * سرویس اسکن: دوربین + ML Kit بدون پیش‌نمایش => نمایشگر می‌تواند خاموش (standby) بماند
 * در حالی که CPU با PARTIAL_WAKE_LOCK و دوربین در این سرویسِ foreground فعال‌اند.
 * به محض دیدنِ تگ، نمایشگر آنی روشن شده و نام نمایش داده می‌شود.
 *
 * نکتهٔ مهم: bindToLifecycle باید روی ترد اصلی اجرا شود (الزام CameraX).
 */
class ScannerService : LifecycleService() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_TORCH = "torch"
        const val EVENT = "ir.sdp.scanner.EVENT"
        const val EXTRA_TYPE = "type"
        const val EXTRA_LAST = "last"
        private const val CHANNEL = "sdp_scan"
        private const val NOTIF = 1
        @Volatile var running = false
        @Volatile var cameraReady = false
        @Volatile var lastError: String? = null
    }

    private var wake: PowerManager.WakeLock? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val scanner = BarcodeScanning.getClient()
    private val cooldown = HashMap<String, Long>()
    private var lastLum = -1
    private var skip = 0
    private var torchOn = false
    private var foregrounded = false

    override fun onCreate() {
        super.onCreate()
        createChannel()

        // Android 14: سرویس foreground با نوع camera بدون دسترسی دوربین => SecurityException
        if (!hasCameraPermission()) {
            lastError = "دسترسی دوربین داده نشده است"
            startForegroundSafe()
            broadcast("error", lastError)
            stopSelf()
            return
        }

        startForegroundSafe()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sdp:scan").also { it.acquire() }
    }

    private fun startForegroundSafe() {
        if (foregrounded) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        try {
            ServiceCompat.startForeground(this, NOTIF, buildNotif(), type)
            foregrounded = true
        } catch (e: Exception) {
            lastError = "سرویس پیش‌زمینه شروع نشد: " + e.javaClass.simpleName
            broadcast("error", lastError)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START -> startScan()
            ACTION_STOP -> { stopScan(); if (foregrounded) stopForeground(true); stopSelf() }
            ACTION_TORCH -> toggleTorch()
            else -> broadcast(if (running) "running" else "idle", null)
        }
        return START_STICKY
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun startScan() {
        if (!hasCameraPermission()) { broadcast("error", "دسترسی دوربین داده نشده است"); return }
        if (running && cameraReady) { broadcast("running", null); return }
        running = true
        lastError = null
        broadcast("running", null)
        startForegroundSafe()

        val fut = ProcessCameraProvider.getInstance(this)
        // CameraX: bindToLifecycle باید روی ترد اصلی باشد؛ پس شنونده روی main executor ثبت می‌شود.
        fut.addListener({
            try {
                val provider = fut.get()
                cameraProvider = provider
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(android.util.Size(640, 480))   // رزولوشن کم = مصرف کم
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, analysis)
                cameraReady = true
                torchOn = false
                broadcast("ready", null)
            } catch (e: Exception) {
                cameraReady = false
                running = false
                lastError = "دوربین شروع نشد: " + (e.message ?: e.javaClass.simpleName)
                broadcast("error", lastError)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /** پردازش فریم با تنظیم تطبیقی: وقتی حرکت کم است، فقط هر چند فریم یک‌بار decode کن. */
    private fun analyze(proxy: ImageProxy) {
        try {
            val media = proxy.image
            if (media == null) { proxy.close(); return }
            val lum = meanLuma(media)
            val delta = if (lastLum < 0) 999 else Math.abs(lum - lastLum)
            lastLum = lum
            if (delta < 2) { skip++; if (skip % 3 != 0) { proxy.close(); return } } else skip = 0

            val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
            scanner.process(image)
                .addOnSuccessListener { codes ->
                    if (codes.isNotEmpty()) onCode(codes[0].rawValue ?: (codes[0].displayValue ?: ""))
                }
                .addOnCompleteListener { proxy.close() }
        } catch (e: Exception) {
            try { proxy.close() } catch (_: Exception) {}
        }
    }

    private fun meanLuma(img: android.media.Image): Int {
        val buf = img.planes[0].buffer
        val size = buf.remaining()
        if (size <= 0) return 0
        val step = Math.max(1, size / 64)
        var sum = 0L; var n = 0; var i = 0
        while (i < size) { sum += (buf.get(i).toInt() and 0xFF); n++; i += step }
        return if (n > 0) (sum / n).toInt() else 0
    }

    private fun onCode(tag: String) {
        if (tag.isEmpty()) return
        val now = System.currentTimeMillis()
        if (now - (cooldown[tag] ?: 0L) < AppPreferences.cooldownMs(this)) return  // ضد تکرار
        cooldown[tag] = now
        feedback()
        CheckIn.submit(this, tag, { name, st, _ ->
            val show = if (st.isNotEmpty()) "$name — $st" else name
            broadcast("scan", show)
            wakeScreen(show)
        }, { err -> broadcast("error", err) })
    }

    private fun feedback() {
        if (AppPreferences.vibrateOn(this)) vibrate()
        if (AppPreferences.soundOn(this)) beep()
    }

    /** روشن‌کردنِ آنیِ نمایشگر + نمایش نام؛ بعد از چند ثانیه خودش به standby برمی‌گردد. */
    private fun wakeScreen(name: String) {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        val wl = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "sdp:wake")
        wl.acquire(WakeActivity.SHOW_MS + 500)
        try {
            startActivity(Intent(this, WakeActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(WakeActivity.EXTRA_NAME, name))
        } catch (_: Exception) {}
    }

    private fun toggleTorch() {
        val cam = camera
        if (cam == null || !cameraReady) {
            broadcast("error", "چراغ فعال نیست — ابتدا «شروع اسکن» را بزنید")
            return
        }
        torchOn = !torchOn
        try { cam.cameraControl.enableTorch(torchOn) } catch (_: Exception) {}
        broadcast("torch", if (torchOn) "on" else "off")
    }

    private fun stopScan() {
        running = false
        cameraReady = false
        torchOn = false
        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        camera = null
        broadcast("idle", null)
    }

    override fun onDestroy() {
        running = false
        cameraReady = false
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) {}
        try { scanner.close() } catch (_: Exception) {}
        executor.shutdown()
        super.onDestroy()
    }

    /** ارسال رویداد به رابط کاربری؛ بسته به پکیج تا در اندروید ۱۴ با RECEIVER_NOT_EXPORTED reliably برسد. */
    private fun broadcast(type: String, last: String?) {
        try {
            sendBroadcast(Intent(EVENT).setPackage(packageName)
                .putExtra(EXTRA_TYPE, type).putExtra(EXTRA_LAST, last))
        } catch (_: Exception) {}
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.notif_title),
                    NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotif(): Notification {
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    private fun vibrate() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                (getSystemService(VibratorManager::class.java)).defaultVibrator
            else @Suppress("DEPRECATION") (getSystemService(VIBRATOR_SERVICE) as Vibrator)
            v.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    private fun beep() {
        try {
            val t = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
            t.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            Handler(Looper.getMainLooper()).postDelayed({ t.release() }, 300)
        } catch (_: Exception) {}
    }
}
