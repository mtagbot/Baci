package ir.sdp.scanner

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Size
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mlkit.vision.barcode.Barcode
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * سرویس اسکن: دوربین + ML Kit بدون پیش‌نمایش => نمایشگر می‌تواند خاموش (standby) بماند
 * در حالی که CPU با PARTIAL_WAKE_LOCK و دوربین در این سرویسِ foreground فعال‌اند.
 *
 * طراحی برای سرعت در صف شلوغ:
 *  - فقط QR رمزگشایی می‌شود (نه همهٔ فرمت‌ها) => چند برابر سریع‌تر
 *  - هر فریم پردازش می‌شود (بدون ردکردن فریم)
 *  - cooldown فقط برای «همان تگ» است، پس دانش‌آموز بعدی هرگز معطل نمی‌شود
 *  - بازخورد (بوق/لرزش) بلافاصله پس از رمزگشایی، بدون انتظار برای پاسخ سرور
 *  - ارسال به سرور موازی (چند رشته) تا چند دانش‌آموز هم‌زمان ثبت شوند
 * طراحی برای شرایط محیطی:
 *  - نورسنجی روی فریم => چراغ خودکار در نور کم، خاموش در نور زیاد
 *  - فوکوس/نورسنجی فعال مرکزِ تصویر، هم دوره‌ای و هم هنگام تغییر صحنه (فاصله‌های مختلف)
 *  - رزولوشن بالا برای فاصلهٔ بیشتر، با زنجیرهٔ fallback برای گوشی‌های قدیمی
 */
class ScannerService : LifecycleService() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_TORCH = "torch"
        const val EVENT = "ir.sdp.scanner.EVENT"
        const val EXTRA_TYPE = "type"
        const val EXTRA_LAST = "last"
        private const val CHANNEL = "sdp_scan"
        private const val CHANNEL_SCAN = "sdp_scan_result"
        private const val NOTIF = 1
        private const val NOTIF_SCAN = 2
        @Volatile var running = false
        @Volatile var cameraReady = false
        @Volatile var lastError: String? = null
    }

    private var wake: PowerManager.WakeLock? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private val executor = Executors.newSingleThreadExecutor()

    /** فقط QR — سامانهٔ ما QR می‌زند و این کار رمزگشایی را بسیار سریع‌تر می‌کند. */
    private val scanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())

    private val cooldown = HashMap<String, Long>()
    private var lastLum = -1
    private var lastFocusAt = 0L
    private var torchOn = false
    private var manualTorch = false
    private var foregrounded = false

    /** تلاش به ترتیب: ۷۲۰p (دقت در فاصله) ← ۴۸۰p ← پیش‌فرض دستگاه (سازگاری با گوشی قدیمی) */
    private val resAttempts: List<Size?> = listOf(Size(1280, 720), Size(640, 480), null)

    override fun onCreate() {
        super.onCreate()
        createChannels()

        // Android 14: سرویس foreground با نوع camera بدون دسترسی دوربین => SecurityException
        if (!hasCameraPermission()) {
            lastError = "دسترسی دوربین داده نشده است"
            startForegroundSafe()
            broadcast("error", lastError)
            stopSelf()
            return
        }

        startForegroundSafe()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sdp:scan").also { it.acquire() }
    }

    private fun startForegroundSafe() {
        if (foregrounded) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        try {
            ServiceCompat.startForeground(this, NOTIF, buildNotif(), type)
            foregrounded = true
        } catch (e: Exception) {
            lastError = "سرویس پیش‌زمینه شروع نشد: " + e.javaClass.simpleName
            broadcast("error", lastError)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START -> startScan()
            ACTION_STOP -> { stopScan(); if (foregrounded) stopForeground(true); stopSelf() }
            ACTION_TORCH -> toggleTorch()
            else -> broadcast(if (running) "running" else "idle", null)
        }
        return START_STICKY
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun startScan() {
        if (!hasCameraPermission()) { broadcast("error", "دسترسی دوربین داده نشده است"); return }
        if (running && cameraReady) { broadcast("running", null); return }
        running = true
        lastError = null
        broadcast("running", null)
        startForegroundSafe()

        val fut = ProcessCameraProvider.getInstance(this)
        // CameraX: bindToLifecycle باید روی ترد اصلی باشد.
        fut.addListener({
            try {
                val provider = fut.get()
                cameraProvider = provider
                bindAttempt(provider, 0)
            } catch (e: Exception) {
                failStart("دوربین شروع نشد: " + (e.message ?: e.javaClass.simpleName))
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /** زنجیرهٔ سازگاری: اگر رزولوشن بالا روی گوشی قدیمی پشتیبانی نشد، پله‌پله پایین‌تر می‌آییم. */
    private fun bindAttempt(provider: ProcessCameraProvider, idx: Int) {
        try {
            val builder = ImageAnalysis.Builder()
            resAttempts[idx]?.let { sz ->
                builder.setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setResolutionStrategy(ResolutionStrategy(
                            sz, ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
                        .build())
            }
            val analysis = builder
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, analysis)
            cameraReady = true
            torchOn = false
            manualTorch = false
            lastLum = -1
            lastFocusAt = 0L
            broadcast("ready", null)
        } catch (e: Exception) {
            if (idx + 1 < resAttempts.size) bindAttempt(provider, idx + 1)
            else failStart("دوربین شروع نشد: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    private fun failStart(msg: String) {
        cameraReady = false
        running = false
        lastError = msg
        broadcast("error", msg)
    }

    /** هر فریم پردازش می‌شود؛ هیچ فریمی رد نمی‌شود تا تگ در سریع‌ترین حالت دیده شود. */
    private fun analyze(proxy: ImageProxy) {
        try {
            val media = proxy.image
            if (media == null) { proxy.close(); return }
            val lum = meanLuma(media)
            applyAutoTorch(lum)     // نورسنجی => چراغ خودکار
            maybeRefocus(lum)       // فوکوس فعال برای فاصله‌های مختلف
            val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
            scanner.process(image)
                .addOnSuccessListener { codes ->
                    if (codes.isNotEmpty()) onCode(codes[0].rawValue ?: (codes[0].displayValue ?: ""))
                }
                .addOnCompleteListener { proxy.close() }
        } catch (e: Exception) {
            try { proxy.close() } catch (_: Exception) {}
        }
    }

    private fun meanLuma(img: android.media.Image): Int {
        val buf = img.planes[0].buffer
        val size = buf.remaining()
        if (size <= 0) return 0
        val step = Math.max(1, size / 64)
        var sum = 0L; var n = 0; var i = 0
        while (i < size) { sum += (buf.get(i).toInt() and 0xFF); n++; i += step }
        return if (n > 0) (sum / n).toInt() else 0
    }

    /** نورسنجی: در نور کم چراغ را روشن و در نور زیاد خاموش می‌کند (مگر کاربر دستی زده باشد). */
    private fun applyAutoTorch(lum: Int) {
        if (manualTorch || !AppPreferences.autoTorch(this)) return
        val cam = camera ?: return
        try {
            if (cam.cameraInfo.hasFlashUnit().value != true) return
            if (lum < 70 && !torchOn) { torchOn = true; cam.cameraControl.enableTorch(true) }
            else if (lum > 170 && torchOn) { torchOn = false; cam.cameraControl.enableTorch(false) }
        } catch (_: Exception) {}
    }

    /**
     * فوکوس/نورسنجی فعال: هم هر ۱٫۵ ثانیه و هم بلافاصله وقتی صحنه عوض می‌شود
     * (یعنی تگ جدیدی جلوی دوربین آمده یا فاصله تغییر کرده) تا دوربین شکارِ فوکوس کند.
     */
    private fun maybeRefocus(lum: Int) {
        val now = System.currentTimeMillis()
        val bigChange = lastLum >= 0 && Math.abs(lum - lastLum) > 12
        if (now - lastFocusAt < 250) { lastLum = lum; return }
        if (!bigChange && now - lastFocusAt < 1500) { lastLum = lum; return }
        lastFocusAt = now
        lastLum = lum
        val cam = camera ?: return
        try {
            val point = SurfaceOrientedMeteringPointFactory(1f, 1f).createPoint(0.5f, 0.5f)
            val action = FocusMeteringAction.Builder(
                    point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(1, TimeUnit.SECONDS)
                .build()
            cam.cameraControl.startFocusAndMetering(action)
        } catch (_: Exception) {}
    }

    private fun onCode(tag: String) {
        if (tag.isEmpty()) return
        val now = System.currentTimeMillis()
        // ضد تکرار فقط برای همان تگ؛ دانش‌آموز بعدی بدون هیچ تأخیری اسکن می‌شود.
        if (now - (cooldown[tag] ?: 0L) < AppPreferences.cooldownMs(this)) return
        cooldown[tag] = now
        feedback()                                   // فوری، بدون انتظار برای سرور
        CheckIn.submit(this, tag, { name, st, _ ->
            val show = if (st.isNotEmpty()) "$name — $st" else name
            broadcast("scan", show)
            wakeScreen(name, st)
        }, { err -> broadcast("error", err) })
    }

    private fun feedback() {
        if (AppPreferences.vibrateOn(this)) vibrate()
        if (AppPreferences.soundOn(this)) beep()
    }

    /**
     * نمایش نام روی صفحهٔ خاموش/قفل — سه لایهٔ پشتیبان، چون اندروید ۱۰+ شروع فعالیت از
     * پس‌زمینه را محدود کرده است:
     *   ۱) اعلان تمام‌صفحه (مطمئن‌ترین راه روی قفل)
     *   ۲) پنجرهٔ شناور (اگر دسترسی «نمایش روی سایر برنامه‌ها» داده شده باشد)
     *   ۳) فعالیت WakeActivity
     */
    private fun wakeScreen(name: String, status: String) {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        val wl = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "sdp:wake")
        try { wl.acquire(AppPreferences.wakeMs(this) + 1000) } catch (_: Exception) {}

        showScanNotification(name, status)
        if (LockOverlay.canDraw(this)) LockOverlay.show(this, name, status)
        try {
            startActivity(Intent(this, WakeActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(WakeActivity.EXTRA_NAME, name)
                .putExtra(WakeActivity.EXTRA_STATUS, status))
        } catch (_: Exception) {}
    }

    private fun toggleTorch() {
        val cam = camera
        if (cam == null || !cameraReady) {
            broadcast("error", "چراغ فعال نیست — ابتدا «شروع اسکن» را بزنید")
            return
        }
        manualTorch = true          // از این پس نورسنجی خودکار دخالت نمی‌کند
        torchOn = !torchOn
        try { cam.cameraControl.enableTorch(torchOn) } catch (_: Exception) {}
        broadcast("torch", if (torchOn) "on" else "off")
    }

    private fun stopScan() {
        running = false
        cameraReady = false
        torchOn = false
        manualTorch = false
        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        camera = null
        LockOverlay.hide()
        broadcast("idle", null)
    }

    override fun onDestroy() {
        running = false
        cameraReady = false
        LockOverlay.hide()
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) {}
        try { scanner.close() } catch (_: Exception) {}
        executor.shutdown()
        super.onDestroy()
    }

    /** ارسال رویداد به رابط کاربری؛ بسته به پکیج تا در اندروید ۱۴ مطمئن برسد. */
    private fun broadcast(type: String, last: String?) {
        try {
            sendBroadcast(Intent(EVENT).setPackage(packageName)
                .putExtra(EXTRA_TYPE, type).putExtra(EXTRA_LAST, last))
        } catch (_: Exception) {}
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(
                CHANNEL, getString(R.string.notif_title), NotificationManager.IMPORTANCE_LOW))
            // اهمیت بالا => اعلان تمام‌صفحه روی صفحهٔ قفل نشان داده می‌شود
            nm.createNotificationChannel(NotificationChannel(
                CHANNEL_SCAN, getString(R.string.scan_channel), NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun buildNotif(): Notification {
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    /** اعلان تمام‌صفحه: روی صفحهٔ قفل به‌صورت یک صفحهٔ کامل با نام دانش‌آموز باز می‌شود. */
    private fun showScanNotification(name: String, status: String) {
        try {
            val full = PendingIntent.getActivity(this, 1,
                Intent(this, WakeActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(WakeActivity.EXTRA_NAME, name)
                    .putExtra(WakeActivity.EXTRA_STATUS, status),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(this, CHANNEL_SCAN)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(name)
                .setContentText(status.ifEmpty { getString(R.string.scanned) })
                .setStyle(NotificationCompat.BigTextStyle()
                    .bigText(status.ifEmpty { getString(R.string.scanned) }))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setFullScreenIntent(full, true)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(this).notify(NOTIF_SCAN, n)
        } catch (_: Exception) {}
    }

    private fun vibrate() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                (getSystemService(VibratorManager::class.java)).defaultVibrator
            else @Suppress("DEPRECATION") (getSystemService(VIBRATOR_SERVICE) as Vibrator)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                v.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") v.vibrate(120)
        } catch (_: Exception) {}
    }

    private fun beep() {
        try {
            val t = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
            t.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            Handler(Looper.getMainLooper()).postDelayed({ t.release() }, 300)
        } catch (_: Exception) {}
    }
}
