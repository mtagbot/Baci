package ir.sdp.scanner

import android.content.Context
import android.media.MediaPlayer
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * پخش صدای گفتار بعد از بوق — دقیقاً مثل نسخهٔ وب:
 *   حضور به موقع → hzr.ogg      تأخیر → tkhr.ogg      خطای شبکه → net.ogg
 *
 * صداها پشت‌سرهم در یک صف پخش می‌شوند تا وقتی چند دانش‌آموز پشت‌سرهم اسکن می‌کنند
 * صداها روی هم نیفتند و ناخوانا نشوند.
 */
object Voice {
    private val queue = ConcurrentLinkedQueue<Int>()
    private var player: MediaPlayer? = null
    private var playing = false

    fun play(ctx: Context, rawRes: Int) {
        if (queue.size > 4) return          // اگر صف شلوغ است، صدای جدید را نریز
        queue.add(rawRes)
        next(ctx.applicationContext)
    }

    @Synchronized
    private fun next(ctx: Context) {
        if (playing) return
        val res = queue.poll() ?: return
        try {
            release()
            val mp = MediaPlayer.create(ctx, res)
            if (mp == null) { next(ctx); return }
            player = mp
            playing = true
            mp.setOnCompletionListener { done(it, ctx) }
            mp.setOnErrorListener { p, _, _ -> done(p, ctx); true }
            mp.start()
        } catch (e: Exception) {
            playing = false
            player = null
        }
    }

    private fun done(mp: MediaPlayer?, ctx: Context) {
        synchronized(this) {
            playing = false
            try { mp?.release() } catch (_: Exception) {}
            if (player === mp) player = null
        }
        next(ctx)
    }

    @Synchronized
    fun stop() {
        queue.clear()
        playing = false
        release()
    }

    private fun release() {
        try { player?.let { if (it.isPlaying) it.stop() } } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }
}
