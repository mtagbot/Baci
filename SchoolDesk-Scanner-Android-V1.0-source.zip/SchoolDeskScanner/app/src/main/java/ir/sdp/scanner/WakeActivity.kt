package ir.sdp.scanner

import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * صفحهٔ «بیداری»: با روشن‌شدنِ آنیِ نمایشگر بالا می‌آید، نام دانش‌آموز را بزرگ
 * نشان می‌دهد و پس از چند ثانیه بسته می‌شود تا نمایشگر دوباره به standby برگردد.
 */
class WakeActivity : AppCompatActivity() {

    companion object { const val EXTRA_NAME = "name"; const val SHOW_MS = 3000L }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // روشن‌کردن و بیدار نگه‌داشتن موقت، حتی روی صفحهٔ قفل
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
        )

        setContentView(R.layout.activity_wake)
        findViewById<TextView>(R.id.wakeName).text = intent.getStringExtra(EXTRA_NAME) ?: "—"

        Handler(Looper.getMainLooper()).postDelayed({ finish() }, SHOW_MS)
    }
}
