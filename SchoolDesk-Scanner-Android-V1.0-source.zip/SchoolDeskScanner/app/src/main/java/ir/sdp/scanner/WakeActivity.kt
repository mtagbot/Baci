package ir.sdp.scanner

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * صفحهٔ «بیداری»: با روشن‌شدنِ آنیِ نمایشگر بالا می‌آید، نام دانش‌آموز و ساعت حضور را
 * نشان می‌دهد و پس از چند ثانیه بسته می‌شود تا نمایشگر دوباره به standby برگردد.
 *
 * بهینه‌سازی باتری: اگر همین صفحه باز باشد، اسکن بعدی فقط متن را به‌روز می‌کند
 * (onNewIntent) و فعالیت جدید ساخته نمی‌شود.
 */
class WakeActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NAME = "name"
        const val EXTRA_TIME = "time"
        const val EXTRA_STATUS = "status"
        @Volatile var alive = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private val finisher = Runnable { finish() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // روشن‌کردن و نمایش روی صفحهٔ قفل — با مسیر جدید و مسیر سازگار با گوشی‌های قدیمی
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
        )

        setContentView(R.layout.activity_wake)
        alive = true
        render(intent)
    }

    /** اسکن بعدی در حالی که صفحه باز است: فقط متن عوض می‌شود، فعالیت جدید ساخته نمی‌شود. */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        render(intent)
    }

    private fun render(intent: Intent?) {
        findViewById<TextView>(R.id.wakeName).text =
            intent?.getStringExtra(EXTRA_NAME) ?: "—"
        findViewById<TextView>(R.id.wakeTime).text =
            intent?.getStringExtra(EXTRA_TIME) ?: ServerClock.timeString()
        findViewById<TextView>(R.id.wakeSub).text =
            intent?.getStringExtra(EXTRA_STATUS)?.takeIf { it.isNotEmpty() }
                ?: getString(R.string.read_ok)

        handler.removeCallbacks(finisher)
        handler.postDelayed(finisher, AppPreferences.wakeMs(this))
    }

    override fun onDestroy() {
        alive = false
        handler.removeCallbacks(finisher)
        super.onDestroy()
    }
}
