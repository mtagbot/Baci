package ir.sdp.scanner

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val REQ_CAM = 100
    private lateinit var status: TextView
    private lateinit var last: TextView
    private lateinit var etServer: EditText
    private lateinit var etKey: EditText
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnTorch: Button

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val extra = i.getStringExtra(ScannerService.EXTRA_LAST)
            when (i.getStringExtra(ScannerService.EXTRA_TYPE)) {
                "running" -> showStatus(R.string.status_running)
                "ready" -> { showStatus(R.string.status_running); toast("دوربین آمادهٔ اسکن است") }
                "idle" -> showStatus(R.string.status_idle)
                "scan" -> last.text = getString(R.string.last).replace("—", extra ?: "—")
                "torch" -> toast(if (extra == "on") "چراغ روشن شد" else "چراغ خاموش شد")
                "error" -> { extra?.let { toast(it) }; status.text = "خطا: " + (extra ?: "") }
            }
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        last = findViewById(R.id.last)
        etServer = findViewById(R.id.etServer)
        etKey = findViewById(R.id.etKey)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnTorch = findViewById(R.id.btnTorch)

        etServer.setText(AppPreferences.serverUrl(this))
        etKey.setText(AppPreferences.scannerKey(this))
        // ذخیرهٔ آدرس سرور به‌محض تایپ (نه فقط هنگام زدن شروع)
        etServer.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(t: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(t: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(t: Editable?) {
                AppPreferences.setServerUrl(this@MainActivity, t?.toString()?.trim() ?: "")
            }
        })

        etKey.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(t: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(t: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(t: Editable?) {
                AppPreferences.setScannerKey(this@MainActivity, t?.toString()?.trim() ?: "")
            }
        })

        btnStart.setOnClickListener { tryStart() }
        btnStop.setOnClickListener { send(ScannerService.ACTION_STOP); showStatus(R.string.status_idle) }
        btnTorch.setOnClickListener {
            if (!ScannerService.cameraReady) toast("ابتدا «شروع اسکن» را بزنید") else send(ScannerService.ACTION_TORCH)
        }

        requestBatteryExemption()   // بهینه‌سازی: خارج‌شدن از Doze برای این اپ
    }

    private fun send(action: String) =
        startService(Intent(this, ScannerService::class.java).setAction(action))

    private fun showStatus(res: Int) = status.setText(res)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun tryStart() {
        AppPreferences.setServerUrl(this, etServer.text.toString().trim())
        AppPreferences.setScannerKey(this, etKey.text.toString().trim())
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQ_CAM)
        } else start()
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        if (rc == REQ_CAM) {
            if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) start()
            else toast(getString(R.string.perm_camera))
        }
    }

    private fun start() {
        val i = Intent(this, ScannerService::class.java).setAction(ScannerService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    /** بهینه‌سازی باتری: درخواست معافیت از بهینه‌سازی/Doze برای این اپ. */
    @SuppressLint("BatteryLife")
    private fun requestBatteryExemption() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName")))
            } catch (_: Exception) {}
        }
    }

    /** همگام‌سازی وضعیت با سرویس هنگام بازگشت به صفحه (اگر سرویس در پس‌زمینه فعال است). */
    private fun syncState() {
        if (ScannerService.running) {
            showStatus(if (ScannerService.cameraReady) R.string.status_running else R.string.status_running)
        } else {
            showStatus(R.string.status_idle)
            ScannerService.lastError?.let { status.text = "خطا: $it" }
        }
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    override fun onResume() {
        super.onResume()
        val f = IntentFilter(ScannerService.EVENT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
        syncState()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }
}
