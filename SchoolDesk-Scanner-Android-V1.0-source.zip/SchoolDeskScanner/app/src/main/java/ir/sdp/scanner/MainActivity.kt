package ir.sdp.scanner

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val REQ_PERMS = 100
    private lateinit var status: TextView
    private lateinit var last: TextView
    private lateinit var etServer: EditText
    private lateinit var etKey: EditText
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnTorch: Button
    private lateinit var btnOverlay: Button
    private lateinit var btnTest: Button
    private lateinit var cbCompat: CheckBox
    private lateinit var cbSound: CheckBox
    private lateinit var cbVibrate: CheckBox
    private lateinit var cbTorchAuto: CheckBox

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val extra = i.getStringExtra(ScannerService.EXTRA_LAST)
            when (i.getStringExtra(ScannerService.EXTRA_TYPE)) {
                "running" -> showStatus(R.string.status_running)
                "ready" -> { showStatus(R.string.status_running); toast("دوربین آمادهٔ اسکن است") }
                "idle" -> showStatus(R.string.status_idle)
                "scan" -> last.text = getString(R.string.last).replace("—", extra ?: "—")
                "torch" -> toast(if (extra == "on") "چراغ روشن شد" else "چراغ خاموش شد")
                "error" -> { extra?.let { toast(it) }; status.text = "خطا: " + (extra ?: "") }
            }
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        last = findViewById(R.id.last)
        etServer = findViewById(R.id.etServer)
        etKey = findViewById(R.id.etKey)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnTorch = findViewById(R.id.btnTorch)
        btnOverlay = findViewById(R.id.btnOverlay)
        btnTest = findViewById(R.id.btnTest)
        cbCompat = findViewById(R.id.cbCompat)
        cbSound = findViewById(R.id.cbSound)
        cbVibrate = findViewById(R.id.cbVibrate)
        cbTorchAuto = findViewById(R.id.cbTorchAuto)

        // مصرف باتری: صدا روشن، لرزش و چراغ خودکار پیش‌فرض خاموش
        cbSound.isChecked = AppPreferences.soundOn(this)
        cbVibrate.isChecked = AppPreferences.vibrateOn(this)
        cbTorchAuto.isChecked = AppPreferences.autoTorch(this)
        cbSound.setOnCheckedChangeListener { _, c -> AppPreferences.setSound(this, c) }
        cbVibrate.setOnCheckedChangeListener { _, c -> AppPreferences.setVibrate(this, c) }
        cbTorchAuto.setOnCheckedChangeListener { _, c -> AppPreferences.setAutoTorch(this, c) }

        etServer.setText(AppPreferences.serverUrl(this))
        etKey.setText(AppPreferences.scannerKey(this))
        // ذخیرهٔ آدرس سرور و کلید به‌محض تایپ (نه فقط هنگام زدن شروع)
        etServer.addTextChangedListener(saver { AppPreferences.setServerUrl(this, it) })
        etKey.addTextChangedListener(saver { AppPreferences.setScannerKey(this, it) })

        btnStart.setOnClickListener { tryStart() }
        btnStop.setOnClickListener { send(ScannerService.ACTION_STOP); showStatus(R.string.status_idle) }
        btnTorch.setOnClickListener {
            if (!ScannerService.cameraReady) toast("ابتدا «شروع اسکن» را بزنید")
            else send(ScannerService.ACTION_TORCH)
        }
        btnOverlay.setOnClickListener { requestOverlayPermission() }

        // حالت سازگاری SSL — فقط برای گوشی قدیمی که گواهی سایت را تأیید نمی‌کند
        cbCompat.isChecked = AppPreferences.compatMode(this)
        cbCompat.setOnCheckedChangeListener { _, checked ->
            AppPreferences.setCompatMode(this, checked)
            toast(if (checked) "حالت سازگاری روشن شد" else "حالت سازگاری خاموش شد")
        }

        // آزمایش اتصال: بدون اسکنِ واقعی، علت دقیق مشکل شبکه را نشان می‌دهد
        btnTest.setOnClickListener {
            status.text = "در حال آزمایش اتصال…"
            CheckIn.testConnection(this) { res ->
                status.text = res
                toast(res)
            }
        }

        requestBatteryExemption()   // بهینه‌سازی: خارج‌شدن از Doze برای این اپ
    }

    private fun saver(write: (String) -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(t: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(t: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(t: Editable?) { write(t?.toString()?.trim() ?: "") }
    }

    private fun send(action: String) =
        startService(Intent(this, ScannerService::class.java).setAction(action))

    private fun showStatus(res: Int) = status.setText(res)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    /** دسترسی‌ها: دوربین برای اسکن، اعلان برای نمایش نام روی صفحهٔ قفل (اندروید ۱۳+). */
    private fun tryStart() {
        AppPreferences.setServerUrl(this, etServer.text.toString().trim())
        AppPreferences.setScannerKey(this, etKey.text.toString().trim())
        val need = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMS)
        else start()
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        if (rc != REQ_PERMS) return
        val camIdx = perms.indexOf(Manifest.permission.CAMERA)
        if (camIdx >= 0 && res.getOrNull(camIdx) == PackageManager.PERMISSION_GRANTED) start()
        else toast(getString(R.string.perm_camera))
    }

    /** دسترسی «نمایش روی سایر برنامه‌ها» => نام دانش‌آموز حتی روی صفحهٔ قفل دیده می‌شود. */
    private fun requestOverlayPermission() {
        if (LockOverlay.canDraw(this)) { toast("دسترسی نمایش روی قفل فعال است"); return }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) { toast("روی این نسخهٔ اندروید لازم نیست"); return }
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        } catch (_: Exception) { toast("تنظیمات این دسترسی در این دستگاه در دسترس نیست") }
    }

    private fun start() {
        val i = Intent(this, ScannerService::class.java).setAction(ScannerService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    /** بهینه‌سازی باتری: درخواست معافیت از بهینه‌سازی/Doze برای این اپ. */
    @SuppressLint("BatteryLife")
    private fun requestBatteryExemption() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName")))
            } catch (_: Exception) {}
        }
    }

    /** همگام‌سازی وضعیت با سرویس هنگام بازگشت به صفحه. */
    private fun syncState() {
        if (ScannerService.running) showStatus(R.string.status_running)
        else {
            showStatus(R.string.status_idle)
            ScannerService.lastError?.let { status.text = "خطا: $it" }
        }
        btnOverlay.text = if (LockOverlay.canDraw(this))
            getString(R.string.overlay_granted) else getString(R.string.overlay_perm)
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    override fun onResume() {
        super.onResume()
        val f = IntentFilter(ScannerService.EVENT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
        syncState()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }
}
