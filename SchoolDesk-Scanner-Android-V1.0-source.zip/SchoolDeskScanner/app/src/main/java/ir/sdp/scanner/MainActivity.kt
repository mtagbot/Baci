package ir.sdp.scanner

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val REQ_CAM = 100
    private lateinit var status: TextView
    private lateinit var last: TextView
    private lateinit var etServer: android.widget.EditText

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.getStringExtra(ScannerService.EXTRA_TYPE)) {
                "running" -> status.setText(R.string.status_running)
                "idle" -> status.setText(R.string.status_idle)
                "scan" -> last.text = getString(R.string.last).replace("—", i.getStringExtra(ScannerService.EXTRA_LAST) ?: "—")
                "error" -> status.text = "خطا: " + (i.getStringExtra(ScannerService.EXTRA_LAST) ?: "")
            }
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        last = findViewById(R.id.last)
        etServer = findViewById(R.id.etServer)
        etServer.setText(AppPreferences.serverUrl(this))
        findViewById<Button>(R.id.btnStart).setOnClickListener { tryStart() }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(Intent(this, ScannerService::class.java).setAction(ScannerService.ACTION_STOP))
        }
        findViewById<Button>(R.id.btnTorch).setOnClickListener {
            startService(Intent(this, ScannerService::class.java).setAction(ScannerService.ACTION_TORCH))
        }
        requestBatteryExemption()   // بهینه‌سازی: خارج‌شدن از Doze برای این اپ
    }

    private fun tryStart() {
        AppPreferences.setServerUrl(this, etServer.text.toString().trim())
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQ_CAM)
        } else start()
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        if (rc == REQ_CAM) {
            if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) start()
            else Toast.makeText(this, R.string.perm_camera, Toast.LENGTH_LONG).show()
        }
    }

    private fun start() {
        val i = Intent(this, ScannerService::class.java).setAction(ScannerService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    /** بهینه‌سازی باتری: درخواست معافیت از بهینه‌سازی/Doze برای این اپ. */
    @SuppressLint("BatteryLife")
    private fun requestBatteryExemption() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName")))
            } catch (_: Exception) {}
        }
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    override fun onResume() {
        super.onResume()
        val f = IntentFilter(ScannerService.EVENT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }
}
