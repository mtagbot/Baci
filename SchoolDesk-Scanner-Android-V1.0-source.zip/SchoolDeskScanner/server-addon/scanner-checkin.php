<?php
/**
 * scanner-checkin.php — نقطهٔ اتصال اختیاری اپِ اندروید به سامانه.
 *
 * نصب: این فایل را در پوشهٔ  api/  ریشهٔ سایت بگذارید:
 *      <site>/api/scanner-checkin.php
 *
 * ورودی: POST با بدنهٔ JSON  {"tag":"<کد ملی یا شناسهٔ دانش‌آموز>"}
 * خروجی: JSON  {"name":"<نام و نام خانوادگی>"}  یا  {"name":""}
 *
 * رفتار: دانش‌آموز را بر اساس کد ملی/شناسه پیدا می‌کند، یک رکورد «حاضر»
 * برای امروز ثبت می‌کند (اگر قبلاً نبود) و نام را برمی‌گرداند تا اپ نمایش دهد.
 * همهٔ خطاها بلعیده می‌شوند تا اپ هرگز به‌خاطر سرور متوقف نشود.
 */
header('Content-Type: application/json; charset=utf-8');
$out = ['name' => ''];
try {
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $tag = trim((string)($body['tag'] ?? ''));
    if ($tag !== '') {
        require_once __DIR__ . '/../includes/db.php';
        require_once __DIR__ . '/../includes/functions.php';

        $st = DB::fetch("SELECT id, first_name, last_name FROM students WHERE national_id = ? OR id = ? LIMIT 1", [$tag, (int)$tag]);
        if ($st) {
            $out['name'] = trim($st['first_name'] . ' ' . $st['last_name']);
            try {
                $today = function_exists('jalali_now') ? substr(jalali_now(), 0, 10) : date('Y-m-d');
                $exists = DB::fetch("SELECT id FROM student_attendance WHERE student_id = ? AND date_jalali = ? LIMIT 1", [(int)$st['id'], $today]);
                if (!$exists) {
                    DB::execute("INSERT INTO student_attendance (student_id, date_jalali, status, source) VALUES (?, ?, 'present', 'qr')",
                        [(int)$st['id'], $today]);
                }
            } catch (Exception $e) { /* ساختار جدول ممکن است متفاوت باشد؛ فقط نام مهم است */ }
        }
    }
} catch (Exception $e) { /* هرگز اپ را نشکن */ }
echo json_encode($out, JSON_UNESCAPED_UNICODE);
