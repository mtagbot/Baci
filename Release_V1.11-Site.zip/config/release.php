<?php
return ['release'=>'Release_V1.11','distribution'=>'site','site_version'=>'4.217.0','desktop_version'=>'2.141.0'];
