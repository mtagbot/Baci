<?php
return ['release'=>'Release_V1.10','distribution'=>'site','site_version'=>'4.216.0','desktop_version'=>'2.140.0'];
