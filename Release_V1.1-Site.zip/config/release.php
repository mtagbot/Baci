<?php
return ['release'=>'Release_V1.1','distribution'=>'site','site_version'=>'4.178.0','desktop_version'=>'2.101.0'];
