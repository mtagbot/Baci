<?php
/**
 * Reports & Grades Management (reports.php)
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/academic_year_helpers.php';
require_once __DIR__ . '/includes/school_roles.php';
ensure_school_roles_schema();
$canDeputyReports = function_exists('is_teacher_logged_in') && is_teacher_logged_in() && (teacher_has_deputy($_SESSION['teacher_id']) || teacher_has_executive($_SESSION['teacher_id']));
if (!$canDeputyReports) require_permission('manage_reports');
require_once __DIR__ . '/includes/header.php';

$action   = $_GET['action'] ?? '';
$reportId = (int)($_GET['id'] ?? 0);

// Delete Report
if ($action === 'delete' && $reportId > 0) {
    DB::execute("DELETE FROM reports WHERE id = ?", [$reportId]);
    DB::execute("DELETE FROM report_grades WHERE report_id = ?", [$reportId]);
    log_activity($_SESSION['admin_id'], 'حذف کارنامه', "کارنامه ID: $reportId حذف شد.");
    set_flash_message('success', 'کارنامه مورد نظر حذف شد.');
    redirect('reports.php');
}

// Unlock a pre-locked month/class rule directly from the active locks banner
if ($action === 'unlock_rule' && isset($_GET['lock_id'])) {
    ensure_report_locks_schema();
    $lockId = (int)$_GET['lock_id'];
    $rule = DB::fetch("SELECT * FROM report_locks WHERE id = ?", [$lockId]);
    if ($rule) {
        /* V4.209.4 — دو نوع قاعده دو معنی متفاوت دارد:
           · قاعدهٔ گروهی (کلاس/همه کلاس‌ها) → فقط همان لایه برداشته می‌شود؛
             مسدودیت‌های فردیِ دانش‌آموزان (بدهی مالی و…) سر جایشان می‌مانند.
           · قاعدهٔ یک دانش‌آموز → همان دانش‌آموز کامل آزاد می‌شود (قاعده + قفل ردیف). */
        if ((int)($rule['student_id'] ?? 0) > 0) {
            set_report_bulk_lock($rule['academic_year'] ?? '', $rule['report_month'] ?? '', $rule['class_name'] ?? '', (int)$rule['student_id'], 0, '');
        } else {
            set_report_bulk_lock($rule['academic_year'] ?? '', $rule['report_month'] ?? '', $rule['class_name'] ?? '', 0, 0, '');
        }
        DB::execute("DELETE FROM report_locks WHERE id = ?", [$lockId]);
        unset($GLOBALS['__sdp_report_locks_cache']);
        log_activity($_SESSION['admin_id'] ?? null, 'رفع مسدودیت پیشینی کارنامه', "قانون مسدودسازی #{$lockId} ({$rule['report_month']}) آزاد شد.");
        set_flash_message('success', (int)($rule['student_id'] ?? 0) > 0
            ? 'مسدودیت فردی این دانش‌آموز برای این ماه برداشته شد.'
            : 'مسدودیت گروهی این ماه/کلاس برداشته شد. مسدودیت‌های فردیِ دانش‌آموزان (مثل بدهی مالی) دست‌نخورده باقی ماند.');
    }
    redirect('reports.php');
}

// Toggle Lock single report via standard request
if ($action === 'toggle_lock' && $reportId > 0) {
    $rep = DB::fetch("SELECT * FROM reports WHERE id = ?", [$reportId]);
    if ($rep) {
        ensure_report_locks_schema();
        $currentlyLocked = is_report_locked_for_student($rep);
        $newLock = $currentlyLocked ? 0 : 1;
        /* V4.209.4 — «مسدود کردن» این ردیف یعنی یک مسدودیت فردیِ مستقل:
           فقط ستون همین کارنامه. پس آزادسازی گروهیِ ماه/کلاس هرگز آن را باز
           نمی‌کند و تا وقتی مدیر همین ردیف را آزاد نکند مسدود می‌ماند.
           «رفع مسدودیت» یعنی آزادسازی کامل همین دانش‌آموز در همین ماه
           (قاعده‌های فردی + قفل ردیف) و اگر مسدودیت کلاسی باقی باشد، استثنای
           آزادسازی برای او ثبت می‌شود. */
        if ($newLock === 1) {
            DB::execute("UPDATE reports SET is_locked = 1 WHERE id = ?", [$reportId]);
            unset($GLOBALS['__sdp_report_locks_cache']);
        } else {
            set_report_bulk_lock($rep['academic_year'] ?? '', $rep['report_month'] ?? '', $rep['class_name'] ?? '', (int)$rep['student_id'], 0, '');
        }
        log_activity($_SESSION['admin_id'] ?? null, 'تغییر قفل کارنامه', "کارنامه $reportId وضعیت مسدودسازی به $newLock شد.");
        set_flash_message('success', $newLock === 1
            ? 'این کارنامه به‌صورت فردی مسدود شد؛ با آزادسازی گروهی ماه/کلاس باز نمی‌شود.'
            : 'مسدودیت این دانش‌آموز برای این ماه برداشته شد.');
    }
    redirect('reports.php');
}

// Save Manual Report
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_report'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash_message('error', 'خطای امنیتی CSRF');
        redirect('reports.php');
    }
    $studentId = (int)($_POST['student_id'] ?? 0);
    $year = unify_academic_year(trim($_POST['academic_year'] ?? '1402-1403'));
    $term      = trim($_POST['term'] ?? 'نوبت اول');
    $month     = trim($_POST['report_month'] ?? 'دی');
    $comments  = trim($_POST['teacher_comments'] ?? '');
    $disciplineScore = ($_POST['discipline_score'] ?? '') !== '' ? (float)str_replace('/', '.', $_POST['discipline_score']) : null;

    $student = DB::fetch("SELECT class_name FROM students WHERE id = ?", [$studentId]);
    if (!$student) {
        set_flash_message('error', 'دانش‌آموز انتخاب‌شده نامعتبر است.');
        redirect('reports.php');
    }

    $subjNames  = $_POST['subject_name'] ?? [];
    $subjScores = $_POST['score'] ?? [];
    $subjMax    = $_POST['max_score'] ?? [];
    $subjCoeff  = $_POST['coefficient'] ?? [];

    $totalWeighted = 0;
    $totalCoeff = 0;
    $gradesData = [];

    foreach ($subjNames as $idx => $sname) {
        $sname = trim($sname);
        if (empty($sname)) continue;
        $rawScore = trim((string)($subjScores[$idx] ?? ''));
        // Empty score means the subject is not included in this report at all.
        if ($rawScore === '') continue;
        $score = (float)str_replace('/', '.', $rawScore);
        $max   = (float)($subjMax[$idx] ?? 20);
        $coef  = (float)($subjCoeff[$idx] ?? 1);

        // Score 21 means absence (غیبت): show in report, but ignore in GPA.
        if ($score != 21.0) {
            $totalWeighted += ($score * $coef);
            $totalCoeff += $coef;
        }
        $gradesData[] = [
            'name' => $sname,
            'score' => $score,
            'max' => $max,
            'coef' => $coef,
            'status' => $score == 21.0 ? 'none' : ($score >= 10 ? 'passed' : 'failed')
        ];
    }

    $gpa = $totalCoeff > 0 ? round($totalWeighted / $totalCoeff, 2) : 0;

    if ($reportId > 0) {
        DB::execute("UPDATE reports SET student_id=?, class_name=?, academic_year=?, term=?, report_month=?, total_score=?, gpa=?, discipline_score=?, teacher_comments=? WHERE id=?",
        [$studentId, $student['class_name'], $year, $term, $month, $totalWeighted, $gpa, $disciplineScore, $comments, $reportId]);
        DB::execute("DELETE FROM report_grades WHERE report_id = ?", [$reportId]);
        foreach ($gradesData as $g) {
            DB::execute("INSERT INTO report_grades (report_id, subject_name, score, max_score, coefficient, status) VALUES (?, ?, ?, ?, ?, ?)",
            [$reportId, $g['name'], $g['score'], $g['max'], $g['coef'], $g['status']]);
        }
        log_activity($_SESSION['admin_id'] ?? null, 'ویرایش کارنامه', "کارنامه ID: $reportId ویرایش شد.");
        set_flash_message('success', 'کارنامه با موفقیت ویرایش و محاسبه شد.');
    } else {
        $initLock = is_report_prelocked($year, $month, $student['class_name'], $studentId) ? 1 : 0;
        DB::execute("INSERT INTO reports (student_id, class_name, academic_year, term, report_month, total_score, gpa, discipline_score, teacher_comments, is_locked) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [$studentId, $student['class_name'], $year, $term, $month, $totalWeighted, $gpa, $disciplineScore, $comments, $initLock]);
        $newRepId = DB::lastInsertId();
        foreach ($gradesData as $g) {
            DB::execute("INSERT INTO report_grades (report_id, subject_name, score, max_score, coefficient, status) VALUES (?, ?, ?, ?, ?, ?)",
            [$newRepId, $g['name'], $g['score'], $g['max'], $g['coef'], $g['status']]);
        }
        log_activity($_SESSION['admin_id'] ?? null, 'ثبت دستی کارنامه', "کارنامه جدید برای دانش‌آموز ID: $studentId ثبت شد.");
        set_flash_message('success', 'کارنامه جدید با موفقیت ایجاد و معدل محاسبه گردید.');
    }
    $targetReportId = $reportId > 0 ? $reportId : ($newRepId ?? 0);
    if ($targetReportId > 0) redirect('reports.php?action=edit&id=' . $targetReportId);
    redirect('reports.php');
}

if ($action === 'new' || $action === 'edit'):
    $repData = null;
    $gradesList = [];
    if ($action === 'edit' && $reportId > 0) {
        $repData = DB::fetch("SELECT * FROM reports WHERE id = ?", [$reportId]);
        $gradesList = DB::fetchAll("SELECT * FROM report_grades WHERE report_id = ?", [$reportId]);
    }
    $preselectStudentId = (int)($_GET['student_id'] ?? 0);
    $selectedFormStudentId = (int)($repData['student_id'] ?? $preselectStudentId);
    
    // Academic year options - from settings and existing data (Shamsi)
    $currentDefaultYear = get_setting('current_academic_year','1404/1405');
    $yearOptions = get_academic_years_for_filter();
    if (empty($yearOptions)) $yearOptions = [['academic_year'=>$currentDefaultYear], ['academic_year'=>'1404/1405'], ['academic_year'=>'1403/1404']];
    
    // Month options - fixed Persian months + terms
    $monthOptions = ['مهر','آبان','آذر','دی','بهمن','اسفند','فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','نوبت اول','نوبت دوم'];
    
    // Selected year and month for form - hierarchical: year -> month -> student
    $selectedYear = trim($_GET['academic_year'] ?? $repData['academic_year'] ?? $currentDefaultYear);
    $selectedMonth = trim($_GET['report_month'] ?? $repData['report_month'] ?? 'دی');
    
    // Fetch all active students with academic year for filtering - FIXED to show ALL students of that year with normalization
    $allStudents = DB::fetchAll("SELECT id, national_id, first_name, last_name, class_name, grade_level, academic_year FROM students WHERE status='active'");
    usort($allStudents, function($a,$b){ $c = strcmp((string)($b['academic_year']??''), (string)($a['academic_year']??'')); if ($c!==0) return $c; return persian_compare($a['last_name']??'', $b['last_name']??'') ?: persian_compare($a['first_name']??'', $b['first_name']??''); });   // v4.77.0: آ قبل از ا
    // Group students by NORMALIZED academic year for JS (to handle 1405/1406 vs 1405-1406 vs spaces)
    $studentsByYear = [];
    $studentsByYearNormalized = [];
    foreach ($allStudents as $s) {
        $ayRaw = $s['academic_year'] ?: '';
        $ay = $ayRaw ?: 'بدون سال';
        $ayNorm = $ayRaw ? (function($y){ $y=trim($y); $y=str_replace(['-','–','—',' '], ['/','/','/',''], $y); $y=preg_replace('#/+#','/',$y); return trim($y,'/'); })($ayRaw) : 'بدون سال';
        if (!isset($studentsByYear[$ay])) $studentsByYear[$ay] = [];
        $studentsByYear[$ay][] = $s;
        if (!isset($studentsByYearNormalized[$ayNorm])) $studentsByYearNormalized[$ayNorm] = [];
        $studentsByYearNormalized[$ayNorm][] = $s;
    }
    // For initial display, filter students by NORMALIZED selected year - show ALL of that year
    $selectedYearNorm = $selectedYear ? (function($y){ $y=trim($y); $y=str_replace(['-','–','—',' '], ['/','/','/',''], $y); $y=preg_replace('#/+#','/',$y); return trim($y,'/'); })($selectedYear) : '';
    $students = [];
    if ($selectedYearNorm !== '') {
        // Get all students whose normalized year equals selected normalized year
        $students = $studentsByYearNormalized[$selectedYearNorm] ?? [];
        // Also include students with empty academic_year? No, per requirement only that year, but include empty if selected is empty
        if (empty($students)) {
            // Fallback: filter manually with normalization
            $students = array_filter($allStudents, function($s) use ($selectedYearNorm) {
                $sNorm = $s['academic_year'] ? (function($y){ $y=trim($y); $y=str_replace(['-','–','—',' '], ['/','/','/',''], $y); $y=preg_replace('#/+#','/',$y); return trim($y,'/'); })($s['academic_year']) : '';
                return $sNorm === $selectedYearNorm;
            });
        }
    } else {
        $students = $allStudents;
    }
    if (empty($students)) $students = $allStudents; // fallback if no match to avoid empty list
    
    $selectedStudent = $selectedFormStudentId ? DB::fetch("SELECT class_name, grade_level FROM students WHERE id=?", [$selectedFormStudentId]) : null;
    if ($selectedStudent) {
        $defaultSubjects = DB::fetchAll("SELECT DISTINCT subject_name AS name, 1 AS coefficient FROM class_schedules WHERE class_name=? AND subject_name<>'' ORDER BY subject_name", [$selectedStudent['class_name']]);
        if (!$defaultSubjects) {
            $defaultSubjects = DB::fetchAll("SELECT name, coefficient FROM subjects WHERE grade_level=? OR grade_level='عمومی' OR grade_level='' ORDER BY name", [$selectedStudent['grade_level']]);
        }
    } else {
        $defaultSubjects = [];
    }
    $gradeRows = [];
    $existingBySubject = [];
    foreach ($gradesList as $gr) {
        $existingBySubject[$gr['subject_name']] = $gr;
        $gradeRows[] = [
            'subject_name' => $gr['subject_name'],
            'score' => $gr['score'],
            'max_score' => $gr['max_score'],
            'coefficient' => $gr['coefficient']
        ];
    }
    foreach ($defaultSubjects as $sub) {
        $subName = $sub['name'] ?? $sub['subject_name'] ?? '';
        if ($subName !== '' && !isset($existingBySubject[$subName])) {
            $gradeRows[] = [
                'subject_name' => $subName,
                'score' => '',
                'max_score' => 20,
                'coefficient' => $sub['coefficient'] ?? 1
            ];
        }
    }
?>
<div class="max-w-3xl mx-auto card p-6">
    <h3 class="text-lg font-bold mb-6 text-primary border-b pb-2">
        <?php echo $action === 'edit' ? 'ویرایش نمرات و کارنامه' : 'ثبت دستی کارنامه جدید'; ?>
        <span class="text-xs text-muted">(سال تحصیلی → ماه → دانش‌آموز)</span>
    </h3>
    <form method="POST" action="reports.php?id=<?php echo $reportId; ?>" id="reportForm">
        <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
        <input type="hidden" name="save_report" value="1">

        <!-- Hierarchical Selectors: Year -> Month -> Student -->
        <div class="space-y-4 mb-6 p-4 border-2 border-indigo-100 rounded-xl bg-indigo-50/30">
            <h4 class="font-bold text-sm text-indigo-700">۱. انتخاب سال تحصیلی (شمسی) → ۲. ماه → ۳. دانش‌آموز</h4>
            <div class="grid grid-cols-3 gap-4">
                <div>
                    <label class="block text-xs font-bold mb-1">۱. سال تحصیلی *</label>
                    <select name="academic_year" id="academicYearSelect" class="form-select font-bold" required onchange="filterStudentsByYear(); updateMonthOptions();">
                        <option value="">انتخاب سال تحصیلی...</option>
                        <?php foreach ($yearOptions as $yo): $ay = $yo['academic_year']; $ayNorm = $ay ? (function($y){ $y=trim($y); $y=str_replace(['-','–','—',' '], ['/','/','/',''], $y); $y=preg_replace('#/+#','/',$y); return trim($y,'/'); })($ay) : ''; $cntNorm = isset($studentsByYearNormalized[$ayNorm]) ? count($studentsByYearNormalized[$ayNorm]) : (isset($studentsByYear[$ay]) ? count($studentsByYear[$ay]) : 0); ?>
                            <option value="<?php echo clean($ay); ?>" <?php echo $selectedYear===$ay ? 'selected' : ''; ?>><?php echo clean($ay); ?> (<?php echo $cntNorm; ?> نفر)</option>
                        <?php endforeach; ?>
                    </select>
                    <div class="text-[10px] text-muted mt-1">سال جاری سیستم: <?php echo clean($currentDefaultYear); ?></div>
                </div>
                <div>
                    <label class="block text-xs font-bold mb-1">۲. ماه / نوبت تحصیلی *</label>
                    <select name="report_month" id="reportMonthSelect" class="form-select font-bold" required>
                        <option value="">انتخاب ماه...</option>
                        <?php foreach ($monthOptions as $mo): ?>
                            <option value="<?php echo clean($mo); ?>" <?php echo $selectedMonth===$mo ? 'selected' : ''; ?>><?php echo clean($mo); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-bold mb-1">عنوان نوبت (اختیاری)</label>
                    <input type="text" name="term" class="form-input" value="<?php echo clean($repData['term'] ?? $selectedMonth); ?>" placeholder="نوبت اول / دوم / ماهانه" id="termInput">
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold mb-1">۳. انتخاب دانش‌آموز * <span class="text-[10px] text-muted" id="studentCountLabel">(فقط دانش‌آموزان سال انتخاب شده)</span></label>
                <select name="student_id" id="studentSelect" class="form-select" required onchange="if(!<?php echo $reportId ? 'true' : 'false'; ?>){location.href='reports.php?action=new&academic_year='+encodeURIComponent(document.getElementById('academicYearSelect').value)+'&report_month='+encodeURIComponent(document.getElementById('reportMonthSelect').value)+'&student_id='+this.value;}">
                    <option value="">ابتدا سال تحصیلی را انتخاب کنید...</option>
                </select>
                <div class="text-[10px] text-muted mt-1">فقط دانش‌آموزان سال تحصیلی انتخاب شده نمایش داده می‌شوند. برای تغییر سال، سال را عوض کنید.</div>
            </div>
        </div>

        <script>
        // All students grouped by year - for filtering - FIXED with normalized map
        window.studentsByYear = <?php echo json_encode($studentsByYear, JSON_UNESCAPED_UNICODE); ?>;
        window.studentsByYearNormalized = <?php echo json_encode($studentsByYearNormalized, JSON_UNESCAPED_UNICODE); ?>;
        window.allStudents = <?php echo json_encode($allStudents, JSON_UNESCAPED_UNICODE); ?>;
        window.selectedStudentId = <?php echo (int)$selectedFormStudentId; ?>;

        function normalizeYearJS(y){
            if(!y) return '';
            y = y.trim().replace(/[-–—\s]+/g, '/').replace(/\/+/g, '/').replace(/^\/|\/$/g, '');
            return y;
        }

        function filterStudentsByYear(){
            let yearRaw = document.getElementById('academicYearSelect').value;
            let year = normalizeYearJS(yearRaw);
            let studentSelect = document.getElementById('studentSelect');
            let countLabel = document.getElementById('studentCountLabel');
            studentSelect.innerHTML = '';
            
            if(!yearRaw){
                studentSelect.innerHTML = '<option value="">ابتدا سال تحصیلی را انتخاب کنید...</option>';
                countLabel.textContent = '(ابتدا سال را انتخاب کنید)';
                return;
            }

            // Try normalized map first - shows ALL students of that normalized year (handles 1405/1406 vs 1405-1406)
            let students = window.studentsByYearNormalized[year] || [];
            if(students.length===0){
                // Fallback to exact raw map
                students = window.studentsByYear[yearRaw] || [];
            }
            if(students.length===0){
                let alt1 = yearRaw.replace('/', '-');
                let alt2 = yearRaw.replace('-', '/');
                students = window.studentsByYear[alt1] || window.studentsByYear[alt2] || window.studentsByYearNormalized[normalizeYearJS(alt1)] || [];
            }
            // If still empty, filter manually with normalization - shows ALL matching
            if(students.length===0){
                students = window.allStudents.filter(s=> {
                    let sNorm = s.academic_year ? normalizeYearJS(s.academic_year) : '';
                    return sNorm === year;
                });
            }
            if(students.length===0){
                // Last fallback: show all to avoid empty
                students = window.allStudents;
                countLabel.textContent = `(هشدار: ${students.length} دانش‌آموز - سال ${yearRaw} یافت نشد، همه نمایش داده شدند)`;
            } else {
                countLabel.textContent = `(نمایش تمام دانش‌آموزان سال ${yearRaw} - ${students.length} نفر)`;
            }

            studentSelect.add(new Option('انتخاب دانش‌آموز...', ''));
            students.forEach(s=>{
                let text = `${s.last_name}، ${s.first_name} (${s.national_id} - ${s.class_name} - ${s.academic_year||'بدون سال'})`;
                let opt = new Option(text, s.id, false, parseInt(s.id)===window.selectedStudentId);
                studentSelect.add(opt);
            });

            if(students.length===0){
                studentSelect.innerHTML = '<option value="">دانش‌آموزی در این سال یافت نشد</option>';
            }
        }

        function updateMonthOptions(){
            let month = document.getElementById('reportMonthSelect').value;
            let termInput = document.getElementById('termInput');
            if(month && !termInput.value){
                termInput.value = month;
            } else if(month){
                // If term is same as previous month, update to new month
                // Keep custom term if user edited
            }
        }

        document.addEventListener('DOMContentLoaded', function(){
            filterStudentsByYear();
            // Set month change to update term
            document.getElementById('reportMonthSelect').addEventListener('change', function(){
                document.getElementById('termInput').value = this.value;
            });
        });
        </script>

        <div class="grid grid-cols-2 gap-4 mb-6" style="display:none;">
            <!-- Old fields kept hidden for fallback -->
            <div>
                <label class="block text-xs font-semibold mb-1">عنوان نوبت تحصیلی</label>
                <select name="term_old" class="form-select"><?php $troSel = trim($repData['term'] ?? 'نوبت اول'); $troOpts = ['ماهانه','نوبت اول','نوبت دوم']; if ($troSel !== '' && !in_array($troSel, $troOpts, true)) $troOpts[] = $troSel; foreach ($troOpts as $troT): ?><option value="<?php echo clean($troT); ?>" <?php echo $troSel===$troT?'selected':''; ?>><?php echo clean($troT); ?></option><?php endforeach; ?></select>
            </div>
            <div>
                <label class="block text-xs font-semibold mb-1">ماه کارنامه</label>
                <select name="report_month_old" class="form-select"><?php $rmoSel = trim($repData['report_month'] ?? 'دی'); $rmoOpts = ['مهر','آبان','آذر','دی','بهمن','اسفند','فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','نوبت اول','نوبت دوم']; if ($rmoSel !== '' && !in_array($rmoSel, $rmoOpts, true)) $rmoOpts[] = $rmoSel; foreach ($rmoOpts as $rmoM): ?><option value="<?php echo clean($rmoM); ?>" <?php echo $rmoSel===$rmoM?'selected':''; ?>><?php echo clean($rmoM); ?></option><?php endforeach; ?></select>
            </div>
        </div>

        <h4 class="font-bold mb-3 text-sm border-b pb-1">نمرات دروس:</h4>
        <div id="subjectsBox" class="space-y-2 mb-4">
            <?php foreach ($gradeRows as $gr): ?>
            <div class="grid grid-cols-4 gap-2 items-center">
                <input type="text" name="subject_name[]" class="form-input text-xs" value="<?php echo clean($gr['subject_name']); ?>" placeholder="نام درس" required>
                <input type="number" step="0.25" min="0" max="21" name="score[]" class="form-input text-xs font-bold" value="<?php echo clean($gr['score']); ?>" placeholder="خالی=عدم ثبت، 21=غیبت">
                <input type="number" step="0.25" min="1" max="100" name="max_score[]" class="form-input text-xs" value="<?php echo clean($gr['max_score']); ?>" placeholder="حداکثر">
                <input type="number" step="0.5" min="0.5" max="10" name="coefficient[]" class="form-input text-xs" value="<?php echo clean($gr['coefficient']); ?>" placeholder="ضریب">
            </div>
            <?php endforeach; if (empty($gradeRows)): ?>
            <div class="text-center text-muted text-xs p-3 border rounded">برای این دانش‌آموز/کلاس درسی یافت نشد؛ می‌توانید ردیف درس را دستی اضافه کنید.</div>
            <?php endif; ?>
        </div>

        <button type="button" onclick="addGradeRow()" class="btn btn-outline text-xs mb-6 w-full py-2">+ افزودن ردیف درس دیگر</button>

        <div class="mb-4">
            <label class="block text-xs font-semibold mb-1">نمره انضباط</label>
            <input type="number" step="0.25" min="0" max="21" name="discipline_score" class="form-input" value="<?php echo clean($repData['discipline_score'] ?? ''); ?>" placeholder="مثلاً 20">
        </div>

        <div class="mb-6">
            <label class="block text-xs font-semibold mb-1">نظر یا پیام معلم راهنما</label>
            <textarea name="teacher_comments" rows="2" class="form-textarea"><?php echo clean($repData['teacher_comments'] ?? ''); ?></textarea>
        </div>

        <div class="flex justify-between items-center">
            <a href="reports.php" class="btn btn-secondary">&rarr; انصراف</a>
            <button type="submit" class="btn btn-success px-8 py-2.5 font-bold"><svg data-ui-icon="save" class="school-icon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M3 3h15l3 3v15H3Zm4 0v7h10V3M7 21v-7h10v7"/></svg> محاسبه معدل و ذخیره کارنامه</button>
        </div>
    </form>
</div>
<script>
function addGradeRow() {
    const box = document.getElementById('subjectsBox');
    const div = document.createElement('div');
    div.className = 'grid grid-cols-4 gap-2 items-center';
    div.innerHTML = `
        <input type="text" name="subject_name[]" class="form-input text-xs" placeholder="نام درس" required>
        <input type="number" step="0.25" min="0" max="21" name="score[]" class="form-input text-xs font-bold" placeholder="خالی=عدم ثبت، 21=غیبت">
        <input type="number" step="0.25" min="1" max="100" name="max_score[]" class="form-input text-xs" value="20" placeholder="حداکثر">
        <input type="number" step="0.5" min="0.5" max="10" name="coefficient[]" class="form-input text-xs" value="2" placeholder="ضریب">
    `;
    box.appendChild(div);
}
</script>
<?php
else:
    $filterStudent = trim($_GET['student_query'] ?? '');
    $filterClass   = trim($_GET['class_name'] ?? '');
    $filterYear    = trim($_GET['year'] ?? '');
    $filterMonth   = trim($_GET['month'] ?? '');

    $where = ["1=1"];
    $params = [];
    if (!empty($filterStudent)) {
        $where[] = "(s.first_name LIKE ? OR s.last_name LIKE ? OR s.national_id LIKE ?)";
        $params[] = "%$filterStudent%"; $params[] = "%$filterStudent%"; $params[] = "%$filterStudent%";
    }
    if (!empty($filterClass)) { $where[] = "r.class_name = ?"; $params[] = $filterClass; }
    if (!empty($filterYear)) { $where[] = "r.academic_year = ?"; $params[] = $filterYear; }
    if (!empty($filterMonth)) { $where[] = "r.report_month = ?"; $params[] = $filterMonth; }

    $whereSql = implode(' AND ', $where);
    $reports = DB::fetchAll("SELECT r.*, s.first_name, s.last_name, s.national_id, s.photo_url FROM reports r JOIN students s ON r.student_id = s.id WHERE $whereSql ORDER BY r.id DESC LIMIT 100", $params);

    $classSet = [];
    foreach (DB::fetchAll("SELECT DISTINCT name AS class_name FROM classes WHERE name IS NOT NULL AND name <> ''") ?: [] as $cr) {
        $cn = trim((string)$cr['class_name']); if ($cn !== '') $classSet[norm_class_str($cn)] = ['class_name' => $cn];
    }
    foreach (DB::fetchAll("SELECT DISTINCT class_name FROM students WHERE class_name IS NOT NULL AND class_name <> ''") ?: [] as $cr) {
        $cn = trim((string)$cr['class_name']); if ($cn !== '' && !isset($classSet[norm_class_str($cn)])) $classSet[norm_class_str($cn)] = ['class_name' => $cn];
    }
    foreach (DB::fetchAll("SELECT DISTINCT class_name FROM class_schedules WHERE class_name IS NOT NULL AND class_name <> ''") ?: [] as $cr) {
        $cn = trim((string)$cr['class_name']); if ($cn !== '' && !isset($classSet[norm_class_str($cn)])) $classSet[norm_class_str($cn)] = ['class_name' => $cn];
    }
    foreach (DB::fetchAll("SELECT DISTINCT class_name FROM reports WHERE class_name IS NOT NULL AND class_name <> ''") ?: [] as $cr) {
        $cn = trim((string)$cr['class_name']); if ($cn !== '' && !isset($classSet[norm_class_str($cn)])) $classSet[norm_class_str($cn)] = ['class_name' => $cn];
    }
    $classes = array_values($classSet);
    if (function_exists('persian_usort_by')) persian_usort_by($classes, ['class_name']);

    $currentDefaultYear = get_setting('current_academic_year', '1404/1405');
    $years = get_academic_years_for_filter();
    $hasCurrYear = false;
    foreach ($years as $yrRow) {
        if (in_array($currentDefaultYear, report_year_variants($yrRow['academic_year'] ?? ''), true)) { $hasCurrYear = true; break; }
    }
    if (!$hasCurrYear && $currentDefaultYear !== '') {
        array_unshift($years, ['academic_year' => $currentDefaultYear]);
    }
    if (empty($years)) {
        $years = [['academic_year' => '1404/1405'], ['academic_year' => '1403/1404']];
    }

    $standardMonths = ['مهر','آبان','آذر','دی','بهمن','اسفند','فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','نوبت اول','نوبت دوم'];
    $monthMap = [];
    foreach ($standardMonths as $sm) $monthMap[$sm] = ['report_month' => $sm];
    foreach (DB::fetchAll("SELECT DISTINCT report_month FROM reports WHERE report_month IS NOT NULL AND report_month <> ''") ?: [] as $mr) {
        $mn = trim((string)$mr['report_month']);
        if ($mn !== '' && !isset($monthMap[$mn])) $monthMap[$mn] = ['report_month' => $mn];
    }
    ensure_report_locks_schema();
    /* V4.209.4 — دو لایهٔ جدا: مسدودیت گروهی (کلاس/ماه) و مسدودیت فردی (دانش‌آموز).
       آزادسازی گروهی فقط لایهٔ اول را برمی‌دارد، پس مدیر باید هر دو را جدا ببیند. */
    $activePreLocks = DB::fetchAll("SELECT rl.*, s.first_name, s.last_name FROM report_locks rl LEFT JOIN students s ON rl.student_id = s.id WHERE rl.is_locked = 1 ORDER BY rl.id DESC") ?: [];
    $groupLocks = []; $individualLocks = [];
    foreach ($activePreLocks as $apl) {
        if ((int)($apl['student_id'] ?? 0) > 0) $individualLocks[] = $apl; else $groupLocks[] = $apl;
    }
    $rowLocks = report_lock_node_holds('', '', '', 300);
    foreach ($activePreLocks as $apl) {
        $mn = trim((string)($apl['report_month'] ?? ''));
        if ($mn !== '' && !isset($monthMap[$mn])) $monthMap[$mn] = ['report_month' => $mn];
    }
    $months = array_values($monthMap);

    $students = DB::fetchAll("SELECT id, first_name, last_name, national_id, class_name FROM students WHERE status='active'");
    persian_usort_by($students, ['last_name','first_name']);   // v4.77.0: آ قبل از ا
?>
<div class="space-y-6">
    <div class="flex justify-between items-center">
        <div>
            <h2 class="text-2xl font-bold">مدیریت و نظارت بر کارنامه‌ها</h2>
            <p class="text-sm text-muted">مشاهده، مسدودسازی پیشینی یا گروهی ماه‌ها، خروجی اکسل و ثبت کارنامه</p>
        </div>
        <div class="flex gap-2">
            <a href="bulk-print.php" class="btn btn-primary gap-1 shadow text-xs"><svg data-ui-icon="print" class="school-icon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M7 8V3h10v5M7 17H3V9h18v8h-4M7 14h10v8H7ZM17 11h.1"/></svg> چاپ گروهی انتخابی (۱، ۲ یا ۴ در صفحه)</a>
            <button onclick="document.getElementById('bulkLockModal').style.display='flex'" class="btn btn-outline border-amber-500 text-amber-700 text-xs"><svg data-ui-icon="lock" class="school-icon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4" y="10" width="16" height="12" rx="2"/><path d="M7 10V6c0-6 10-6 10 0v4M12 15v3"/></svg> مسدودسازی پیشینی / گروهی ماه</button>
            <a href="reports.php?action=new" class="btn btn-success gap-1 text-xs">
                <span>+ ثبت دستی کارنامه</span>
            </a>
        </div>
    </div>

    <?php if (!empty($groupLocks) || !empty($individualLocks) || !empty($rowLocks)): ?>
    <div class="card p-4 border-amber-300 bg-amber-50 space-y-3">
        <?php if (!empty($groupLocks)): ?>
        <div class="space-y-2">
            <h3 class="font-bold text-sm text-amber-900 flex items-center gap-1">
                <svg data-ui-icon="lock" class="school-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4" y="10" width="16" height="12" rx="2"/><path d="M7 10V6c0-6 10-6 10 0v4M12 15v3"/></svg>
                ۱) مسدودیت گروهی — ماه‌ها و کلاس‌های مسدود برای دانش‌آموزان (دبیران همچنان می‌توانند نمره ثبت کنند):
            </h3>
            <div class="flex flex-wrap gap-2">
                <?php foreach ($groupLocks as $apl):
                    $scopeLbl = 'سال ' . ($apl['academic_year'] ?: 'همه سال‌ها') . ' — ماه «' . ($apl['report_month'] ?: 'همه ماه‌ها') . '»';
                    $scopeLbl .= !empty($apl['class_name']) ? (' — کلاس ' . $apl['class_name']) : ' — همه کلاس‌ها';
                ?>
                <div class="flex items-center gap-2 bg-white border border-amber-300 rounded-lg px-3 py-1.5 text-xs shadow-sm">
                    <span class="font-bold text-amber-900"><?php echo clean($scopeLbl); ?></span>
                    <?php if (!empty($apl['reason'])): ?>
                        <span class="text-muted">(<?php echo clean($apl['reason']); ?>)</span>
                    <?php endif; ?>
                    <a href="reports.php?action=unlock_rule&lock_id=<?php echo (int)$apl['id']; ?>" class="btn btn-secondary text-xs px-2 py-0.5 text-green-700 font-bold" onclick="return confirm('آیا مسدودیت گروهی این ماه/کلاس برداشته شود؟ مسدودیت‌های فردی دانش‌آموزان دست‌نخورده می‌مانند.')">آزادسازی گروهی 🔓</a>
                </div>
                <?php endforeach; ?>
            </div>
            <p class="text-[11px] text-amber-800">با آزادسازی گروهی، کارنامهٔ دانش‌آموزانی که مسدودیت فردی دارند (مثل بدهی مالی) همچنان مسدود می‌ماند.</p>
        </div>
        <?php endif; ?>

        <?php if (!empty($individualLocks)): ?>
        <div class="space-y-2">
            <h3 class="font-bold text-sm text-rose-900 flex items-center gap-1">
                <svg data-ui-icon="lock" class="school-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4" y="10" width="16" height="12" rx="2"/><path d="M7 10V6c0-6 10-6 10 0v4M12 15v3"/></svg>
                ۲) مسدودیت فردی — دانش‌آموزانی که جدا از گروه مسدود شده‌اند (با آزادسازی گروهی باز نمی‌شوند):
            </h3>
            <div class="flex flex-wrap gap-2">
                <?php foreach ($individualLocks as $apl):
                    $scopeLbl = 'سال ' . ($apl['academic_year'] ?: 'همه سال‌ها') . ' — ماه «' . ($apl['report_month'] ?: 'همه ماه‌ها') . '»';
                    $scopeLbl .= !empty($apl['class_name']) ? (' — کلاس ' . $apl['class_name']) : ' — همه کلاس‌ها';
                    $scopeLbl .= ' — دانش‌آموز: ' . (trim(($apl['first_name'] ?? '') . ' ' . ($apl['last_name'] ?? '')) ?: ('#' . (int)$apl['student_id']));
                ?>
                <div class="flex items-center gap-2 bg-white border border-rose-300 rounded-lg px-3 py-1.5 text-xs shadow-sm">
                    <span class="font-bold text-rose-900"><?php echo clean($scopeLbl); ?></span>
                    <?php if (!empty($apl['reason'])): ?>
                        <span class="text-muted">(<?php echo clean($apl['reason']); ?>)</span>
                    <?php endif; ?>
                    <a href="reports.php?action=unlock_rule&lock_id=<?php echo (int)$apl['id']; ?>" class="btn btn-secondary text-xs px-2 py-0.5 text-green-700 font-bold" onclick="return confirm('آیا مسدودیت فردی این دانش‌آموز برداشته شود؟')">رفع مسدودیت فردی 🔓</a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($rowLocks)): ?>
        <div class="space-y-2">
            <h3 class="font-bold text-sm text-slate-800 flex items-center gap-1">۳) قفل فردی روی خودِ کارنامه (بدون قاعده، از جدول کارنامه‌ها):</h3>
            <div class="flex flex-wrap gap-2">
                <?php foreach (array_slice($rowLocks, 0, 12) as $rl):
                    $rlLbl = trim((string)($rl['first_name'] ?? '') . ' ' . (string)($rl['last_name'] ?? ''));
                    if ($rlLbl === '') $rlLbl = '#' . (int)$rl['student_id'];
                    $rlLbl .= ' — ' . (($rl['term'] ?? '') !== '' ? $rl['term'] . ' / ' : '') . ($rl['report_month'] ?: '—');
                ?>
                <div class="flex items-center gap-2 bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs shadow-sm">
                    <span class="font-bold text-slate-800"><?php echo clean($rlLbl); ?></span>
                    <a href="reports.php?action=toggle_lock&id=<?php echo (int)$rl['id']; ?>" class="btn btn-secondary text-xs px-2 py-0.5 text-green-700 font-bold" onclick="return confirm('آیا قفل فردی این کارنامه برداشته شود؟')">آزادسازی 🔓</a>
                </div>
                <?php endforeach; ?>
                <?php if (count($rowLocks) > 12): ?>
                    <span class="text-xs text-muted">و <?php echo tr_num((string)(count($rowLocks) - 12), 'fa'); ?> مورد دیگر…</span>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Hierarchical Filter & Live Search Bar -->
    <div class="card p-4 shadow-md">
        <form method="GET" class="grid compact-filter-grid compact-filter-grid-5 items-end">
            <div>
                <label class="block text-xs font-semibold mb-1">۱. سال تحصیلی</label>
                <select name="year" class="form-select text-xs font-bold" onchange="this.form.submit()">
                    <option value="">همه سال‌ها</option>
                    <?php foreach ($years as $y): ?>
                        <option value="<?php echo clean($y['academic_year']); ?>" <?php echo $filterYear === $y['academic_year'] ? 'selected' : ''; ?>><?php echo clean($y['academic_year']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-xs font-semibold mb-1">۲. ماه / نوبت</label>
                <select name="month" class="form-select text-xs font-bold" onchange="this.form.submit()">
                    <option value="">همه ماه‌ها</option>
                    <?php foreach ($months as $m): ?>
                        <option value="<?php echo clean($m['report_month']); ?>" <?php echo $filterMonth === $m['report_month'] ? 'selected' : ''; ?>><?php echo clean($m['report_month']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-xs font-semibold mb-1">۳. کلاس</label>
                <select name="class_name" class="form-select text-xs font-bold" onchange="this.form.submit()">
                    <option value="">همه کلاس‌ها</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo clean($c['class_name']); ?>" <?php echo $filterClass === $c['class_name'] ? 'selected' : ''; ?>><?php echo clean($c['class_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-xs font-semibold mb-1">۴. جستجوی دانش‌آموز</label>
                <input type="text" name="student_query" class="form-input text-xs" placeholder="نام یا کد ملی..." value="<?php echo clean($filterStudent); ?>">
            </div>
            <div class="flex gap-1">
                <button type="submit" class="btn btn-primary w-full text-xs font-bold">فیلتر / جستجو</button>
                <?php if ($filterClass || $filterYear || $filterMonth || $filterStudent): ?>
                <a href="reports.php" class="btn btn-secondary text-xs px-2">حذف</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Reports Table -->
    <div class="card">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>شناسه</th>
                        <?php /* V4.213.0 — تصویر دانش‌آموز در ستون پیش از نام. */ ?>
                        <th class="text-center">تصویر</th>
                        <th>دانش‌آموز</th>
                        <th>کلاس</th>
                        <th>نوبت / ماه</th>
                        <th>معدل کل</th>
                        <th>وضعیت دسترسی</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reports as $rep):
                        $repLockReason = '';
                        $repLocked = is_report_locked_for_student($rep, $repLockReason);
                        if ($repLocked && function_exists('report_lock_reason_for')) $repLockReason = report_lock_reason_for($rep);
                    ?>
                    <tr>
                        <td class="font-mono text-xs">#<?php echo $rep['id']; ?></td>
                        <td class="text-center"><?php echo student_row_avatar($rep['photo_url'] ?? '', trim((string)$rep['first_name'] . ' ' . (string)$rep['last_name'])); ?></td>
                        <td class="font-bold"><?php echo clean($rep['first_name'] . ' ' . $rep['last_name']); ?></td>
                        <td><?php echo clean($rep['class_name']); ?></td>
                        <td><?php echo clean($rep['term'] . ' (' . $rep['report_month'] . ')'); ?></td>
                        <td><span class="badge badge-info text-sm"><?php echo format_score($rep['gpa']); ?></span></td>
                        <td>
                            <?php if ($repLocked): ?>
                                <span class="badge badge-danger">مسدود برای دانش‌آموز <svg data-ui-icon="lock" class="school-icon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4" y="10" width="16" height="12" rx="2"/><path d="M7 10V6c0-6 10-6 10 0v4M12 15v3"/></svg></span>
                                <?php if (trim((string)$repLockReason) !== ''): ?>
                                    <div class="text-[11px] text-muted mt-1" title="<?php echo clean($repLockReason); ?>">علت: <?php echo clean(mb_strlen($repLockReason) > 52 ? mb_substr($repLockReason, 0, 52) . '…' : $repLockReason); ?></div>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="badge badge-success">آزاد و قابل مشاهده <svg data-ui-icon="unlock" class="school-icon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4" y="10" width="16" height="12" rx="2"/><path d="M7 10V6c0-6 10-6 10 0M12 15v3"/></svg></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="flex gap-1 justify-end">
                                <a href="report-view.php?id=<?php echo $rep['id']; ?>" class="btn btn-primary text-xs px-2 py-1">مشاهده</a>
                                <a href="export-excel.php?id=<?php echo $rep['id']; ?>" class="btn btn-outline text-xs px-2 py-1 text-green-700">Excel</a>
                                <a href="export-pdf.php?id=<?php echo $rep['id']; ?>" class="btn btn-outline text-xs px-2 py-1 text-red-600">PDF</a>
                                <a href="reports.php?action=toggle_lock&id=<?php echo $rep['id']; ?>" class="btn btn-secondary text-xs px-2 py-1"
                                   onclick="return confirm('<?php echo $repLocked ? 'آیا مسدودیت فردی این دانش‌آموز برای این ماه برداشته شود؟' : 'این کارنامه به‌صورت فردی مسدود شود؟ با آزادسازی گروهی ماه/کلاس باز نمی‌شود.'; ?>')">
                                    <?php echo $repLocked ? 'رفع مسدودیت فردی' : 'مسدودیت فردی'; ?>
                                </a>
                                <a href="reports.php?action=edit&id=<?php echo $rep['id']; ?>" class="btn btn-secondary text-xs px-2 py-1">ویرایش</a>
                                <a href="reports.php?action=delete&id=<?php echo $rep['id']; ?>" onclick="return confirm('حذف این کارنامه؟')" class="btn btn-danger text-xs px-2 py-1">حذف</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; if (empty($reports)): ?>
                    <tr><td colspan="7" class="text-center text-muted">کارنامه‌ای یافت نشد.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Bulk Lock Modal -->
<div id="bulkLockModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5);">
    <div class="card max-w-md w-full p-6 shadow-xl">
        <h3 class="font-bold text-lg mb-4 text-amber-700"><svg data-ui-icon="lock" class="school-icon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4" y="10" width="16" height="12" rx="2"/><path d="M7 10V6c0-6 10-6 10 0v4M12 15v3"/></svg> مسدودسازی پیشینی یا آزادسازی گروهی کارنامه‌ها</h3>
        <p class="text-xs text-muted mb-2">می‌توانید حتی <b>پیش از ثبت نمرات توسط دبیران</b> و پیش از ساخته شدن کارنامه‌ها، ماه مورد نظر (مثلاً آبان) را برای همه کلاس‌ها یا یک کلاس مسدود کنید تا دبیران به مرور نمرات را ثبت کنند و پس از تکمیل تمام نمرات، کارنامه آن ماه را برای دانش‌آموزان آزاد نمایید.</p>
        <p class="text-xs mb-4 rounded-lg bg-amber-50 border border-amber-200 p-2 text-amber-900"><b>توجه:</b> آزادسازی گروهی فقط مسدودیت همان کلاس/ماه را برمی‌دارد. دانش‌آموزی که جداگانه (مثلاً به دلیل بدهی مالی) مسدود شده باشد <b>مسدود می‌ماند</b> و باید از بخش «مسدودیت فردی» بالا آزاد شود.</p>
        <form id="bulkLockForm" data-no-ajax="1" onsubmit="submitBulkLock(event)">
            <div class="mb-4">
                <label class="block text-xs font-semibold mb-1">انتخاب کلاس</label>
                <select id="bulkClass" class="form-select">
                    <option value="">همه کلاس‌ها</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo clean($c['class_name']); ?>"><?php echo clean($c['class_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-xs font-semibold mb-1">انتخاب دانش‌آموز خاص (اختیاری)</label>
                <select id="bulkStudent" class="form-select">
                    <option value="0">همه دانش‌آموزان فیلتر شده</option>
                    <?php foreach ($students ?? [] as $s): ?>
                        <option value="<?php echo (int)$s['id']; ?>"><?php echo clean($s['last_name'].'، '.$s['first_name'].' - '.$s['class_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="grid grid-cols-2 gap-2 mb-4">
                <div>
                    <label class="block text-xs font-semibold mb-1">سال تحصیلی</label>
                    <select id="bulkYear" class="form-select font-bold">
                        <?php foreach ($years as $y): ?>
                            <option value="<?php echo clean($y['academic_year']); ?>"><?php echo clean($y['academic_year']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold mb-1">ماه / نوبت</label>
                    <select id="bulkMonth" class="form-select font-bold">
                        <?php foreach ($months as $m): ?>
                            <option value="<?php echo clean($m['report_month']); ?>"><?php echo clean($m['report_month']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="mb-4">
                <label class="block text-xs font-semibold mb-1">عملیات مورد نظر</label>
                <select id="bulkIsLocked" class="form-select">
                    <option value="1">مسدود کردن مشاهده کارنامه (پیشینی / گروهی) 🔒</option>
                    <option value="0">آزادسازی و رفع مسدودیت 🔓</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-xs font-semibold mb-1">علت مسدودسازی (جهت نمایش به دانش‌آموز / اولیا)</label>
                <input type="text" id="bulkReason" class="form-input" value="در حال تکمیل نمرات توسط دبیران">
            </div>
            <label id="bulkIncludeWrap" class="hidden items-start gap-2 mb-6 text-xs bg-rose-50 border border-rose-200 rounded-lg p-2 text-rose-900" style="display:none">
                <input type="checkbox" id="bulkIncludeIndividual" class="mt-0.5">
                <span>آزادسازی کامل: مسدودیت‌های <b>فردی</b> این محدوده (مثل بدهی مالی) هم برداشته شود. اگر این تیک را نزنید، فقط مسدودیت گروهی برداشته می‌شود.</span>
            </label>
            <div class="flex justify-end gap-2">
                <button type="button" onclick="document.getElementById('bulkLockModal').style.display='none'" class="btn btn-secondary">انصراف</button>
                <button type="submit" class="btn btn-primary px-6">اعمال گروهی</button>
            </div>
        </form>
    </div>
</div>
<script>
/* V4.209.4 — تیک «آزادسازی کامل» فقط در حالت آزادسازی معنا دارد. */
(function () {
    var sel = document.getElementById('bulkIsLocked');
    var wrap = document.getElementById('bulkIncludeWrap');
    if (!sel || !wrap) return;
    var sync = function () {
        var unlocking = sel.value === '0';
        wrap.style.display = unlocking ? 'flex' : 'none';
        wrap.classList.toggle('hidden', !unlocking);
        if (!unlocking) { var cb = document.getElementById('bulkIncludeIndividual'); if (cb) cb.checked = false; }
    };
    sel.addEventListener('change', sync);
    sync();
})();
function submitBulkLock(e) {
    e.preventDefault();
    const formData = new URLSearchParams();
    formData.append('action', 'bulk_lock');
    formData.append('class_name', document.getElementById('bulkClass').value);
    formData.append('student_id', document.getElementById('bulkStudent').value);
    formData.append('academic_year', document.getElementById('bulkYear').value);
    formData.append('report_month', document.getElementById('bulkMonth').value);
    formData.append('is_locked', document.getElementById('bulkIsLocked').value);
    formData.append('reason', document.getElementById('bulkReason').value);
    var inc = document.getElementById('bulkIncludeIndividual');
    formData.append('include_individual', (inc && inc.checked) ? '1' : '0');

    fetch('admin-ajax.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString()
    }).then(r => r.json()).then(data => {
        if(data.status === 'success') {
            alert('عملیات با موفقیت انجام شد.');
            location.reload();
        } else {
            alert('خطایی رخ داد');
        }
    });
}
</script>
<?php endif; require_once __DIR__ . '/includes/footer.php'; ?>
