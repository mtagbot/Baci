<?php
return ['release'=>'Release_V1.4','distribution'=>'desktop','site_version'=>'4.208.0','desktop_version'=>'2.132.0'];
