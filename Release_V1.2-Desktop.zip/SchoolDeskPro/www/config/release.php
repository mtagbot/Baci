<?php
return ['release'=>'Release_V1.2','distribution'=>'desktop','site_version'=>'4.179.0','desktop_version'=>'2.103.0'];
