<?php
return ['release'=>'Release_V1.6','distribution'=>'site','site_version'=>'4.214.1','desktop_version'=>'2.138.1'];
