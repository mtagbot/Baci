<?php
return ['release'=>'Release_V1.15','distribution'=>'desktop','site_version'=>'4.221.0','desktop_version'=>'2.145.0'];
