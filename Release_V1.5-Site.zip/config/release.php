<?php
return ['release'=>'Release_V1.5','distribution'=>'site','site_version'=>'4.209.2','desktop_version'=>'2.133.2'];
