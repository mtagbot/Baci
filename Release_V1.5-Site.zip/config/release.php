<?php
return ['release'=>'Release_V1.5','distribution'=>'site','site_version'=>'4.213.0','desktop_version'=>'2.137.0'];
