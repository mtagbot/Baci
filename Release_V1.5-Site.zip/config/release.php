<?php
return ['release'=>'Release_V1.5','distribution'=>'site','site_version'=>'4.211.0','desktop_version'=>'2.135.0'];
