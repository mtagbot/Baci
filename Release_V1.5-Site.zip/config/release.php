<?php
return ['release'=>'Release_V1.5','distribution'=>'site','site_version'=>'4.209.4','desktop_version'=>'2.133.4'];
