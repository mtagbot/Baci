<?php
return ['release'=>'Release_V1.5','distribution'=>'site','site_version'=>'4.210.0','desktop_version'=>'2.134.0'];
