<?php
return ['release'=>'Release_V1.12','distribution'=>'site','site_version'=>'4.218.0','desktop_version'=>'2.142.0'];
