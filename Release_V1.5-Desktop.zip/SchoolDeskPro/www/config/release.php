<?php
return ['release'=>'Release_V1.5','distribution'=>'desktop','site_version'=>'4.209.0','desktop_version'=>'2.133.0'];
