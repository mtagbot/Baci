<?php
return ['release'=>'Release_V1.5','distribution'=>'desktop','site_version'=>'4.209.3','desktop_version'=>'2.133.3'];
