<?php
return ['release'=>'Release_V1.9','distribution'=>'desktop','site_version'=>'4.215.0','desktop_version'=>'2.139.0'];
