<?php
// File: includes/desk_sync.php  (SchoolDesk Pro — bidirectional auto-sync engine)
/**
 * Keeps the desktop SQLite database and the school's live MySQL website
 * in sync, automatically and in both directions.
 *
 * Design:
 *  - Every change on either side is recorded in a `desk_change_log`
 *    table (SQLite triggers here, MySQL triggers on the server —
 *    installed automatically by desk-sync-api.php).
 *  - The DESKTOP is always the initiator: it pushes its own changes and
 *    pulls the server's changes over plain HTTPS/HTTP JSON.
 *  - First run performs a full snapshot import from the server.
 *  - Conflicts: last-write-wins using the change timestamp.
 *  - While applying remote changes, local triggers are suppressed via
 *    the `desk_sync_suppress` marker table, so applied rows do not echo
 *    back to the server.
 *  - New desktop rows use IDs >= 5,000,000 (sqlite_sequence bump), so
 *    desktop-created and server-created rows can never collide.
 */

if (!defined('DESK_SYNC_TABLES')) {
    define('DESK_SYNC_TABLES', json_encode([
        'admins',
        'academic_years','teachers','discipline_titles','classes','subjects',
        'class_schedules','students','student_discipline_records','reports',
        'report_grades','report_locks','exam_schedules','exam_designs',
        'class_exam_groups','class_exam_group_members',
        'exam_question_bank','exam_design_archive','exam_assignments','exam_student_seating',
        'online_exam_categories','online_question_categories','online_question_bank',
        'online_exams','online_questions','online_exam_attempts','online_exam_answers',
        'grade_messages','counseling_requests','student_attendance','student_qr_tags',
        // bot integration: registrations, staff bot sessions, templates, logs —
        // so everything the site's Bale/Telegram/Rubika bots know is also on the desktop
        'bale_bot_users','telegram_bot_users','rubika_bot_users','bot_admin_sessions',
        'bot_message_templates','bot_button_templates','bot_login_tokens','bot_message_logs',
        // v2.11.0: full parity with the site dashboard — admin activity log,
        // notifications, SMS log and parent report reviews sync too
        'activity_logs','notifications','sms_logs','report_parent_reviews',
        'settings',
    ]));
}

class DeskSync {

    const ID_BASE = 5000000;      // desktop-created rows start here
    const BATCH   = 400;
    // Safety cycle for when BOTH sides are quiet. The daemon loops every few
    // seconds, so with a 120s cycle each system ran ~150 full cycles/day
    // (handshake + pull + file checks) even on an empty school day. 300s
    // keeps a 5-minute mirror guarantee while cutting those cycles 60%.
    const MIN_INTERVAL = 300;     // seconds between automatic safety runs
    const LOCK_TTL     = 180;     // stale-lock takeover
    const RECON_INTERVAL = 3600;  // v2.11.0: mirror-reconcile at most once per hour
    // Idle "any news on the site?" probe. One probe per daemon loop (≈5s) was
    // ~2,900 empty requests/day per system carrying only a change counter;
    // stretching it to 30s costs at most 25s of site→desktop visibility and
    // removes ~80% of idle traffic. Desktop→site pushes stay immediate
    // (kick file + pending>0 below), unaffected by this constant.
    const PING_INTERVAL = 30;     // seconds between idle site probes
    // "event" mode (desk_sync_mode='event', least-traffic option): no idle
    // probes and no 5-minute safety cycle — this hourly mirror check is the
    // only background work. Site-side edits still reach the desktop on the
    // next local edit (full cycles are bidirectional) or by the hourly check.
    const EVENT_SAFETY_INTERVAL = 3600;

    /* ---------------- settings helpers (raw, no cache) ---------------- */

    public static function getCfg($key, $default = '') {
        try {
            $r = DB::fetch("SELECT key_value FROM settings WHERE key_name = ?", [$key]);
            return $r ? (string)$r['key_value'] : $default;
        } catch (Throwable $e) { return $default; }
    }

    public static function setCfg($key, $value) {
        DB::execute("INSERT INTO settings (key_name, key_value) VALUES (?, ?)
                     ON DUPLICATE KEY UPDATE key_value = VALUES(key_value)", [$key, $value]);
    }

    public static function enabled() {
        return self::getCfg('desk_sync_enabled') === '1'
            && self::getCfg('desk_sync_url') !== ''
            && self::getCfg('desk_sync_key') !== '';
    }

    /* v2.12.0 — retry ladder (seconds) when the server cannot be reached,
       exactly per the user's spec:
       attempts 1-5 → every 10s, attempts 6-10 → every 20s,
       attempts 11+ → every 60s. After 5 one-minute attempts (i.e. from
       attempt 15 on) the UI shows a message asking the user to check the
       internet connection; retrying continues every minute forever. */
    public static function backoffDelay($fails) {
        if ($fails <= 5)  return 10;
        if ($fails <= 10) return 20;
        return 60;
    }

    public static function status() {
        return [
            'enabled'   => self::enabled(),
            'mode'      => self::getCfg('desk_sync_mode', 'full'),
            'url'       => self::getCfg('desk_sync_url'),
            'last_run'  => (int) self::getCfg('desk_sync_last', '0'),
            'last_ok'   => (int) self::getCfg('desk_sync_last_ok', '0'),
            'last_err'  => self::getCfg('desk_sync_err'),
            'cursor'    => (int) self::getCfg('desk_sync_cursor', '0'),
            'snapshot'  => self::getCfg('desk_sync_snapshot_done') === '1',
            'pushed'    => (int) self::getCfg('desk_sync_pushed', '0'),
            'pulled'    => (int) self::getCfg('desk_sync_pulled', '0'),
        ];
    }

    /** Separate idempotent handoff. Never mirror outbox delivery state as ordinary rows. */
    public static function relayBotNotifications() {
        require_once __DIR__.'/bot_helpers.php';
        if(!self::enabled())return;
        $next=(int)self::getCfg('desk_bot_outbox_next','0');
        if(time()<$next)return;
        $jobs=bot_outbox_relay_jobs();
        self::setCfg('desk_bot_outbox_next',(string)(time()+15));
        // Empty queue is the NORMAL state. Handing an empty batch to the site
        // was ~1,200 HTTP round-trips/day per system with nothing behind
        // them. New jobs are picked up on the next 15s cycle; nothing lost.
        if(!$jobs)return;
        try {
            $res=self::call('bot_outbox',['jobs'=>$jobs]);
            bot_outbox_apply_receipts($jobs,$res['receipts']??null);
            self::setCfg('desk_bot_outbox_error','');
        } catch(Throwable $e) {
            // Don't use bot API fallback: the server might already have accepted this batch.
            self::setCfg('desk_bot_outbox_next',(string)(time()+30));
            self::setCfg('desk_bot_outbox_error','تحویل صف اعلان به سایت انجام نشد؛ اتصال و نصب اصلاحی صف ربات روی سایت را بررسی کنید.');
        }
    }

    /* ---------------- HTTP ---------------- */

    private static $workingEndpoint = '';
    private static $workingMode = '';
    private static $workingBaseUrl = '';

    private static function alternateSyncEndpoint($url) {
        if (preg_match('~(^|/)desk-sync-api\.php(?=\?|$)~i', $url))
            return preg_replace('~(^|/)desk-sync-api\.php(?=\?|$)~i', '$1class-exam-sync-api.php', $url, 1);
        if (preg_match('~(^|/)class-exam-sync-api\.php(?=\?|$)~i', $url))
            return preg_replace('~(^|/)class-exam-sync-api\.php(?=\?|$)~i', '$1desk-sync-api.php', $url, 1);
        return null;
    }

    public static function candidateSyncEndpoints($url): array {
        $list = [$url];
        $alt = self::alternateSyncEndpoint($url);
        if ($alt && $alt !== $url) $list[] = $alt;
        foreach (['desk-connection-status.php', 'csrf-refresh.php', 'index.php'] as $relay) {
            $u = preg_replace('~[^/?]+\.php(?=\?|$)~i', $relay, $url, 1);
            if (is_string($u) && $u !== '' && !in_array($u, $list, true)) $list[] = $u;
        }
        return $list;
    }

    public static function encodeSyncToken(array $payload): string {
        $json = (string)json_encode($payload, JSON_UNESCAPED_UNICODE);
        $raw = function_exists('gzdeflate') ? @gzdeflate($json, 6) : false;
        $prefix = is_string($raw) && $raw !== '' ? 'z1' : 'b1';
        $bin = is_string($raw) && $raw !== '' ? $raw : $json;
        return $prefix . rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
    }

    private static function cookieJarPath(): string {
        return rtrim(sys_get_temp_dir(), '/\\') . '/sdp_sync_cookies.txt';
    }

    private static function browserHeaders($url, $contentType = 'application/x-www-form-urlencoded; charset=utf-8', string $profile = 'chrome'): array {
        $scheme = (string)parse_url($url, PHP_URL_SCHEME) ?: 'https';
        $host   = (string)parse_url($url, PHP_URL_HOST);
        $port   = parse_url($url, PHP_URL_PORT);
        $origin = $host !== '' ? ($scheme . '://' . $host . ($port ? ':' . $port : '')) : '';
        $ref    = preg_replace('~[^/?]+\.php(?:\?.*)?$~i', '', (string)$url);
        if ($profile === 'clean') {
            $headers = [
                'User-Agent: SchoolDeskPro/2.130',
                'Accept: */*',
                'Expect:',
            ];
            if ($contentType !== null && $contentType !== '') $headers[] = 'Content-Type: ' . $contentType;
            return $headers;
        }
        $headers = [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
            'Accept: ' . ($contentType === null ? 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' : 'application/json, text/plain, */*'),
            'Accept-Language: fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
            'Expect:',
        ];
        if ($contentType !== null && $contentType !== '') {
            $headers[] = 'Content-Type: ' . $contentType;
            $headers[] = 'X-Requested-With: XMLHttpRequest';
            if ($origin !== '') $headers[] = 'Origin: ' . $origin;
        }
        if (is_string($ref) && $ref !== '') $headers[] = 'Referer: ' . $ref;
        return $headers;
    }

    private static function isSyncJson($body): bool {
        if (!is_string($body) || $body === '') return false;
        $j = json_decode($body, true);
        return is_array($j) && array_key_exists('ok', $j);
    }

    private static function execSyncHttp(string $targetUrl, string $mode, array $payload, string $sdpZ, int $connectT, int $totalT, bool $secureOutbox, bool $directClean = false): array {
        $jar = self::cookieJarPath();
        $profile = $directClean ? 'clean' : 'chrome';
        $baseOpts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => $connectT,
            CURLOPT_TIMEOUT        => $totalT,
            CURLOPT_SSL_VERIFYPEER => $secureOutbox,
            CURLOPT_SSL_VERIFYHOST => $secureOutbox ? 2 : 0,
            CURLOPT_FOLLOWLOCATION => !$secureOutbox,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_COOKIEFILE     => $jar,
            CURLOPT_COOKIEJAR      => $jar,
        ];
        if (defined('CURLOPT_POSTREDIR')) $baseOpts[CURLOPT_POSTREDIR] = 7;
        if ($directClean) {
            if (defined('CURLOPT_PROXY')) $baseOpts[CURLOPT_PROXY] = '';
            if (defined('CURLOPT_NOPROXY')) $baseOpts[CURLOPT_NOPROXY] = '*';
            if (defined('CURLOPT_HTTP_VERSION') && defined('CURL_HTTP_VERSION_1_1')) $baseOpts[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
        }

        if ($mode === 'get_z') {
            $parts = str_split($sdpZ, 1800);
            $total = count($parts);
            $sep = strpos($targetUrl, '?') === false ? '?' : '&';
            if ($total <= 1) {
                $ch = curl_init($targetUrl . $sep . 'sdp_sync=1&sdp_z=' . $sdpZ);
                curl_setopt_array($ch, $baseOpts + [
                    CURLOPT_HTTPGET    => true,
                    CURLOPT_HTTPHEADER => self::browserHeaders($targetUrl, null, $profile),
                ]);
                $b = curl_exec($ch); $e = curl_error($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                if (!$directClean && ($b === false || $c === 403)) {
                    $retry = self::execSyncHttp($targetUrl, $mode, $payload, $sdpZ, $connectT, $totalT, $secureOutbox, true);
                    if ($retry['body'] !== false && ($retry['code'] === 200 || $b === false)) return $retry;
                }
                return ['body' => $b, 'err' => $e, 'code' => $c];
            }
            $cid = bin2hex(function_exists('random_bytes') ? random_bytes(8) : openssl_random_pseudo_bytes(8));
            $last = ['body' => false, 'err' => '', 'code' => 0];
            foreach ($parts as $idx => $part) {
                $q = 'sdp_sync=1&sdp_cid=' . $cid . '&sdp_ci=' . $idx . '&sdp_cn=' . $total . '&sdp_cp=' . $part;
                $ch = curl_init($targetUrl . $sep . $q);
                curl_setopt_array($ch, $baseOpts + [
                    CURLOPT_HTTPGET    => true,
                    CURLOPT_HTTPHEADER => self::browserHeaders($targetUrl, null, $profile),
                ]);
                $b = curl_exec($ch); $e = curl_error($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                $last = ['body' => $b, 'err' => $e, 'code' => $c];
                if ($b === false || $c !== 200 || !self::isSyncJson($b)) {
                    if (!$directClean && $idx === 0 && ($b === false || $c === 403)) {
                        return self::execSyncHttp($targetUrl, $mode, $payload, $sdpZ, $connectT, $totalT, $secureOutbox, true);
                    }
                    return $last;
                }
            }
            return $last;
        }

        if ($mode === 'post_z_chunked') {
            $parts = str_split($sdpZ, 28000);
            $total = count($parts);
            $cid = bin2hex(function_exists('random_bytes') ? random_bytes(8) : openssl_random_pseudo_bytes(8));
            $last = ['body' => false, 'err' => '', 'code' => 0];
            foreach ($parts as $idx => $part) {
                $postBody = 'sdp_sync=1&sdp_cid=' . $cid . '&sdp_ci=' . $idx . '&sdp_cn=' . $total . '&sdp_cp=' . $part;
                $ch = curl_init($targetUrl);
                curl_setopt_array($ch, $baseOpts + [
                    CURLOPT_POST       => true,
                    CURLOPT_POSTFIELDS => $postBody,
                    CURLOPT_HTTPHEADER => self::browserHeaders($targetUrl, 'application/x-www-form-urlencoded; charset=utf-8', $profile),
                ]);
                $b = curl_exec($ch); $e = curl_error($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                $last = ['body' => $b, 'err' => $e, 'code' => $c];
                if ($b === false || $c !== 200 || !self::isSyncJson($b)) return $last;
            }
            return $last;
        }

        $postFields = $mode === 'post_z'
            ? ('sdp_sync=1&sdp_z=' . $sdpZ)
            : ($mode === 'json'
                ? (string)json_encode($payload, JSON_UNESCAPED_UNICODE)
                : http_build_query(['payload' => json_encode($payload, JSON_UNESCAPED_UNICODE)], '', '&', PHP_QUERY_RFC3986));
        $ct = $mode === 'json' ? 'application/json' : 'application/x-www-form-urlencoded; charset=utf-8';
        $ch = curl_init($targetUrl);
        curl_setopt_array($ch, $baseOpts + [
            CURLOPT_POST       => true,
            CURLOPT_POSTFIELDS => $postFields,
            CURLOPT_HTTPHEADER => self::browserHeaders($targetUrl, $ct, $profile),
        ]);
        $b = curl_exec($ch); $e = curl_error($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if (!$directClean && ($b === false || $c === 403)) {
            $retry = self::execSyncHttp($targetUrl, $mode, $payload, $sdpZ, $connectT, $totalT, $secureOutbox, true);
            if ($retry['body'] !== false && ($retry['code'] === 200 || $b === false)) {
                $b = $retry['body']; $e = $retry['err']; $c = $retry['code'];
            }
        }
        if ($mode === 'post_z' && strlen($sdpZ) > 28000 && ($c === 403 || $c === 413 || $c === 500)) {
            return self::execSyncHttp($targetUrl, 'post_z_chunked', $payload, $sdpZ, $connectT, $totalT, $secureOutbox, $directClean);
        }
        return ['body' => $b, 'err' => $e, 'code' => $c];
    }

    private static function tryFallbackTransports(string $baseUrl, array $payload, string $sdpZ, int $connectT, int $totalT, bool $secureOutbox, array &$forbiddenBodies, bool &$siteUnpatched, array &$epStats = []): ?array {
        $candidates = self::candidateSyncEndpoints($baseUrl);
        // 1) Try WAF-safe compressed alphanumeric POST (`sdp_sync=1&sdp_z=z1...`) across all candidate endpoints.
        foreach ($candidates as $ep) {
            $shortName = basename((string)parse_url($ep, PHP_URL_PATH));
            $res = self::execSyncHttp($ep, 'post_z', $payload, $sdpZ, $connectT, $totalT, $secureOutbox);
            $epStats[$shortName . ':POST'] = (int)$res['code'];
            if ($res['code'] === 403 && $res['body'] !== false) $forbiddenBodies[] = $res['body'];
            if ($res['body'] !== false && $res['code'] === 200) {
                $j = json_decode((string)$res['body'], true);
                if (is_array($j) && array_key_exists('ok', $j)) {
                    if (empty($j['ok']) && strtolower((string)($j['error'] ?? '')) === 'bad request') {
                        // Server endpoint is reachable with Chrome headers, but older than v4.205.0 (does not know sdp_z).
                        $fRes = self::execSyncHttp($ep, 'form', $payload, $sdpZ, $connectT, $totalT, $secureOutbox);
                        if ($fRes['body'] !== false && $fRes['code'] === 200 && self::isSyncJson($fRes['body'])) {
                            $fj = json_decode((string)$fRes['body'], true);
                            if (empty($fj['ok']) && strtolower((string)($fj['error'] ?? '')) === 'bad request' && !$secureOutbox) {
                                $jRes = self::execSyncHttp($ep, 'json', $payload, $sdpZ, $connectT, $totalT, $secureOutbox);
                                if ($jRes['body'] !== false && $jRes['code'] === 200 && self::isSyncJson($jRes['body'])) {
                                    self::$workingEndpoint = $ep; self::$workingMode = 'json'; self::$workingBaseUrl = $baseUrl;
                                    return $jRes + ['url' => $ep];
                                }
                            }
                            self::$workingEndpoint = $ep; self::$workingMode = 'form'; self::$workingBaseUrl = $baseUrl;
                            return $fRes + ['url' => $ep];
                        }
                    } else {
                        self::$workingEndpoint = $ep; self::$workingMode = 'post_z'; self::$workingBaseUrl = $baseUrl;
                        return $res + ['url' => $ep];
                    }
                } elseif (preg_match('~/(?:index|csrf-refresh)\.php(?=\?|$)~i', $ep)) {
                    $siteUnpatched = true;
                }
            }
        }
        // 2) Warm up cookie jar via GET on index.php, then try GET transport (`?sdp_sync=1&sdp_z=z1...`).
        if (!$secureOutbox) {
            $indexUrl = preg_replace('~[^/?]+\.php(?=\?|$)~i', 'index.php', $baseUrl, 1);
            if (is_string($indexUrl) && $indexUrl !== '') {
                $jar = self::cookieJarPath();
                $ch = curl_init($indexUrl);
                $warmOpts = [
                    CURLOPT_HTTPGET        => true,
                    CURLOPT_HTTPHEADER     => self::browserHeaders($indexUrl, null, 'clean'),
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CONNECTTIMEOUT => $connectT,
                    CURLOPT_TIMEOUT        => $connectT + 2,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS      => 5,
                    CURLOPT_COOKIEFILE     => $jar,
                    CURLOPT_COOKIEJAR      => $jar,
                ];
                if (defined('CURLOPT_PROXY')) $warmOpts[CURLOPT_PROXY] = '';
                if (defined('CURLOPT_NOPROXY')) $warmOpts[CURLOPT_NOPROXY] = '*';
                curl_setopt_array($ch, $warmOpts);
                $warmBody = curl_exec($ch);
                $warmCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                if ($warmBody !== false && $warmCode === 200) $siteUnpatched = true;
            }
            foreach (array_reverse($candidates) as $ep) {
                $shortName = basename((string)parse_url($ep, PHP_URL_PATH));
                $res = self::execSyncHttp($ep, 'get_z', $payload, $sdpZ, $connectT, $totalT, $secureOutbox);
                $epStats[$shortName . ':GET'] = (int)$res['code'];
                if ($res['body'] !== false && $res['code'] === 200 && self::isSyncJson($res['body'])) {
                    $j = json_decode((string)$res['body'], true);
                    if (!(empty($j['ok']) && strtolower((string)($j['error'] ?? '')) === 'bad request')) {
                        self::$workingEndpoint = $ep; self::$workingMode = 'get_z'; self::$workingBaseUrl = $baseUrl;
                        return $res + ['url' => $ep];
                    }
                }
            }
        }
        return null;
    }

    private static function diagnose403Response($body) {
        $body = (string)$body;
        if (trim($body) === '') return 'بدنهٔ پاسخ خالی است';
        $plain = strtolower(strip_tags($body));
        if (strpos($plain, 'cloudflare') !== false || strpos($plain, 'cf-ray') !== false || strpos($plain, 'ray id') !== false)
            return 'نشانه‌های صفحهٔ Cloudflare یا WAF دیده شد';
        if (strpos($plain, 'mod_security') !== false || strpos($plain, 'modsecurity') !== false || strpos($plain, 'mod security') !== false)
            return 'نشانه‌های ModSecurity دیده شد';
        if (preg_match('~access denied|403 forbidden|request blocked|not authorized~i', $plain))
            return 'متن پاسخ شبیه صفحهٔ منع دسترسی وب‌سرور است';
        $json = json_decode($body, true);
        if (is_array($json) && isset($json['error'])) return 'پاسخ JSON با وضعیت 403 از برنامه یا پراکسی دریافت شد';
        return 'پاسخ 403 غیر JSON از وب‌سرور یا واسط دریافت شد';
    }

    private static function call($action, $payload = [], $fast = false) {
        /* v2.11.0: $fast = lightweight probes (ping). When the internet is
           down, the old 10s-connect + 40s-total timeouts held the desktop's
           single PHP worker hostage — every click in the app waited behind
           the stuck sync request. Probes now give up within seconds. */
        $connectT = $fast ? 4 : 6;
        $totalT   = $fast ? 6 : 40;
        $url = self::getCfg('desk_sync_url');
        // Companion endpoint preserves the original server's custom key/config file.
        $url = preg_replace('~[^/?]+\.php(?=\?|$)~','class-exam-sync-api.php',$url);
        $secureOutbox=$action==='bot_outbox';
        if($secureOutbox && strtolower((string)parse_url($url,PHP_URL_SCHEME))!=='https')throw new RuntimeException('Notification relay requires HTTPS');
        $payload['action'] = $action;
        $payload['key']    = self::getCfg('desk_sync_key');
        $sdpZ = self::encodeSyncToken($payload);

        if (self::$workingEndpoint !== '' && self::$workingMode !== '' && self::$workingBaseUrl === $url) {
            $cached = self::execSyncHttp(self::$workingEndpoint, self::$workingMode, $payload, $sdpZ, $connectT, $totalT, $secureOutbox);
            if ($cached['body'] !== false && $cached['code'] === 200 && self::isSyncJson($cached['body'])) {
                $j = json_decode((string)$cached['body'], true);
                if (empty($j['ok'])) throw new Exception('خطای سرور: ' . ($j['error'] ?? 'نامشخص'));
                return $j;
            }
            self::$workingEndpoint = ''; self::$workingMode = '';
        }

        $jar = self::cookieJarPath();
        $ch = curl_init($url);
        $primaryOpts = [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query(['payload' => json_encode($payload, JSON_UNESCAPED_UNICODE)], '', '&', PHP_QUERY_RFC3986),
            CURLOPT_HTTPHEADER     => self::browserHeaders($url, 'application/x-www-form-urlencoded; charset=utf-8'),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => $connectT,
            CURLOPT_TIMEOUT        => $totalT,
            CURLOPT_SSL_VERIFYPEER => $secureOutbox,
            CURLOPT_SSL_VERIFYHOST => $secureOutbox?2:0,
            CURLOPT_FOLLOWLOCATION => !$secureOutbox,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_COOKIEFILE     => $jar,
            CURLOPT_COOKIEJAR      => $jar,
        ];
        if (defined('CURLOPT_POSTREDIR')) $primaryOpts[CURLOPT_POSTREDIR] = 7;
        curl_setopt_array($ch, $primaryOpts);
        $body = curl_exec($ch);
        $err  = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        // https failed at connection level → retry once over plain http.
        // v2.11.0: skipped when DNS itself failed (device offline) — the
        // fallback could never succeed and only doubled the frozen time.
        if (!$secureOutbox && $body === false && stripos($url, 'https://') === 0 && stripos($err, 'resolve') === false) {
            $httpUrl = 'http://' . substr($url, 8);
            $ch = curl_init($httpUrl);
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => http_build_query(['payload' => json_encode($payload, JSON_UNESCAPED_UNICODE)], '', '&', PHP_QUERY_RFC3986),
                CURLOPT_HTTPHEADER     => self::browserHeaders($httpUrl, 'application/x-www-form-urlencoded; charset=utf-8'),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => $connectT,
                CURLOPT_TIMEOUT        => $totalT,
                CURLOPT_FOLLOWLOCATION => !$secureOutbox,
                CURLOPT_MAXREDIRS      => 5,
            ]);
            $body = curl_exec($ch);
            if ($body !== false) { $err = ''; $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); $url = $httpUrl; }
            curl_close($ch);
        }
        // Some hosts whitelist only one of these legacy/companion endpoint filenames.
        // On HTTP 403 try the paired filename once, preserving the scheme, query and same key.
        $forbiddenBodies = $code === 403 ? [$body] : [];
        if ($code === 403) {
            $alternateUrl = self::alternateSyncEndpoint($url);
            if ($alternateUrl && $alternateUrl !== $url) {
                $ch = curl_init($alternateUrl);
                $altOpts = [
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => http_build_query(['payload' => json_encode($payload, JSON_UNESCAPED_UNICODE)], '', '&', PHP_QUERY_RFC3986),
                    CURLOPT_HTTPHEADER => self::browserHeaders($alternateUrl, 'application/x-www-form-urlencoded; charset=utf-8'),
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CONNECTTIMEOUT => $connectT,
                    CURLOPT_TIMEOUT => $totalT,
                    CURLOPT_SSL_VERIFYPEER => $secureOutbox,
                    CURLOPT_SSL_VERIFYHOST => $secureOutbox ? 2 : 0,
                    CURLOPT_FOLLOWLOCATION => !$secureOutbox,
                    CURLOPT_MAXREDIRS => 5,
                    CURLOPT_COOKIEFILE => $jar,
                    CURLOPT_COOKIEJAR  => $jar,
                ];
                if (defined('CURLOPT_POSTREDIR')) $altOpts[CURLOPT_POSTREDIR] = 7;
                curl_setopt_array($ch, $altOpts);
                $altBody = curl_exec($ch);
                $altErr = curl_error($ch);
                $altCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                if ($altCode === 403 && $altBody !== false) $forbiddenBodies[] = $altBody;
                if ($altBody !== false && $altCode !== 403) {
                    $body = $altBody; $err = $altErr; $code = $altCode; $url = $alternateUrl;
                }
            }
        }
        $siteUnpatched = false;
        $epStats = [];
        if ($body !== false && ($code === 403 || $code !== 200 || !self::isSyncJson($body))) {
            $fb = self::tryFallbackTransports($url, $payload, $sdpZ, $connectT, $totalT, $secureOutbox, $forbiddenBodies, $siteUnpatched, $epStats);
            if ($fb !== null) {
                $body = $fb['body']; $err = $fb['err']; $code = $fb['code']; $url = $fb['url'];
            }
        }
        // A legacy endpoint may still parse only raw JSON and return its normal
        // application-level "bad request" JSON (HTTP 200) to the form envelope.
        // Retry that specific compatibility signal with the original JSON format.
        if (!$secureOutbox && $body !== false && $code === 200) {
            $firstReply = json_decode($body, true);
            if (is_array($firstReply) && strtolower((string)($firstReply['error'] ?? '')) === 'bad request') {
                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
                    CURLOPT_HTTPHEADER => self::browserHeaders($url, 'application/json'),
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CONNECTTIMEOUT => $connectT,
                    CURLOPT_TIMEOUT => $totalT,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS => 5,
                ]);
                $legacyBody = curl_exec($ch);
                $legacyErr = curl_error($ch);
                $legacyCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                if ($legacyBody !== false) { $body = $legacyBody; $err = $legacyErr; $code = $legacyCode; }
            }
        }
        if ($body === false) {
            $hint = '';
            if (stripos($err, 'resolve') !== false) {
                $host = parse_url($url, PHP_URL_HOST);
                $hint = ' — آدرس دامنه «' . $host . '» پیدا نشد؛ املای آدرس سایت را در تنظیمات بررسی کنید';
            }
            throw new Exception('اتصال به سرور برقرار نشد: ' . $err . $hint);
        }
        if ($code !== 200) {
            $hint = '';
            if ($code === 403) {
                $diagnosis = self::diagnose403Response(implode("\n", $forbiddenBodies));
                $statParts = [];
                foreach ($epStats as $k => $v) $statParts[] = $k . '=' . $v;
                $statText = $statParts ? (' [v2.130.0 | ' . implode(', ', $statParts) . ']') : ' [v2.130.0]';
                $patchNote = $siteUnpatched
                    ? ' خود سایت در دسترس است اما بستهٔ اصلاحی جدید سایت هنوز روی هاست جایگزین نشده است؛ فایل‌های بستهٔ اصلاحی سایت را در ریشهٔ هاست استخراج کنید تا همگام‌سازی از مسیر امن جایگزین انجام و سطح دسترسی فایل‌ها (0644) خودکار ترمیم شود.'
                    : '';
                $hint = ' — هر دو مسیر همگام‌سازی (desk-sync-api.php و class-exam-sync-api.php) با HTTP 403 رد شدند.' . $patchNote . ' در APIهای فعلی، کلید نادرست پاسخ HTTP 200 می‌دهد؛ پس این 403 احتمالاً پیش از اجرای API از وب‌سرور/WAF/قواعد دسترسی آمده است (' . $diagnosis . '). از میزبان بخواهید درخواست‌های POST با Content-Type: application/x-www-form-urlencoded را در access/error/WAF log بررسی کند؛ کلید را تغییر ندهید.' . $statText;
            }
            throw new Exception('پاسخ نامعتبر سرور (HTTP ' . $code . ')' . $hint);
        }
        $j = json_decode($body, true);
        if (!is_array($j))   throw new Exception('پاسخ سرور JSON نیست — آدرس desk-sync-api.php را بررسی کنید');
        if (empty($j['ok'])) throw new Exception('خطای سرور: ' . ($j['error'] ?? 'نامشخص'));
        return $j;
    }

    /* ---------------- local schema helpers ---------------- */

    private static function columns($tbl) {
        static $cache = [];
        if (!isset($cache[$tbl])) {
            $rows = DB::fetchAll("SELECT name FROM pragma_table_info(" . DB::getInstance()->getPdo()->quote($tbl) . ")");
            $cache[$tbl] = array_map(function ($r) { return $r['name']; }, $rows);
        }
        return $cache[$tbl];
    }

    private static function suppress($on) {
        if ($on) DB::execute("INSERT INTO desk_sync_suppress (flag) VALUES (1)");
        else     DB::execute("DELETE FROM desk_sync_suppress");
    }

    /**
     * Make desktop-created IDs collision-free vs server IDs.
     * A +1000 safety margin above the highest known ID means the server
     * can create up to 1000 new rows per table between two sync cycles
     * without ever colliding with a desktop-created row.
     */
    public static function bumpSequences() {
        $tables = json_decode(DESK_SYNC_TABLES, true);
        foreach ($tables as $t) {
            try {
                $max = DB::fetch("SELECT COALESCE(MAX(id),0) m FROM \"$t\"");
                $base = max(self::ID_BASE, (int)($max['m'] ?? 0) + 1000);
                $cur = DB::fetch("SELECT seq FROM sqlite_sequence WHERE name = ?", [$t]);
                if ($cur) {
                    if ((int)$cur['seq'] < $base) DB::execute("UPDATE sqlite_sequence SET seq = ? WHERE name = ?", [$base, $t]);
                } else {
                    DB::execute("INSERT INTO sqlite_sequence (name, seq) VALUES (?, ?)", [$t, $base]);
                }
            } catch (Throwable $e) { /* table without AUTOINCREMENT */ }
        }
    }

    /* self-heal: make sure every synced table has its local change triggers
       (covers databases created by an older version of the app) */
    public static function ensureLocalTriggers() {
        $tables = json_decode(DESK_SYNC_TABLES, true);
        foreach ($tables as $t) {
            if ($t === 'settings') continue; // has custom key_name triggers in the schema
            try {
                $have = DB::fetch("SELECT COUNT(*) c FROM sqlite_master WHERE type='trigger' AND name = ?", ["trg_sync_{$t}_i"]);
                if ((int)($have['c'] ?? 0) > 0) continue;
                $exists = DB::fetch("SELECT COUNT(*) c FROM sqlite_master WHERE type='table' AND name = ?", [$t]);
                if ((int)($exists['c'] ?? 0) === 0) continue;
                foreach ([['i','INSERT','NEW'], ['u','UPDATE','NEW'], ['d','DELETE','OLD']] as $x) {
                    list($suf, $evt, $ref) = $x;
                    DB::getInstance()->getPdo()->exec(
                        "CREATE TRIGGER IF NOT EXISTS trg_sync_{$t}_{$suf} AFTER {$evt} ON \"{$t}\"\n" .
                        "WHEN NOT EXISTS (SELECT 1 FROM desk_sync_suppress)\n" .
                        "BEGIN INSERT INTO desk_change_log(tbl,rid,op,ts) VALUES ('{$t}', {$ref}.id, '" . substr($evt, 0, 1) . "', strftime('%s','now')); END"
                    );
                }
            } catch (Throwable $e) { /* ignore */ }
        }
    }

    /* ---------------- apply one remote change locally ---------------- */

    private static function pkCol($tbl) {
        return $tbl === 'settings' ? 'key_name' : 'id';
    }

    /* settings keys that must stay local (sync/runtime state, not school data) */
    private static function settingsLocal($key) {
        return strpos((string)$key, 'desk_') === 0;
    }

    private static function applyChange($c) {
        $tbl = $c['tbl']; $rid = $c['rid']; $op = $c['op'];
        $tables = json_decode(DESK_SYNC_TABLES, true);
        if (!in_array($tbl, $tables, true)) return;
        if ($tbl === 'settings' && self::settingsLocal($rid)) return;
        $pk = self::pkCol($tbl);
        if ($op === 'D' || empty($c['row'])) {
            DB::execute("DELETE FROM \"$tbl\" WHERE \"$pk\" = ?", [$rid]);
            return;
        }
        $row  = $c['row'];
        if(in_array($tbl,['class_exam_groups','class_exam_group_members'],true)){require_once __DIR__.'/class_exam_groups.php';if(ceg_sync_conflict($tbl,$row))throw new RuntimeException('تعارض گروه آزمون سایت و دسکتاپ؛ گروه‌های هم‌زمان خودکار ادغام یا حذف نمی‌شوند.');}
        $cols = array_values(array_intersect(self::columns($tbl), array_keys($row)));
        if (!$cols) return;
        $ph   = implode(',', array_fill(0, count($cols), '?'));
        $cl   = '"' . implode('","', $cols) . '"';
        $vals = [];
        foreach ($cols as $col) $vals[] = $row[$col];
        DB::execute("REPLACE INTO \"$tbl\" ($cl) VALUES ($ph)", $vals);
    }

    /* ---------------- collect local changes to push ---------------- */

    private static function collectLocal($limit) {
        $rows = DB::fetchAll("SELECT id, tbl, rid, op, ts FROM desk_change_log ORDER BY id ASC LIMIT " . (int)$limit);
        if (!$rows) return [[], 0];
        $tables = json_decode(DESK_SYNC_TABLES, true);
        $latest = []; $maxId = 0;
        foreach ($rows as $r) {
            $maxId = max($maxId, (int)$r['id']);
            if (!in_array($r['tbl'], $tables, true)) continue;
            if ($r['tbl'] === 'settings' && self::settingsLocal($r['rid'])) continue;
            $latest[$r['tbl'] . '|' . $r['rid']] = $r;          // later entries overwrite
        }
        $changes = [];
        foreach ($latest as $r) {
            $c = ['tbl' => $r['tbl'], 'rid' => $r['rid'], 'op' => $r['op'], 'ts' => (int)$r['ts']];
            if ($r['op'] !== 'D') {
                $pk = self::pkCol($r['tbl']);
                $row = DB::fetch("SELECT * FROM \"{$r['tbl']}\" WHERE \"$pk\" = ?", [$r['rid']]);
                if ($row) { $c['op'] = 'U'; $c['row'] = $row; }
                else      { $c['op'] = 'D'; }
            }
            $changes[] = $c;
        }
        return [$changes, $maxId];
    }

    /* ---------------- main cycle ---------------- */

    public static function runIfDue() {
        if (!self::enabled()) return ['ok' => false, 'skipped' => 'disabled'];
        $last = (int) self::getCfg('desk_sync_last', '0');
        $safety = self::getCfg('desk_sync_mode', 'full') === 'event'
            ? self::EVENT_SAFETY_INTERVAL : self::MIN_INTERVAL;
        if (time() - $last < $safety) return ['ok' => true, 'skipped' => 'recent'];
        return self::run();
    }

    /** rows waiting to be pushed to the site */
    public static function pendingCount() {
        try {
            $r = DB::fetch("SELECT COUNT(*) c FROM desk_change_log");
            return (int)($r['c'] ?? 0);
        } catch (Throwable $e) { return 0; }
    }

    /**
     * Real-time heartbeat (called every few seconds by the daemon/UI):
     *  - pushes local changes IMMEDIATELY after any edit,
     *  - pulls site changes within ~30s (a throttled `ping` checks the site's
     *    change counter; a full cycle runs only when something is new or the
     *    5-minute safety interval has passed),
     *  - when offline, retries on the 10s/20s/60s ladder and keeps every
     *    change safely in the local change-log until the connection is back.
     */
    public static function tick() {
        if (!self::enabled()) return ['ok' => false, 'skipped' => 'disabled', 'pending' => 0, 'fails' => 0, 'alert' => false];
        $now     = time();
        $pending = self::pendingCount();
        $fails   = (int) self::getCfg('desk_sync_fails', '0');
        $nextTry = (int) self::getCfg('desk_sync_next_try', '0');
        $base    = ['pending' => $pending, 'fails' => $fails, 'alert' => $fails >= 15,
                    'retry_in' => max(0, $nextTry - $now), 'server_verified' => false];

        // offline back-off window still open → wait
        if ($fails > 0 && $now < $nextTry) return ['ok' => true, 'skipped' => 'backoff'] + $base;

        $due = $pending > 0 || self::getCfg('desk_sync_snapshot_done') !== '1';
        // "event" mode: no idle probes at all — the desktop talks to the
        // site only when something changed, plus the hourly mirror check
        // below. (Mode selector lives on the sync settings page.)
        $event = self::getCfg('desk_sync_mode', 'full') === 'event';

        // nothing to push → ask the site (cheap) whether IT has news.
        // The probe is throttled to PING_INTERVAL (30s): the desktop→site
        // direction is unaffected (pending>0 below runs a full cycle
        // immediately, kicked within a second of any edit), and a change made
        // ON THE SITE is still noticed within one probe. The success
        // timestamp only advances on a GOOD probe, so the offline back-off
        // ladder still controls retry timing after an outage.
        if (!$due && !$event) {
            $lastPing = (int) self::getCfg('desk_sync_ping_last', '0');
            if ($now - $lastPing >= self::PING_INTERVAL) {
                try {
                    $res = self::call('ping', [], true);
                    if (!isset($res['log_max']) || !is_numeric($res['log_max']) || $res['log_max'] < 0) throw new Exception('پاسخ بررسی سرور معتبر نیست');
                    self::setCfg('desk_sync_ping_last', (string)$now);
                    /* v2.107.0: persist the proof of a *real* site answer.
                       Only `run()` used to record it, and full cycles are rare
                       (300s safety cycle), so the idle heartbeat carried
                       server_verified=false almost always and the connection
                       monitor flipped back to «در انتظار وضعیت همگامسازی»
                       within seconds — while the site was perfectly reachable
                       and the manual button worked. Now one good probe keeps
                       the flag true for the next 60s (recency check below),
                       i.e. for the whole 30s probe cadence. */
                    self::setCfg('desk_sync_verified_at', (string)$now);
                    $base['server_verified'] = true;
                    $base['fails'] = 0; $base['alert'] = false; $base['retry_in'] = 0;
                    if ((int)($res['log_max'] ?? 0) > (int) self::getCfg('desk_sync_cursor', '0')) $due = true;
                    if ($fails > 0) { self::setCfg('desk_sync_fails', '0'); self::setCfg('desk_sync_next_try', '0'); $fails = 0; }
                } catch (Throwable $e) {
                    if (self::isOffline($e)) return self::noteFailure($now) + ['ok' => true, 'skipped' => 'offline', 'pending' => $pending];
                    // A rejected/unsupported ping is not proof of a healthy connection.
                    $base['probe_failed'] = true;
                    // old server file (no ping action) → fall back to the periodic cycle
                    $due = ($now - (int) self::getCfg('desk_sync_last', '0')) >= self::MIN_INTERVAL;
                }
            }
        }

        // A probe or full cycle that verified the site within the last minute
        // still counts as verified, so the 15s notification-handoff cadence
        // does not have to wait for the next 30s probe. The guard remains:
        // nothing is handed off without a recently verified mirror and zero
        // unpushed local changes.
        if (!$base['server_verified'] && ($now - (int) self::getCfg('desk_sync_verified_at', '0')) < 60) $base['server_verified'] = true;

        // periodic safety cycle even when both sides look quiet
        // (event mode relaxes it to the hourly mirror check)
        $safety = $event ? self::EVENT_SAFETY_INTERVAL : self::MIN_INTERVAL;
        if (!$due && ($now - (int) self::getCfg('desk_sync_last', '0')) >= $safety) $due = true;

        if (!$due) return ['ok' => true, 'skipped' => 'idle'] + $base;

        $res = self::run();
        $pending = self::pendingCount();
        if (!empty($res['ok'])) {
            self::setCfg('desk_sync_fails', '0');
            self::setCfg('desk_sync_next_try', '0');
            if (!isset($res['skipped'])) self::setCfg('desk_sync_verified_at', (string)$now);
            /* A cycle that was skipped (e.g. another worker held the lock) is
               not proof by itself, but a proof recorded moments ago stays
               valid — the panel must not flash «در انتظار…» during a lock. */
            return $res + ['pending' => $pending, 'fails' => 0, 'alert' => false, 'retry_in' => 0,
                            'server_verified' => !isset($res['skipped']) || $base['server_verified']];
        }
        if (isset($res['error']) && mb_strpos((string)$res['error'], 'اتصال به سرور برقرار نشد') !== false) {
            return self::noteFailure($now) + $res + ['pending' => $pending];
        }
        return $res + ['pending' => $pending, 'fails' => $fails, 'alert' => $fails >= 15, 'retry_in' => 0];
    }

    private static function isOffline(Throwable $e) {
        return mb_strpos($e->getMessage(), 'اتصال به سرور برقرار نشد') !== false;
    }

    /** register one failed attempt and schedule the next one on the ladder */
    private static function noteFailure($now) {
        $fails = (int) self::getCfg('desk_sync_fails', '0') + 1;
        $delay = self::backoffDelay($fails);
        self::setCfg('desk_sync_fails', (string)$fails);
        self::setCfg('desk_sync_next_try', (string)($now + $delay));
        self::setCfg('desk_sync_err', 'اتصال به سرور برقرار نشد — تلاش بعدی تا ' . $delay . ' ثانیه دیگر (تلاش ' . $fails . ')');
        return ['fails' => $fails, 'alert' => $fails >= 15, 'retry_in' => $delay];
    }

    /**
     * v2.11.0: mirror reconcile — the guarantee that desktop and site are
     * IDENTICAL, not just "no missed events". Compares a cheap per-table
     * fingerprint (row count + sum of ids) with the server; any table that
     * differs (leftover demo rows, rows changed before the sync file was
     * installed, a missed trigger, a crash mid-import...) is wiped and
     * re-imported from the site in full. Runs on every manual sync and
     * automatically at most once per hour. Tables with unpushed local
     * changes are skipped — user data is never thrown away.
     */
    private static function reconcile(&$pulled) {
        $sum = self::call('recon');                    // old server file → exception, caught by caller
        $srv = $sum['tables'] ?? [];
        $fixed = [];
        foreach (json_decode(DESK_SYNC_TABLES, true) as $tbl) {
            if (!isset($srv[$tbl])) continue;          // server file older than this table
            $pk = self::pkCol($tbl);
            try {
                $pending = DB::fetch("SELECT 1 x FROM desk_change_log WHERE tbl = ? LIMIT 1", [$tbl]);
                if ($pending) continue;                // unpushed local edits — never overwrite
                if ($pk === 'id') {
                    $loc = DB::fetch("SELECT COUNT(*) n, COALESCE(SUM(id),0) s FROM \"$tbl\"");
                    $same = ((int)$loc['n'] === (int)($srv[$tbl]['n'] ?? -1))
                         && ((string)(int)$loc['s'] === (string)(int)($srv[$tbl]['s'] ?? -1));
                } else {                               // settings: count of non-desk keys
                    $loc = DB::fetch("SELECT COUNT(*) n FROM \"$tbl\" WHERE key_name NOT LIKE 'desk!_%' ESCAPE '!'");
                    $same = ((int)$loc['n'] === (int)($srv[$tbl]['n'] ?? -1));
                }
                if ($same) continue;
                // ---- mismatch → wipe + full re-import of this one table ----
                $aft = ($pk === 'id') ? 0 : '';
                $first = true;
                do {
                    $res  = self::call('snapshot', ['tbl' => $tbl, 'after' => $aft, 'limit' => self::BATCH]);
                    $rows = $res['rows'] ?? [];
                    self::suppress(true);
                    try {
                        if ($first) {
                            if ($tbl === 'admins' && !$rows) break; // never lock the user out
                            if ($tbl === 'settings') DB::execute("DELETE FROM \"settings\" WHERE key_name NOT LIKE 'desk!_%' ESCAPE '!'");
                            else                     DB::execute("DELETE FROM \"$tbl\"");
                            $first = false;
                        }
                        foreach ($rows as $row) {
                            if (!isset($row[$pk])) continue;
                            self::applyChange(['tbl' => $tbl, 'rid' => $row[$pk], 'op' => 'U', 'row' => $row]);
                            $aft = ($pk === 'id') ? max((int)$aft, (int)$row[$pk]) : max((string)$aft, (string)$row[$pk]);
                            $pulled++;
                        }
                    } finally { self::suppress(false); }
                } while (count($rows) >= self::BATCH);
                try { DB::execute("DELETE FROM desk_change_log WHERE tbl = ?", [$tbl]); } catch (Throwable $e) {}
                $fixed[] = $tbl;
            } catch (Throwable $e) {
                if (mb_strpos($e->getMessage(), 'اتصال به سرور') !== false) throw $e; // offline → stop
                /* per-table problem: keep reconciling the rest */
            }
        }
        if ($fixed) self::bumpSequences();
        self::setCfg('desk_sync_recon_last', (string) time());
        return $fixed;
    }

    /* ---------------- v2.12.0: file mirror ----------------
     * Rows alone are not enough — an exam design saved on the SITE points
     * to files: the uploaded source PDF/image (question_file), the
     * server-converted page images (uploads/exams/pdf-pages/exam_N/...),
     * student photos and the exam stamp. Without them the desktop opens
     * the design with empty pages. This mirrors every referenced file in
     * BOTH directions (site⇄desktop): newer/missing files are transferred,
     * mtimes preserved, everything locked inside uploads/. */

    private static function safeRel($p) {
        $p = str_replace('\\', '/', trim((string)$p));
        $p = ltrim($p, '/');
        if ($p === '' || strpos($p, '..') !== false || strpos($p, "\0") !== false) return '';
        if (strpos($p, 'uploads/') !== 0) return '';
        return $p;
    }

    /* v2.13.0 — reverse design path: an exam designed ON THE DESKTOP with a
     * PDF source cannot be converted to page images locally (the portable
     * app ships no Imagick/Ghostscript). This pushes the PDF to the site,
     * asks the site to convert it (action exam_pages — same rendering code
     * the site itself uses), then pulls the generated page images back.
     * Returns the local relative page paths, or [] when offline/unavailable.
     */
    public static function remoteExamPdfPages($examId, $relPath, $declaredPages = 0, $selectedPages = []) {
        if (!self::enabled()) return [];
        $examId = (int)$examId;
        $rel = self::safeRel($relPath);
        if ($examId <= 0 || $rel === '') return [];
        $root = dirname(__DIR__);
        $full = $root . '/' . $rel;
        if (!is_file($full) || filesize($full) > 25 * 1024 * 1024) return [];
        try {
            // 1) make sure the PDF itself is on the site (the row may not have
            //    synced yet — file_put is idempotent and cheap to repeat)
            self::call('file_put', ['path' => $rel,
                'b64' => base64_encode((string)file_get_contents($full)),
                'm'   => (int)filemtime($full)]);
            // 2) the site needs the exam row to know question_file → push
            //    pending changes first so exam_schedules is up to date there
            try { self::run(true); } catch (Throwable $e) { /* best effort */ }
            // 3) convert on the site (path passed too, in case the exam row
            //    itself has not reached the site yet)
            $res = self::call('exam_pages', ['exam_id' => $examId, 'declared_pages' => (int)$declaredPages, 'path' => $rel,
                'selected_pages' => implode(',', array_map('intval', (array)$selectedPages))]); /* v4.101.0 */
            $pages = [];
            foreach ((array)($res['pages'] ?? []) as $p) {
                $pRel = self::safeRel($p);
                if ($pRel === '') continue;
                // 4) pull each page image down
                $g = self::call('file_get', ['path' => $pRel]);
                $data = base64_decode((string)($g['b64'] ?? ''), true);
                if ($data === false) continue;
                $pFull = $root . '/' . $pRel;
                $dir = dirname($pFull);
                if (!is_dir($dir)) @mkdir($dir, 0777, true);
                if (@file_put_contents($pFull, $data) !== false) {
                    // force mtime NEWER than the local pdf so the print page's
                    // cache check never discards these (clock skew safe)
                    @touch($pFull, time() + 1);
                    $pages[] = $pRel;
                }
            }
            sort($pages);
            return $pages;
        } catch (Throwable $e) {
            return []; // offline → caller shows the existing warning; the
                       // pages will be produced next time sync succeeds
        }
    }

    private static function fileSyncTargets() {
        $paths = []; $dirs = [];
        try {
            foreach (DB::fetchAll("SELECT id, question_file FROM exam_schedules WHERE question_file IS NOT NULL AND question_file != ''") as $r) {
                $rel = self::safeRel($r['question_file']);
                if ($rel !== '') {
                    /* v4.94.0: بعد از تبدیل، PDF منبع از هاست حذف می‌شود؛ اگر تصاویر
                       صفحات موجود است، خود PDF دیگر همگام/آپلود نمی‌شود تا به هاست برنگردد. */
                    $isPdf = strtolower(pathinfo($rel, PATHINFO_EXTENSION)) === 'pdf';
                    $hasPages = $isPdf && (glob(dirname(__DIR__) . '/uploads/exams/pdf-pages/exam_' . (int)$r['id'] . '/page_*.jpg') ?: []);
                    if (!$hasPages) $paths[] = $rel;
                    $dirs[] = 'uploads/exams/pdf-pages/exam_' . (int)$r['id'];
                }
            }
        } catch (Throwable $e) {}
        /* v4.99.0: بایگانی نسخه‌های قبلی بانک هم بین سایت و دسکتاپ همگام می‌شود */
        try {
            foreach (DB::fetchAll("SELECT id FROM exam_design_archive") as $r) {
                $dirs[] = 'uploads/exams/bank-archive/' . (int)$r['id'];
            }
        } catch (Throwable $e) {}
        try {
            foreach (DB::fetchAll("SELECT photo_url FROM students WHERE photo_url LIKE 'uploads/%'") as $r) {
                $rel = self::safeRel($r['photo_url']);
                if ($rel !== '') $paths[] = $rel;
            }
        } catch (Throwable $e) {}
        foreach (['principal_signature_url','school_stamp_url','exam_stamp_url','school_logo_url','report_stamp_url'] as $k) {
            $rel = self::safeRel(self::getCfg($k, ''));
            if ($rel !== '') $paths[] = $rel;
        }
        return [array_values(array_unique($paths)), array_values(array_unique($dirs))];
    }

    private static function fileSync(&$warn) {
        $root = dirname(__DIR__);                      // www/
        list($paths, $dirs) = self::fileSyncTargets();
        if (!$paths && !$dirs) return 0;

        $srv = [];                                     // rel => ['s'=>size,'m'=>mtime] (s=-1 missing)
        if ($dirs) {
            $res = self::call('files_list', ['dirs' => $dirs]);
            foreach (($res['dirs'] ?? []) as $rel => $files) {
                foreach ((array)$files as $f) {
                    if (!empty($f['p'])) $srv[$f['p']] = ['s' => (int)$f['s'], 'm' => (int)$f['m']];
                }
            }
            // local page images whose dir exists on the server list are known;
            // also mirror desktop-only page images upward (dir scan below).
            foreach ($dirs as $d) {
                $full = $root . '/' . $d;
                if (!is_dir($full)) continue;
                foreach (scandir($full) ?: [] as $fn) {
                    if ($fn === '' || $fn[0] === '.') continue;
                    if (is_file($full . '/' . $fn)) $paths[] = $d . '/' . $fn;
                }
            }
        }
        $paths = array_values(array_unique($paths));
        $need = array_values(array_diff($paths, array_keys($srv)));
        for ($i = 0; $i < count($need); $i += 500) {
            $res = self::call('files_stat', ['paths' => array_slice($need, $i, 500)]);
            foreach (($res['files'] ?? []) as $rel => $st) $srv[$rel] = ['s' => (int)$st['s'], 'm' => (int)$st['m']];
        }
        // include server-side files we did not reference locally (dir listing already did that)
        foreach (array_keys($srv) as $rel) if (!in_array($rel, $paths, true)) $paths[] = $rel;

        $moved = 0; $down = 0; $up = 0;
        foreach ($paths as $rel) {
            if ($down >= 40 && $up >= 10) break;       // cap per cycle; next cycle continues
            $st = $srv[$rel] ?? ['s' => -1, 'm' => 0];
            $full = $root . '/' . $rel;
            $locS = is_file($full) ? (int)filesize($full) : -1;
            $locM = is_file($full) ? (int)filemtime($full) : 0;
            $differs = ($st['s'] >= 0 && $locS >= 0 && $st['s'] !== $locS);
            if ($st['s'] >= 0 && ($locS < 0 || ($differs && $st['m'] >= $locM))) {
                // server has it and local is missing/older → download
                if ($down >= 40) continue;
                if ($st['s'] > 25 * 1024 * 1024) continue;
                try {
                    $res = self::call('file_get', ['path' => $rel]);
                    $data = base64_decode((string)($res['b64'] ?? ''), true);
                    if ($data !== false) {
                        $dir = dirname($full);
                        if (!is_dir($dir)) @mkdir($dir, 0777, true);
                        if (@file_put_contents($full, $data) !== false) {
                            if (!empty($res['m'])) @touch($full, (int)$res['m']);
                            $moved++; $down++;
                        }
                    }
                } catch (Throwable $e) {
                    if (self::isOffline($e)) throw $e;
                }
            } elseif ($locS >= 0 && ($st['s'] < 0 || ($differs && $locM > $st['m']))) {
                // desktop-only or desktop-newer file (uploaded here while offline) → push to site
                if ($up >= 10) continue;
                if ($locS > 25 * 1024 * 1024) continue;
                try {
                    self::call('file_put', ['path' => $rel, 'b64' => base64_encode((string)file_get_contents($full)), 'm' => $locM]);
                    $moved++; $up++;
                } catch (Throwable $e) {
                    if (self::isOffline($e)) throw $e;
                }
            }
        }
        if ($moved) self::setCfg('desk_files_synced', (string)((int)self::getCfg('desk_files_synced', '0') + $moved));
        return $moved;
    }

    public static function bridgeInit(): array {
        require_once __DIR__ . '/class_exam_groups.php';
        ensure_exams_schema(); ceg_schema();
        self::ensureLocalTriggers();
        self::bumpSequences();
        $url = self::getCfg('desk_sync_url');
        $key = self::getCfg('desk_sync_key');
        $hsPayload = ['action' => 'handshake', 'key' => $key];
        $bridgeUrl = preg_replace('~[^/?]+\.php(?:\?.*)?$~i', 'index.php?sdp_sync=1&sdp_bridge=1', $url, 1);
        return [
            'ok' => true,
            'url' => $url,
            'bridge_url' => is_string($bridgeUrl) ? $bridgeUrl : ($url . '?sdp_sync=1&sdp_bridge=1'),
            'endpoints' => self::candidateSyncEndpoints($url),
            'cursor' => (int)self::getCfg('desk_sync_cursor', '0'),
            'pending' => self::pendingCount(),
            'handshake_z' => self::encodeSyncToken($hsPayload),
            'handshake_payload' => (string)json_encode($hsPayload, JSON_UNESCAPED_UNICODE),
        ];
    }

    public static function bridgeNextPull(): array {
        $cursor = (int)self::getCfg('desk_sync_cursor', '0');
        $p = ['action' => 'pull', 'cursor' => $cursor, 'limit' => 250, 'key' => self::getCfg('desk_sync_key')];
        return [
            'ok' => true,
            'cursor' => $cursor,
            'sdp_z' => self::encodeSyncToken($p),
            'payload' => (string)json_encode($p, JSON_UNESCAPED_UNICODE),
        ];
    }

    public static function bridgeApplyPull(array $res): array {
        $cursor = (int)self::getCfg('desk_sync_cursor', '0');
        $changes = $res['changes'] ?? [];
        $pulled = 0;
        if (is_array($changes) && $changes) {
            self::suppress(true);
            try {
                foreach ($changes as $c) {
                    if (is_array($c)) { self::applyChange($c); $pulled++; }
                }
            } finally {
                self::suppress(false);
            }
        }
        $nextCursor = (int)($res['next_cursor'] ?? $cursor);
        self::setCfg('desk_sync_cursor', (string)$nextCursor);
        if ($pulled > 0) {
            self::setCfg('desk_sync_pulled', (string)((int)self::getCfg('desk_sync_pulled', '0') + $pulled));
        }
        return ['ok' => true, 'pulled' => $pulled, 'more' => !empty($res['more']), 'next_cursor' => $nextCursor];
    }

    public static function bridgeNextPush(): array {
        list($changes, $maxId) = self::collectLocal(100);
        if (!$changes) {
            return ['ok' => true, 'done' => true, 'count' => 0, 'max_id' => 0];
        }
        $p = ['action' => 'push', 'changes' => $changes, 'key' => self::getCfg('desk_sync_key')];
        return [
            'ok' => true,
            'done' => false,
            'count' => count($changes),
            'max_id' => (int)$maxId,
            'sdp_z' => self::encodeSyncToken($p),
            'payload' => (string)json_encode($p, JSON_UNESCAPED_UNICODE),
        ];
    }

    public static function bridgeAckPush(int $maxId, int $count): array {
        if ($maxId > 0) {
            DB::execute("DELETE FROM desk_change_log WHERE id <= ?", [$maxId]);
        }
        if ($count > 0) {
            self::setCfg('desk_sync_pushed', (string)((int)self::getCfg('desk_sync_pushed', '0') + $count));
        }
        return ['ok' => true, 'pending' => self::pendingCount()];
    }

    public static function bridgeFinish(string $warn = ''): array {
        self::bumpSequences();
        self::setCfg('desk_sync_snapshot_done', '1');
        self::setCfg('desk_sync_err', $warn);
        self::setCfg('desk_sync_last', (string)time());
        self::setCfg('desk_sync_last_ok', (string)time());
        self::setCfg('desk_sync_verified_at', (string)time());
        self::setCfg('desk_sync_fails', '0');
        self::setCfg('desk_sync_next_try', '0');
        self::setCfg('desk_sync_lock', '0');
        return ['ok' => true, 'pending' => self::pendingCount(), 'status' => self::status(), 'server_verified' => true];
    }

    public static function run($force = false) {
        if (!self::enabled()) return ['ok' => false, 'error' => 'sync disabled'];

        // lock
        $lock = (int) self::getCfg('desk_sync_lock', '0');
        if (!$force && $lock && time() - $lock < self::LOCK_TTL) return ['ok' => true, 'skipped' => 'locked'];
        self::setCfg('desk_sync_lock', (string) time());
        self::setCfg('desk_sync_last', (string) time());

        $pushed = 0; $pulled = 0; $warn = ''; $out0 = '';
        try {
            require_once __DIR__.'/class_exam_groups.php';
            ensure_exams_schema();ceg_schema();
            self::ensureLocalTriggers();
            self::bumpSequences();

            // 1) handshake (also auto-installs server-side triggers)
            $hs = self::call('handshake');
            // old server file? → it does not know recently added tables (e.g. bots)
            if (isset($hs['tables']) && is_array($hs['tables'])) {
                $missingSrv = array_diff(json_decode(DESK_SYNC_TABLES, true), $hs['tables']);
                if ($missingSrv) $warn = 'فایل desk-sync-api.php روی سایت قدیمی است — فایل جدید (پوشه server همین بسته) را دوباره آپلود کنید تا این جدول‌ها هم همگام شوند: ' . implode('، ', $missingSrv);
            } elseif (!isset($hs['tables'])) {
                $warn = 'فایل desk-sync-api.php روی سایت قدیمی است — فایل جدید (پوشه server همین بسته) را دوباره آپلود کنید.';
            }

            // 2) first-time snapshot
            if (self::getCfg('desk_sync_snapshot_done') !== '1') {
                $state = json_decode(self::getCfg('desk_sync_state', '{}'), true) ?: [];
                $tables = json_decode(DESK_SYNC_TABLES, true);
                $ti  = (int)($state['ti'] ?? 0);
                $aft = $state['after'] ?? 0;
                while ($ti < count($tables)) {
                    $tbl = $tables[$ti];
                    $pk  = self::pkCol($tbl);
                    if ($aft === 0 && $pk !== 'id') $aft = '';
                    try {
                        $res = self::call('snapshot', ['tbl' => $tbl, 'after' => $aft, 'limit' => self::BATCH]);
                    } catch (Throwable $e) {
                        // old server file does not know this table — skip it,
                        // and remember that so it is imported later (2b) once
                        // the server file has been updated.
                        if (mb_strpos($e->getMessage(), 'bad table') !== false) {
                            $skipped = json_decode(self::getCfg('desk_sync_skipped', '[]'), true) ?: [];
                            if (!in_array($tbl, $skipped, true)) { $skipped[] = $tbl; self::setCfg('desk_sync_skipped', json_encode($skipped)); }
                            $ti++; $aft = 0;
                            self::setCfg('desk_sync_state', json_encode(['ti' => $ti, 'after' => $aft]));
                            continue;
                        }
                        throw $e;
                    }
                    $rows = $res['rows'] ?? [];
                    /* v2.11.0: full-mirror snapshot — before importing the FIRST
                       batch of a table, wipe the local copy (demo/seed rows and
                       stale data must never survive; the site is the source of
                       truth). settings keeps its desk_* keys (sync config!),
                       and admins is only wiped when the server actually sent
                       admins (never lock the user out on a server glitch). */
                    $freshStart = ($aft === 0 || $aft === '' || $aft === '0');
                    if ($freshStart && !($tbl === 'admins' && !$rows)) {
                        self::suppress(true);
                        try {
                            if ($tbl === 'settings') DB::execute("DELETE FROM \"settings\" WHERE key_name NOT LIKE 'desk!_%' ESCAPE '!'");
                            else                     DB::execute("DELETE FROM \"$tbl\"");
                        } catch (Throwable $e) { /* keep going */ }
                        finally { self::suppress(false); }
                    }
                    if ($rows) {
                        self::suppress(true);
                        try {
                            foreach ($rows as $row) {
                                if (!isset($row[$pk])) continue;
                                self::applyChange(['tbl' => $tbl, 'rid' => $row[$pk], 'op' => 'U', 'row' => $row]);
                                $aft = ($pk === 'id') ? max((int)$aft, (int)$row[$pk]) : max((string)$aft, (string)$row[$pk]);
                                $pulled++;
                            }
                        } finally { self::suppress(false); }
                    }
                    if (count($rows) < self::BATCH) { $ti++; $aft = 0; }
                    self::setCfg('desk_sync_state', json_encode(['ti' => $ti, 'after' => $aft]));
                }
                // snapshot rows must not be pushed back
                DB::execute("DELETE FROM desk_change_log");
                self::setCfg('desk_sync_cursor', (string)(isset($res['log_max']) ? $res['log_max'] : 0));
                self::setCfg('desk_sync_snapshot_done', '1');
                $skipped = json_decode(self::getCfg('desk_sync_skipped', '[]'), true) ?: [];
                self::setCfg('desk_sync_snapped', json_encode(array_values(array_diff(
                    json_decode(DESK_SYNC_TABLES, true), $skipped))));
                self::setCfg('desk_sync_skipped', '[]');
                self::bumpSequences();
            }

            // 2b) tables added in an app update AFTER the first snapshot:
            //     import them once, without redoing the whole snapshot.
            $snapped = json_decode(self::getCfg('desk_sync_snapped', '[]'), true) ?: [];
            if (!$snapped && self::getCfg('desk_sync_snapshot_done') === '1') {
                // upgraded from a pre-2.4 install: everything except the
                // bot tables was already imported by the original snapshot
                $snapped = array_values(array_diff(json_decode(DESK_SYNC_TABLES, true), [
                    'class_exam_groups','class_exam_group_members',
                    'bale_bot_users','telegram_bot_users','rubika_bot_users','bot_admin_sessions',
                    'bot_message_templates','bot_button_templates','bot_login_tokens','bot_message_logs',
                ]));
                self::setCfg('desk_sync_snapped', json_encode($snapped));
            }
            $newTables = array_diff(json_decode(DESK_SYNC_TABLES, true), $snapped);
            // self-heal: bot tables that are EMPTY locally are (re)imported even
            // if an older version wrongly marked them as already snapped
            // (v2.4.0 recorded skipped tables as done). Costs one tiny call per
            // empty table and is skipped when local deletions are still pending.
            foreach (['bale_bot_users','telegram_bot_users','rubika_bot_users','bot_admin_sessions',
                      'bot_message_templates','bot_button_templates','bot_login_tokens','bot_message_logs'] as $bt) {
                if (in_array($bt, $newTables, true)) continue;
                try {
                    $n = DB::fetch("SELECT COUNT(*) AS c FROM \"$bt\"");
                    if ((int)($n['c'] ?? 0) > 0) continue;
                    $pending = DB::fetch("SELECT 1 AS x FROM desk_change_log WHERE tbl = ? LIMIT 1", [$bt]);
                    if ($pending) continue; // local edits not pushed yet — do not overwrite
                    $newTables[] = $bt;
                } catch (Throwable $e) { /* table missing locally → schema upgrade handles it */ }
            }
            $srvTables = (isset($hs['tables']) && is_array($hs['tables'])) ? $hs['tables'] : null;
            foreach ($newTables as $tbl) {
                if ($srvTables !== null && !in_array($tbl, $srvTables, true)) continue; // server file too old for this table
                $pk = self::pkCol($tbl);
                $aft = ($pk === 'id') ? 0 : '';
                $srvOld = false;
                do {
                    try {
                        $res = self::call('snapshot', ['tbl' => $tbl, 'after' => $aft, 'limit' => self::BATCH]);
                    } catch (Throwable $e) {
                        if (mb_strpos($e->getMessage(), 'bad table') !== false) { $rows = []; $srvOld = true; break; }
                        throw $e;
                    }
                    $rows = $res['rows'] ?? [];
                    if ($rows) {
                        self::suppress(true);
                        try {
                            foreach ($rows as $row) {
                                if (!isset($row[$pk])) continue;
                                self::applyChange(['tbl' => $tbl, 'rid' => $row[$pk], 'op' => 'U', 'row' => $row]);
                                $aft = ($pk === 'id') ? max((int)$aft, (int)$row[$pk]) : max((string)$aft, (string)$row[$pk]);
                                $pulled++;
                            }
                        } finally { self::suppress(false); }
                    }
                } while (count($rows) >= self::BATCH);
                // rows imported this way must not echo back
                try { DB::execute("DELETE FROM desk_change_log WHERE tbl = ?", [$tbl]); } catch (Throwable $e) {}
                if ($srvOld) {
                    // server file too old for this table — leave it un-snapped so
                    // it is retried once the new desk-sync-api.php is uploaded
                    $snapped = array_values(array_diff($snapped, [$tbl]));
                } elseif (!in_array($tbl, $snapped, true)) {
                    $snapped[] = $tbl;
                }
                self::setCfg('desk_sync_snapped', json_encode(array_values($snapped)));
                self::bumpSequences();
            }

            // 3) pull server changes
            do {
                $cursor = (int) self::getCfg('desk_sync_cursor', '0');
                $res = self::call('pull', ['cursor' => $cursor, 'limit' => self::BATCH]);
                $changes = $res['changes'] ?? [];
                if ($changes) {
                    self::suppress(true);
                    try {
                        foreach ($changes as $c) { self::applyChange($c); $pulled++; }
                    } finally { self::suppress(false); }
                }
                self::setCfg('desk_sync_cursor', (string)($res['next_cursor'] ?? $cursor));
            } while (!empty($res['more']));

            // 4) push local changes
            do {
                list($changes, $maxId) = self::collectLocal(self::BATCH);
                if (!$changes) break;
                self::call('push', ['changes' => $changes]);
                DB::execute("DELETE FROM desk_change_log WHERE id <= ?", [$maxId]);
                $pushed += count($changes);
            } while (count($changes) >= 1 && $maxId > 0 && DB::fetch("SELECT id FROM desk_change_log LIMIT 1"));

            // 4b) v2.12.0: mirror the FILES referenced by the rows (exam
            //     source PDFs/images, converted page images, student photos,
            //     stamps) — a design without its files is useless on the
            //     desktop. Runs both ways; offline exceptions bubble up.
            try {
                $filesMoved = self::fileSync($warn);
                if ($filesMoved) $pulled += 0; // counted separately in desk_files_synced
            } catch (Throwable $e) {
                if (self::isOffline($e)) throw $e;
                if (mb_strpos($e->getMessage(), 'unknown action') !== false && $warn === '')
                    $warn = 'فایل desk-sync-api.php روی سایت قدیمی است — فایل جدید (پوشه server همین بسته) را آپلود کنید تا فایل‌های آزمون (PDF/تصاویر) هم همگام شوند.';
            }

            // 5) v2.11.0: mirror reconcile — desktop must EQUAL the site, not
            //    just receive its events. Every manual sync + hourly otherwise.
            $reconLast = (int) self::getCfg('desk_sync_recon_last', '0');
            if ($force || time() - $reconLast >= self::RECON_INTERVAL) {
                try {
                    $fixed = self::reconcile($pulled);
                    if ($fixed) $out0 = 'جدول‌های ناهمسان دوباره از سایت دریافت شدند: ' . implode('، ', $fixed);
                } catch (Throwable $e) {
                    if (mb_strpos($e->getMessage(), 'اتصال به سرور') !== false) throw $e;
                    if (mb_strpos($e->getMessage(), 'unknown action') !== false && $warn === '')
                        $warn = 'فایل desk-sync-api.php روی سایت قدیمی است — فایل جدید (پوشه server همین بسته) را دوباره آپلود کنید تا مقایسه کامل دسکتاپ/سایت هم فعال شود.';
                }
            }

            self::setCfg('desk_sync_err', $warn);
            self::setCfg('desk_sync_last_ok', (string) time());
            /* v2.107.0: «successful exchange» is recorded here, inside run(),
               so it is written by EVERY path — the manual «همگامسازی همین حالا»
               button (desk-sync.php?ajax=run&force) and the background daemon
               alike. The connection monitor used to depend only on a flag in
               the daemon heartbeat, so on installs whose heartbeat did not
               carry it the panel stayed on «در انتظار وضعیت همگامسازی» even
               right after a perfectly successful manual sync. */
            self::setCfg('desk_sync_verified_at', (string) time());
            self::setCfg('desk_sync_fails', '0');
            self::setCfg('desk_sync_next_try', '0');
            self::setCfg('desk_sync_pushed', (string)((int)self::getCfg('desk_sync_pushed','0') + $pushed));
            self::setCfg('desk_sync_pulled', (string)((int)self::getCfg('desk_sync_pulled','0') + $pulled));
            /* Explicit proof for whoever consumes this result (manual button
               JSON, daemon heartbeat, notification hand-off): the site really
               answered a full cycle. */
            $out = ['ok' => true, 'pushed' => $pushed, 'pulled' => $pulled, 'server_verified' => true];
            if (!empty($out0)) $out['reconciled'] = $out0;
            if ($warn !== '') $out['warning'] = $warn;
        } catch (Throwable $e) {
            self::setCfg('desk_sync_err', $e->getMessage());
            $out = ['ok' => false, 'error' => $e->getMessage(), 'pushed' => $pushed, 'pulled' => $pulled];
        }
        self::setCfg('desk_sync_lock', '0');
        return $out;
    }
}
