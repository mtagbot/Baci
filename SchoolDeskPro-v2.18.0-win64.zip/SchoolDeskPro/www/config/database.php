<?php
/**
 * SchoolDesk Pro desktop runtime — embedded SQLite database.
 */
return [
    'driver'   => 'sqlite',
    'database' => dirname(__DIR__, 2) . '/data/school.sqlite',
];
