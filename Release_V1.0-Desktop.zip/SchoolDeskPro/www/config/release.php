<?php
return ['release'=>'Release_V1.0','distribution'=>'desktop','site_version'=>'4.152.0','desktop_version'=>'2.83.0'];
