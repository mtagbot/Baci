<?php
// File: desk-sync-daemon.php  (SchoolDesk Pro — background sync worker)
/**
 * v2.11.0: ALL sync network I/O now happens here, in a separate hidden
 * PHP process — never inside a page request.
 *
 * Why: the desktop serves the whole app from ONE PHP worker. Previously the
 * 5-second heartbeat executed the sync (with its network timeouts) inside
 * that worker, so while the internet was slow or down, every click in the
 * app queued behind a stuck network call — that was the "slow without
 * internet" problem. Now page requests only read a status file (instant),
 * and this daemon does the waiting.
 *
 * Lifecycle: spawned automatically by desk-prepend.php on app start (and
 * re-spawned if it ever dies). Exits by itself when the app has been
 * closed for a while. Single-instance via an exclusive file lock.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit('cli only'); }

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
set_time_limit(0);

$root    = dirname(__DIR__);              // SchoolDeskPro/
$dataDir = $root . '/data';
if (!is_dir($dataDir)) @mkdir($dataDir, 0777, true);

require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/desk_sync.php';

/* single instance */
$lockFh = @fopen($dataDir . '/sync-daemon.lock', 'c');
if (!$lockFh || !@flock($lockFh, LOCK_EX | LOCK_NB)) exit(0);

$hbFile     = $dataDir . '/sync-heartbeat.json';
$aliveFile  = $dataDir . '/app-alive.txt';
$kickFile   = $dataDir . '/sync-kick.txt';
$engineFile = __DIR__ . '/includes/desk_sync.php';
$bootMtime  = ((int)@filemtime($engineFile)) . ':' . ((int)@filemtime(__FILE__));

function desk_write_heartbeat($file,$value) {
    $temp=$file.'.'.getmypid().'.tmp';
    if(@file_put_contents($temp,json_encode($value,JSON_UNESCAPED_UNICODE),LOCK_EX)!==false){
        if(!@rename($temp,$file))@unlink($temp);
    }
}
while (true) {
    clearstatcache(true, $engineFile);
    clearstatcache(true, __FILE__);
    if ((((int)@filemtime($engineFile)) . ':' . ((int)@filemtime(__FILE__))) !== $bootMtime) break;
    // Publish actual worker activity before potentially slow remote I/O.
    desk_write_heartbeat($hbFile,['phase'=>'syncing','ts'=>time(),'daemon'=>1,'engine_mtime'=>$bootMtime]);
    $res = ['ok' => false];
    try {
        $res = DeskSync::tick();
    } catch (Throwable $e) {
        $res = ['ok' => false, 'error' => $e->getMessage(),
                'pending' => DeskSync::pendingCount(), 'fails' => 0, 'alert' => false];
    }
    if (!is_array($res)) $res = ['ok' => false];
    try {
        require_once __DIR__.'/includes/bot_helpers.php';
        // Local-owner jobs are safe to retry independently of school-data sync.
        bot_outbox_drain(2,8);
        // Alert links/record IDs must already exist on the server before handoff.
        if(!empty($res['ok']) && !empty($res['server_verified']) && DeskSync::pendingCount()===0) DeskSync::relayBotNotifications();
    } catch(Throwable $e) { error_log('Notification worker: queue processing failed; retained for retry.'); }

    /* Desktop online update — fully automatic. Ask the school site (same key as
       sync) whether a newer package is published and install it without any
       operator action: web files are replaced immediately, a new
       SchoolDeskPro.exe is staged and applied by the launcher on the next start.
       The check is throttled inside the engine (15 minutes), so most loops are a
       local file read, and a failure never disturbs school-data sync. */
    $res['update'] = null;
    try {
        require_once __DIR__.'/includes/desk_update.php';
        if (DeskSync::enabled()) {
            $auto = desk_update_auto(900);
            $res['update'] = $auto['status'] ?? null;
            $res['update_installed'] = !empty($auto['installed']);
            $res['update_error'] = (string)($auto['error'] ?? '');
        }
    } catch (Throwable $e) { /* never let update checking disturb data sync */ }

    $res['ts']     = time();
    $res['daemon'] = 1;
    $res['phase']='settled';
    $res['engine_mtime'] = $bootMtime;
    desk_write_heartbeat($hbFile,$res);

    // app closed? (no page request refreshed app-alive for 15 minutes) → stop
    if (!is_file($aliveFile) || time() - (int)@filemtime($aliveFile) > 900) break;

    // engine or daemon file updated on disk? → exit so a fresh worker loads the new code
    clearstatcache(true, $engineFile);
    clearstatcache(true, __FILE__);
    if ((((int)@filemtime($engineFile)) . ':' . ((int)@filemtime(__FILE__))) !== $bootMtime) break;

    /* v2.12.0: sync must follow EVERY change immediately. Any page request
       that modified data touches sync-kick.txt (see desk-prepend.php);
       we sleep in 1-second slices and wake instantly on that signal, so a
       change reaches the site within ~1 second instead of up to 5. */
    for ($i = 0; $i < 5; $i++) {
        if (is_file($kickFile)) { @unlink($kickFile); break; }
        sleep(1);
    }
}
@flock($lockFh, LOCK_UN);
@fclose($lockFh);
