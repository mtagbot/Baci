<?php
// File: student-modal.php
/**
 * AJAX modal/tooltip content for admin student list.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/school_roles.php';
ensure_school_roles_schema();
/* v4.83.0: the discipline page (deputy-panel.php) is available to deputy
   teachers too — the hover tooltip / info / discipline modals must work for
   them exactly like for admins, so accept both roles here. */
$smIsAdmin  = is_admin_logged_in() && has_permission('manage_students');
$smIsDeputy = function_exists('is_teacher_logged_in') && is_teacher_logged_in()
              && function_exists('teacher_has_deputy') && teacher_has_deputy($_SESSION['teacher_id'] ?? 0);
if (!$smIsAdmin && !$smIsDeputy) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'html' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
    exit;
}
header('Content-Type: application/json; charset=utf-8');
$type = $_GET['type'] ?? $_POST['type'] ?? 'hover';
$studentId = (int)($_GET['student_id'] ?? $_POST['student_id'] ?? 0);
$student = DB::fetch("SELECT * FROM students WHERE id=?", [$studentId]);
if (!$student) { echo json_encode(['ok'=>false,'html'=>'دانش‌آموز یافت نشد.'], JSON_UNESCAPED_UNICODE); exit; }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) { echo json_encode(['ok'=>false,'html'=>'خطای امنیتی CSRF'], JSON_UNESCAPED_UNICODE); exit; }
    if ($type === 'discipline_save') {
        $titleId=(int)($_POST['title_id']??0); $tr=$titleId?DB::fetch('SELECT title FROM discipline_titles WHERE id=?',[$titleId]):null;
        $title = trim($tr['title'] ?? ($_POST['title_text'] ?? ''));
        $note = trim($_POST['internal_note'] ?? '');
        $occur = trim($_POST['occurred_at_jalali'] ?? jalali_now());
        $notify = isset($_POST['notify_parents']) ? 1 : 0; $just=isset($_POST['is_justified'])?1:0; $review=trim($_POST['review_status']??'pending'); $reviewNote=trim($_POST['review_note']??'');
        if ($title !== '') {
            DB::execute("INSERT INTO student_discipline_records (student_id,title_id,title_text,internal_note,occurred_at_jalali,notify_parents,is_justified,review_status,review_note,created_by_teacher_id,created_at_jalali) VALUES (?,?,?,?,?,?,?,?,?,?,?)", [$studentId,$titleId?:null,$title,$note,$occur,$notify,$just,$review,$reviewNote,null,jalali_now()]);
            $newRid = DB::lastInsertId();
            if ($notify) notify_student_discipline_bots($studentId,$title,$occur,$newRid);
        }
        $type = 'discipline';
    }
    if ($type === 'discipline_update') {
        /* V4.213.0 — «متن بررسی» هم ذخیره می‌شود؛ قبلاً فقط در فرم ثبت بود و در ویرایش گم می‌شد. */
        DB::execute("UPDATE student_discipline_records SET title_text=?, occurred_at_jalali=?, internal_note=?, is_justified=?, review_status=?, review_note=?, updated_at_jalali=? WHERE id=? AND student_id=?", [trim($_POST['title_text']??''), trim($_POST['occurred_at_jalali']??''), trim($_POST['internal_note']??''), isset($_POST['is_justified'])?1:0, trim($_POST['review_status']??'pending'), trim($_POST['review_note']??''), jalali_now(), (int)$_POST['record_id'], $studentId]);
        $type = 'discipline';
    }
    if ($type === 'discipline_delete') {
        DB::execute("DELETE FROM student_discipline_records WHERE id=? AND student_id=?", [(int)$_POST['record_id'],$studentId]);
        $type = 'discipline';
    }
}

ob_start();
$profileCard = '<div class="soft-panel flex gap-3 items-center mb-3"><div class="avatar-lg">' . (!empty($student['photo_url']) ? '<img src="'.clean($student['photo_url']).'">' : '👤') . '</div><div><b>'.clean($student['first_name'].' '.$student['last_name']).'</b><br><span class="text-xs">'.clean($student['class_name'].' / '.$student['grade_level']).'</span><br><span class="text-xs">پدر: '.tr_num($student['father_phone'] ?: '---','fa').' | مادر: '.tr_num($student['mother_phone'] ?: '---','fa').'</span></div></div>';
if ($type === 'info'):
?>
<?php echo $profileCard; ?><h3 class="font-bold text-primary mb-3">اطلاعات پرونده دانش‌آموز</h3>
<div class="grid grid-cols-2 gap-3">
  <div class="soft-panel"><b>نام:</b> <?php echo clean($student['first_name'].' '.$student['last_name']); ?><br><b>کد ملی:</b> <?php echo tr_num($student['national_id'],'fa'); ?><br><b>نام پدر:</b> <?php echo clean($student['father_name'] ?: '---'); ?><br><b>نام مادر:</b> <?php echo clean(($student['mother_name'] ?? '') ?: '---'); ?><br><b>تاریخ تولد:</b> <?php echo tr_num($student['birth_date'] ?: '---','fa'); ?><br><b>محل تولد:</b> <?php echo clean(($student['birth_place'] ?? '') ?: '---'); ?><br><b>محل صدور:</b> <?php echo clean(($student['place_issued'] ?? '') ?: '---'); ?></div>
  <div class="soft-panel"><b>پایه/کلاس:</b> <?php echo clean($student['grade_level'].' / '.$student['class_name']); ?><br><b>تلفن:</b> <?php echo tr_num($student['phone'] ?: '---','fa'); ?><br><b>پدر:</b> <?php echo tr_num($student['father_phone'] ?: '---','fa'); ?><br><b>مادر:</b> <?php echo tr_num($student['mother_phone'] ?: '---','fa'); ?><br><b>تلفن منزل:</b> <?php echo tr_num(($student['home_phone'] ?? '') ?: '---','fa'); ?><br><b>کد پستی:</b> <?php echo tr_num(($student['postal_code'] ?? '') ?: '---','fa'); ?></div>
  <div class="soft-panel"><b>تحصیلات پدر:</b> <?php echo clean(($student['father_qualification'] ?? '') ?: '---'); ?><br><b>شغل پدر:</b> <?php echo clean(($student['father_job'] ?? '') ?: '---'); ?><br><b>تحصیلات مادر:</b> <?php echo clean(($student['mother_qualification'] ?? '') ?: '---'); ?><br><b>شغل مادر:</b> <?php echo clean(($student['mother_job'] ?? '') ?: '---'); ?><br><b>معدل سال قبل:</b> <?php echo tr_num(($student['last_year_average'] ?? '') ?: '---','fa'); ?></div>
  <div class="soft-panel"><b>آدرس منزل:</b> <?php echo clean(($student['home_address'] ?? '') ?: '---'); ?><br><b>بیماری خاص:</b> <?php echo clean(($student['specific_disease_title'] ?? '') ?: '---'); ?><br>
  <?php if(!empty($student['is_foreign'])): ?><span class="badge badge-danger text-xs">اتباع</span> <?php endif; ?>
  <?php if(!empty($student['has_sport_limitation'])): ?><span class="badge badge-warning text-xs">محدودیت ورزش</span> <?php endif; ?>
  <?php if(!empty($student['mother_deceased'])): ?><span class="badge badge-dark text-xs">مادر فوت شده</span> <?php endif; ?>
  <?php if(!empty($student['father_deceased'])): ?><span class="badge badge-dark text-xs">پدر فوت شده</span> <?php endif; ?>
  </div>
</div>
<div class="mt-3"><a class="btn btn-secondary text-xs" target="_blank" href="students.php?action=edit&id=<?php echo $studentId; ?>">ویرایش پرونده</a></div>
<?php
elseif ($type === 'hover'):
?>
<?php
// v4.34.0: hover card — phones only (large font) + special flags. No national id / father name.
$specialFlags = [];
if (!empty($student['has_sport_limitation'])) $specialFlags[] = ['🏃', 'محدودیت ورزش', '#b45309', '#fffbeb', '#fde68a'];
if (!empty($student['mother_deceased']))      $specialFlags[] = ['🖤', 'مادر فوت شده', '#374151', '#f3f4f6', '#d1d5db'];
if (!empty($student['father_deceased']))      $specialFlags[] = ['🖤', 'پدر فوت شده', '#374151', '#f3f4f6', '#d1d5db'];
if (!empty($student['father_guardian']))      $specialFlags[] = ['🛡️', 'سرپرست: پدر', '#1d4ed8', '#eff6ff', '#bfdbfe'];
if (!empty($student['mother_guardian']))      $specialFlags[] = ['🛡️', 'سرپرست: مادر', '#be185d', '#fdf2f8', '#fbcfe8'];
?>
<div class="student-hover-card">
    <div class="flex gap-3 items-center">
        <div class="avatar-lg"><?php if(!empty($student['photo_url'])): ?><img src="<?php echo clean($student['photo_url']); ?>"><?php else: ?>👤<?php endif; ?></div>
        <div><b><?php echo clean($student['first_name'].' '.$student['last_name']); ?></b><br><span class="text-xs text-muted"><?php echo clean($student['class_name'].' / '.$student['grade_level']); ?></span></div>
    </div>
    <hr>
    <div style="display:flex;flex-direction:column;gap:6px;">
        <div style="display:flex;justify-content:space-between;align-items:center;"><span style="font-size:11px;color:var(--text-muted);font-weight:700;">📱 موبایل دانش‌آموز</span><b style="font-size:17px;letter-spacing:.5px;direction:ltr;"><?php echo tr_num(($student['student_mobile'] ?? '') ?: ($student['phone'] ?: '---'),'fa'); ?></b></div>
        <div style="display:flex;justify-content:space-between;align-items:center;"><span style="font-size:11px;color:var(--text-muted);font-weight:700;">📞 پدر</span><b style="font-size:17px;letter-spacing:.5px;direction:ltr;"><?php echo tr_num($student['father_phone'] ?: '---','fa'); ?></b></div>
        <div style="display:flex;justify-content:space-between;align-items:center;"><span style="font-size:11px;color:var(--text-muted);font-weight:700;">📞 مادر</span><b style="font-size:17px;letter-spacing:.5px;direction:ltr;"><?php echo tr_num($student['mother_phone'] ?: '---','fa'); ?></b></div>
        <?php if (!empty($student['home_phone'])): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;"><span style="font-size:11px;color:var(--text-muted);font-weight:700;">🏠 منزل</span><b style="font-size:17px;letter-spacing:.5px;direction:ltr;"><?php echo tr_num($student['home_phone'],'fa'); ?></b></div>
        <?php endif; ?>
    </div>
    <?php if (!empty($specialFlags)): ?>
    <hr>
    <div style="display:flex;flex-wrap:wrap;gap:5px;">
        <span style="font-size:10px;font-weight:800;color:var(--text-muted);width:100%;">⚠️ موارد خاص:</span>
        <?php foreach ($specialFlags as [$ic, $lbl, $fg, $bg, $bd]): ?>
        <span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:800;color:<?php echo $fg; ?>;background:<?php echo $bg; ?>;border:1px solid <?php echo $bd; ?>;border-radius:999px;padding:3px 9px;"><?php echo $ic; ?> <?php echo $lbl; ?></span>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php elseif ($type === 'reports'):
$reports = DB::fetchAll("SELECT r.*, (SELECT COUNT(*) FROM report_parent_reviews rv WHERE rv.report_id=r.id) AS review_count FROM reports r WHERE r.student_id=? ORDER BY r.id DESC", [$studentId]);
?>
<?php echo $profileCard; ?><h3 class="font-bold text-primary mb-3">کارنامه‌های <?php echo clean($student['first_name'].' '.$student['last_name']); ?></h3>
<div class="table-container modal-table"><table><thead><tr><th>سال</th><th>ماه/نوبت</th><th>معدل</th><th>بررسی والدین</th><th>وضعیت</th><th>مدیریت</th></tr></thead><tbody>
<?php foreach($reports as $r): ?><tr><td><?php echo clean($r['academic_year']); ?></td><td><?php echo clean($r['term'].' / '.$r['report_month']); ?></td><td><?php echo format_score($r['gpa']); ?></td><td><?php echo ((int)$r['review_count']>0)?'<span class="badge badge-success">بررسی شده</span>':'<span class="badge badge-danger">بررسی نشده</span>'; ?></td><td><?php $smLockReason=''; echo is_report_locked_for_student($r, $smLockReason) ? '<span title="'.clean($smLockReason).'">قفل</span>' : 'آزاد'; ?></td><td><a class="btn btn-primary text-xs" target="_blank" href="report-view.php?id=<?php echo $r['id']; ?>&staff=1">مشاهده</a> <a class="btn btn-secondary text-xs" target="_blank" href="reports.php?action=edit&id=<?php echo $r['id']; ?>">ویرایش</a> <a class="btn btn-outline text-xs" target="_blank" href="report-print.php?id=<?php echo $r['id']; ?>&staff=1">چاپ</a></td></tr><?php endforeach; if(!$reports): ?><tr><td colspan="5" class="text-center text-muted">کارنامه‌ای ثبت نشده است.</td></tr><?php endif; ?>
</tbody></table></div><div class="mt-3 flex flex-wrap gap-2">
  <a class="btn btn-success text-xs" target="_blank" href="reports.php?action=new&student_id=<?php echo $studentId; ?>">+ ثبت کارنامه جدید</a>
  <?php /* V4.213.0 — مقایسهٔ ماه‌به‌ماه همهٔ درس‌ها + روند معدل، در صفحه‌ای مستقل. */ ?>
  <a class="btn btn-primary text-xs" target="_blank" href="student-report-compare.php?student_id=<?php echo (int)$studentId; ?>">مقایسه نمرات ماهانه</a>
</div>
<?php elseif ($type === 'discipline'):
$records=DB::fetchAll("SELECT * FROM student_discipline_records WHERE student_id=? ORDER BY id DESC",[$studentId]);
$titlesForModal=function_exists('discipline_titles_ranked')?discipline_titles_ranked():DB::fetchAll('SELECT * FROM discipline_titles WHERE status=1 ORDER BY title');
$smReviewLabels=['pending'=>'در انتظار بررسی','reviewed'=>'بررسی‌شده','closed'=>'مختومه'];
$smRecordCount=is_array($records)?count($records):0;
?>
<?php /* V4.213.0 — مدیریت انضباط در دو پنل تمام‌عرض:
      راست (اول در DOM) = ثبت مورد تازه · چپ = فهرست موارد ثبت‌شده با یک ردیف برای هر مورد.
      در نمایشگر باریک/عمودی، دو پنل زیر هم می‌آیند و همان‌طور که خواسته شد پنل ثبت اول است. */ ?>
<div class="disc-modal">
    <?php echo $profileCard; ?>
    <div class="disc-grid">
        <section class="disc-panel disc-panel-entry" aria-labelledby="discEntryTitle">
            <div class="disc-panel-head">
                <h3 id="discEntryTitle">ثبت مورد انضباطی تازه</h3>
                <span class="disc-hint">برای این دانش‌آموز</span>
            </div>
            <form class="ajax-discipline-form disc-form" onsubmit="return saveDisciplineAjax(this)">
                <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                <input type="hidden" name="type" value="discipline_save">
                <input type="hidden" name="student_id" value="<?php echo $studentId; ?>">
                <div class="disc-field">
                    <label for="discTitleId">عنوان ذخیره‌شده</label>
                    <select id="discTitleId" name="title_id" class="form-select">
                        <option value="">انتخاب از عنوان‌های آماده…</option>
                        <?php foreach($titlesForModal as $tt): ?><option value="<?php echo (int)$tt['id']; ?>"><?php echo clean($tt['title']); ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="disc-field">
                    <label for="discTitleText">یا عنوان جدید</label>
                    <input id="discTitleText" name="title_text" class="form-input" placeholder="مثلاً بی‌نظمی در کلاس" autocomplete="off">
                </div>
                <div class="disc-field">
                    <label for="discDate">تاریخ (شمسی)</label>
                    <input id="discDate" name="occurred_at_jalali" class="form-input" value="<?php echo jalali_now(); ?>" inputmode="numeric" autocomplete="off">
                </div>
                <div class="disc-field">
                    <label for="discReview">وضعیت بررسی</label>
                    <select id="discReview" name="review_status" class="form-select">
                        <option value="pending">در انتظار بررسی</option>
                        <option value="reviewed">بررسی‌شده</option>
                        <option value="closed">مختومه</option>
                    </select>
                </div>
                <div class="disc-field disc-span-all">
                    <label for="discNote">یادداشت داخلی</label>
                    <textarea id="discNote" name="internal_note" class="form-textarea" rows="2" placeholder="توضیح کوتاه برای پرونده (اختیاری)"></textarea>
                </div>
                <div class="disc-field disc-span-all">
                    <label for="discReviewNote">متن بررسی</label>
                    <textarea id="discReviewNote" name="review_note" class="form-textarea" rows="2" placeholder="نتیجهٔ بررسی (اختیاری)"></textarea>
                </div>
                <div class="disc-checks disc-span-all">
                    <label><input type="checkbox" name="is_justified"> مورد موجه است</label>
                    <label><input type="checkbox" name="notify_parents"> ارسال اعلان به والدین</label>
                </div>
                <div class="disc-actions disc-span-all">
                    <button class="btn btn-success" type="submit">ثبت مورد</button>
                </div>
            </form>
        </section>

        <section class="disc-panel disc-panel-list" aria-labelledby="discListTitle">
            <div class="disc-panel-head">
                <h3 id="discListTitle">موارد ثبت‌شده</h3>
                <span class="badge badge-info text-xs"><?php echo tr_num($smRecordCount, 'fa'); ?> مورد</span>
            </div>
            <div class="disc-table-wrap">
                <table class="disc-table">
                    <?php /* V4.214.0 — عرض ستون‌ها ثابت و درصدی است تا جدول در عرض
                          پنجره جا شود و اسکرول افقی هرگز لازم نشود. */ ?>
                    <colgroup>
                        <col style="width:30%"><col style="width:7%">
                        <col style="width:17%"><col style="width:22%"><col style="width:9%"><col style="width:15%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th>عنوان مورد انضباطی و تاریخ</th>
                            <th>موجه</th>
                            <th>بررسی</th>
                            <th>یادداشت داخلی</th>
                            <th>اعلان</th>
                            <th>اقدام</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($records as $r): $rid=(int)$r['id']; $rfid='disc-row-'.$rid; ?>
                        <tr>
                            <td class="disc-col-title">
                                <?php /* فرم هر ردیف با ویژگی form به ورودی‌هایش وصل می‌شود؛ این‌طور
                                      یک جدول واقعی داریم، نه یک فرم غول‌آسا داخل یک سلول. */ ?>
                                <form id="<?php echo $rfid; ?>" onsubmit="return updateDisciplineAjax(this)">
                                    <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                                    <input type="hidden" name="type" value="discipline_update">
                                    <input type="hidden" name="student_id" value="<?php echo $studentId; ?>">
                                    <input type="hidden" name="record_id" value="<?php echo $rid; ?>">
                                </form>
                                <input form="<?php echo $rfid; ?>" name="title_text" class="form-input text-xs disc-title-input" value="<?php echo clean($r['title_text']); ?>" aria-label="عنوان مورد انضباطی" placeholder="عنوان مورد انضباطی">
                                <?php /* V4.214.2 — تاریخ زیر عنوان، با همان عرض دقیقِ فیلد عنوان. */ ?>
                                <div class="disc-date-field">
                                    <span class="disc-date-cap">تاریخ وقوع</span>
                                    <input form="<?php echo $rfid; ?>" name="occurred_at_jalali" class="form-input text-xs disc-date" value="<?php echo clean($r['occurred_at_jalali']); ?>" inputmode="numeric" aria-label="تاریخ وقوع" title="تاریخ وقوع (شمسی)">
                                </div>
                            </td>
                            <td class="disc-col-check"><label class="disc-check" title="موجه"><input form="<?php echo $rfid; ?>" type="checkbox" name="is_justified" <?php echo !empty($r['is_justified'])?'checked':''; ?>> <span>موجه</span></label></td>
                            <td>
                                <select form="<?php echo $rfid; ?>" name="review_status" class="form-select text-xs" aria-label="وضعیت بررسی">
                                    <?php foreach($smReviewLabels as $rv=>$rl): ?><option value="<?php echo $rv; ?>" <?php echo ($r['review_status']??'')===$rv?'selected':''; ?>><?php echo clean($rl); ?></option><?php endforeach; ?>
                                </select>
                                <?php /* V4.213.0 — «متن بررسی» هم مثل بقیهٔ داده‌های همان مورد در همین ردیف
                                      ذخیره می‌شود؛ اگر این ورودی نبود، ذخیرهٔ ردیف آن را خالی می‌کرد. */ ?>
                                <textarea form="<?php echo $rfid; ?>" name="review_note" class="form-textarea text-xs disc-review-note" rows="2" placeholder="متن بررسی" aria-label="متن بررسی"><?php echo clean((string)($r['review_note'] ?? '')); ?></textarea>
                            </td>
                            <td><textarea form="<?php echo $rfid; ?>" name="internal_note" class="form-textarea text-xs disc-note" rows="2" aria-label="یادداشت داخلی"><?php echo clean((string)($r['internal_note'] ?? '')); ?></textarea></td>
                            <td class="disc-col-notify"><?php echo !empty($r['notify_parents']) ? '<span class="badge badge-success text-xs" title="اعلان به والدین ارسال شده">ارسال شد</span>' : '<span class="text-muted text-xs">—</span>'; ?></td>
                            <td class="disc-col-actions">
                                <button form="<?php echo $rfid; ?>" class="btn btn-success text-xs" type="submit">ذخیره</button>
                                <button type="button" class="btn btn-danger text-xs" onclick="deleteDisciplineAjax(<?php echo $studentId; ?>,<?php echo $rid; ?>)">حذف</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(!$records): ?>
                            <tr><td colspan="6" class="text-center text-muted">هنوز موردی برای این دانش‌آموز ثبت نشده است.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</div>
<style>
/* V4.213.0 — چیدمان دو پنلی مدیریت انضباط داخل مودال
   V4.214.0 — پنجره بزرگ‌تر شد و جدول با چیدمان ثابت (table-layout:fixed) در
   همان عرض جا می‌شود؛ ستون‌ها درصدی‌اند، پس دیگر هیچ محتوایی بیرون نمی‌زند
   و اسکرول افقی لازم نیست.
   V4.214.1 — پنجره تقریباً تمام‌صفحه شد (۹۸٪ عرض دید) و هیچ کلمه‌ای نمی‌شکند:
   سرستون‌ها، دکمه‌ها، «موجه» و «ارسال شد» همه nowrap هستند. */
.disc-modal{width:100%;min-width:0}
#studentAjaxModal .modal-card,.modal-backdrop .modal-card{width:min(1180px,96vw);max-width:calc(100vw - 16px)}
#studentAjaxModal.modal-disc{padding:6px}
/* V4.214.2 — سقف ۲۰۰۰ پیکسلی برداشته شد؛ روی نمایشگرهای بزرگ پنجره به ~۷۸٪
   صفحه محدود می‌شد. حالا در هر اندازه‌ای ۹۸٪ عرض دید است (بیشتر از ۹۰٪ خواسته‌شده). */
#studentAjaxModal.modal-disc .modal-card{width:98vw;max-width:calc(100vw - 6px)}
.disc-grid{display:grid;grid-template-columns:minmax(280px,.6fr) minmax(0,2.4fr);gap:12px;align-items:start;margin-top:6px}
@media (max-width:1024px){.disc-grid{grid-template-columns:minmax(0,1fr)}}
.disc-panel{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:14px;min-width:0;box-shadow:0 1px 2px rgba(15,23,42,.04)}
.disc-panel-entry{border-top:3px solid #16a34a}
.disc-panel-list{border-top:3px solid #2563eb}
.disc-panel-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px}
.disc-panel-head h3{font-size:14px;font-weight:800;color:#0f172a;margin:0}
.disc-hint{font-size:11px;color:#64748b;font-weight:700}
.disc-form{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
@media (max-width:560px){.disc-form{grid-template-columns:minmax(0,1fr)}}
.disc-field{display:flex;flex-direction:column;gap:4px;min-width:0}
.disc-field label{font-size:11px;font-weight:800;color:#475569}
.disc-span-all{grid-column:1/-1}
.disc-checks{display:flex;flex-wrap:wrap;gap:14px}
.disc-checks label{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:#334155}
.disc-actions{display:flex;justify-content:flex-end}
.disc-table-wrap{overflow-y:auto;overflow-x:hidden;max-height:56vh;border:1px solid #eef2f7;border-radius:10px}
.disc-table{width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed}
.disc-table th{position:sticky;top:0;background:#f8fafc;color:#475569;font-size:11px;text-align:right;padding:6px 5px;border-bottom:1px solid #e2e8f0;white-space:nowrap;line-height:1.5;z-index:1}
.disc-table td{padding:5px;border-bottom:1px solid #eef2f7;vertical-align:top;overflow-wrap:normal;word-break:normal;min-width:0}
.disc-table tr:last-child td{border-bottom:0}
/* هر ورودی دقیقاً به اندازهٔ ستون خودش؛ نه یک پیکسل بیشتر */
.disc-table .form-input,.disc-table .form-select,.disc-table .form-textarea{width:100%;min-width:0;max-width:100%;box-sizing:border-box;font-size:11px}
.disc-date{direction:ltr;text-align:left}
/* V4.214.2 — تاریخ زیر عنوان و دقیقاً هم‌عرض آن. */
.disc-date-field{margin-top:5px}
.disc-date-cap{display:block;font-size:10px;font-weight:800;color:#64748b;margin-bottom:3px;white-space:nowrap}
.disc-title-input,.disc-date-field .disc-date{width:100%;box-sizing:border-box}
.disc-note,.disc-review-note{resize:vertical}
.disc-review-note{margin-top:4px}
/* V4.214.1 — هیچ‌کدام از این برچسب‌ها/دکمه‌ها نمی‌شکنند. */
.disc-col-check,.disc-col-notify{text-align:center;white-space:nowrap}
.disc-col-actions{text-align:center;white-space:nowrap}
.disc-col-actions .btn{display:block;width:100%;margin:0 0 3px;white-space:nowrap}
.disc-col-notify .badge{white-space:nowrap}
.disc-check{display:inline-flex;align-items:center;gap:3px;font-size:10px;font-weight:700;color:#334155;white-space:nowrap}
/* V4.214.1 — روی نمایشگر باریک، جدول به‌جای شکستنِ کلمه‌ها کمی اسکرول افقی می‌گیرد. */
@media (max-width:1024px){.disc-table-wrap{max-height:none;overflow-x:auto}.disc-table{min-width:780px}}
</style>
<?php endif;
$html = ob_get_clean();
/* v4.169.0: شمارشگرهای تازهٔ همان دانش‌آموز — لیست بدون رفرش صفحه،
   ستون انضباط و بررسی‌نشدهٔ ردیف را با این مقادیر به‌روز می‌کند. */
$rowStats = null;
try {
    $cnt = DB::fetch("SELECT COUNT(*) AS c, SUM(CASE WHEN COALESCE(review_status,'pending')='pending' THEN 1 ELSE 0 END) AS u FROM student_discipline_records WHERE student_id=?", [$studentId]);
    $rowStats = ['student_id'=>$studentId, 'discipline_count'=>(int)($cnt['c']??0), 'unreviewed_count'=>(int)($cnt['u']??0)];
} catch (Exception $e) {}
echo json_encode(['ok'=>true,'html'=>$html,'stats'=>$rowStats], JSON_UNESCAPED_UNICODE);
