<?php
return ['release'=>'Release_V1.14','distribution'=>'desktop','site_version'=>'4.220.0','desktop_version'=>'2.144.0'];
