<?php
return ['release'=>'Release_V1.13','distribution'=>'desktop','site_version'=>'4.219.0','desktop_version'=>'2.143.0'];
