#!/usr/bin/env bash
set -euo pipefail

# Baci rollback target: state before LIVE-EXAM-DESIGNER
TARGET_COMMIT="6a9026eba0ffcdc4ee2f721b05641610d43774ed"

if [[ "${1:-}" != "--confirm" ]]; then
  echo "این عملیات تغییرات محلی را پاک می‌کند و مخزن را به حالت قبل از LIVE-EXAM-DESIGNER برمی‌گرداند."
  echo "برای ادامه اجرا کنید:"
  echo "  $0 --confirm [مسیر مخزن]"
  exit 2
fi

REPO="${2:-.}"
cd "$REPO"

if ! TOP="$(git rev-parse --show-toplevel 2>/dev/null)"; then
  echo "خطا: مسیر داده‌شده یک مخزن Git نیست." >&2
  exit 1
fi
cd "$TOP"

if ! git cat-file -e "${TARGET_COMMIT}^{commit}" 2>/dev/null; then
  echo "خطا: commit هدف در این مخزن وجود ندارد: ${TARGET_COMMIT}" >&2
  exit 1
fi

echo "بازگردانی فایل‌های tracked به ${TARGET_COMMIT} ..."
git reset --hard "$TARGET_COMMIT"

# این‌ها مسیرها و artifactهای مربوط به LIVE-EXAM-DESIGNER و بسته‌های بعدی‌اند.
# فقط untracked/ignored محتویات این فهرست پاک می‌شود؛ .git هرگز لمس نمی‌شود.
CLEAN_PATHS=(
  ".github"
  ".gitignore"
  "docs"
  "release-v1.0-overlays"
  "scripts"
  "site"
  "tests"
  "upstream-reference"
  "update-v4.125.0"
  "update-v4.126.0"
  "update-v4.127.0"
  "update-v4.128.0"
  "update-v4.129.0"
  "update-v4.130.0"
  "update-v4.131.0"
  "update-v4.132.0"
  "LIVE-EXAM-DESIGNER-FIX-Site-v4.132.0.zip"
  "LIVE-EXAM-DESIGNER-FIX-Desktop-v2.63.0.zip"
  "LIVE-EXAM-DESIGNER-FIX-SHA256SUMS.txt"
  "MODIFIED-FILES-v4.125.0.zip"
  "MODIFIED-FILES-v4.126.0.zip"
  "MODIFIED-FILES-v4.127.0.zip"
  "MODIFIED-FILES-v4.128.0.zip"
  "MODIFIED-FILES-v4.129.0.zip"
  "MODIFIED-FILES-v4.130.0.zip"
  "MODIFIED-FILES-v4.131.0.zip"
  "MODIFIED-FILES-v4.132.0.zip"
  "Release_v1.0-Desktop.zip"
  "Release_v1.0-MASTER-MEMORY-FA.md"
  "Release_v1.0-SHA256SUMS.txt"
  "Release_v1.0-Site.zip"
  "SchoolDeskPro-v2.62.0-win64.zip"
  "SchoolDeskPro-v2.63.0-win64.zip"
  "desktop-app-v2/server/README-FA.md"
  "desktop-app-v2/server/desk-sync-key.php.example"
)

for path in "${CLEAN_PATHS[@]}"; do
  if [[ -e "$path" || -L "$path" ]]; then
    git clean -fdx -- "$path"
  fi
done

# فایل‌های tracked که در مقصد وجود دارند، برای اطمینان دوباره restore می‌شوند.
git restore --source="$TARGET_COMMIT" --worktree --staged .

echo
echo "بازگردانی کامل شد. مقصد: ${TARGET_COMMIT}"
git status --short
