<?php
// File: reports-lists.php  (v4.152.0)
/**
 * «لیست‌ها و گزارشات» — خانهٔ همهٔ لیست‌های قابل تهیه در مدرسه.
 *
 * این صفحه عمداً به‌شکل «فهرست گزارش‌ها» ساخته شده، نه یک گزارش
 * تک‌منظوره: کارفرما گفت «میخواهم انواع و اقسام لیست‌ها و گزارشات را
 * تهیه کنم»، پس افزودن گزارش بعدی باید یک بلوک تازه در همین صفحه
 * باشد، نه یک فایل جدید.
 *
 * گزارش اول: لیست کلاسی دبیر (خروجی Word، از قالب خام مدرسه).
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/school_sort.php';
require_once __DIR__ . '/includes/school_roles.php';
require_once __DIR__ . '/includes/class_schedule_sync.php';
require_once __DIR__ . '/includes/docx_class_list.php';
require_once __DIR__ . '/includes/docx_school_list.php';
require_once __DIR__ . '/includes/photo_album.php';
require_once __DIR__ . '/includes/school_forms.php';   /* v4.176.0: فرم‌های اداری از قالب‌های .mrt */
require_once __DIR__ . '/includes/academic_year_helpers.php';

/* v4.169.0: معاون اجرایی هم به «لیست‌ها و گزارشات» دسترسی کامل دارد
   (همهٔ بخش‌ها و دانلودها). بقیهٔ نقش‌ها همان مجوز manage_classes مدیر
   را لازم دارند؛ کاربر واردنشده مثل قبل به ورود هدایت می‌شود. */
ensure_school_roles_schema();
if (!current_teacher_is_executive()) require_permission('manage_classes');

$year    = get_setting('current_academic_year', '1404/1405');
$classes = get_unified_class_options($year);

/* ───────── دانلود: یک کلاس یا همهٔ کلاس‌ها ───────── */
$action = $_GET['action'] ?? '';

if ($action === 'school_list_docx') {
    try {
        $layout = $_GET['layout'] ?? 'split';
        $paper = $_GET['paper'] ?? 'A4';
        $doc = srl_generate(srl_collect($year), null, $layout, $paper);
    } catch (RuntimeException $e) {
        set_flash_message('error', $e->getMessage());
        redirect('reports-lists.php?tab=school');
    }
    $modeName = $layout === 'combined' ? 'نام و نام خانوادگی یکجا' : 'نام و نام خانوادگی جدا';
    $fname = 'لیست دانش‌آموزان مدرسه ' . $modeName . ' ' . $paper . ' ' . str_replace('/', '-', srl_year($year)) . '.docx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Disposition: attachment; filename="school-students-' . $layout . '-' . $paper . '.docx"; filename*=UTF-8\'\'' . rawurlencode($fname));
    header('Content-Length: ' . strlen($doc));
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo $doc;
    exit;
}

if ($action === 'class_list_docx') {
    $className = trim($_GET['class'] ?? '');
    if ($className === '') { set_flash_message('error', 'کلاس انتخاب نشده است.'); redirect('reports-lists.php'); }

    $grade = '';
    foreach ($classes as $c) if ($c['class_name'] === $className) { $grade = $c['grade_level']; break; }

    $code  = dcl_class_code($className, $grade);
    $names = dcl_students_of_class($className, $year);
    $doc   = dcl_generate($code, $names);

    if ($doc === null) {
        set_flash_message('error', 'قالب لیست پیدا نشد یا افزونهٔ Zip روی سرور فعال نیست.');
        redirect('reports-lists.php');
    }

    $fname = 'لیست کلاسی ' . $className . '.docx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Disposition: attachment; filename="' . rawurlencode($fname) . '"; filename*=UTF-8\'\'' . rawurlencode($fname));
    header('Content-Length: ' . strlen($doc));
    header('Cache-Control: no-store');
    echo $doc;
    exit;
}

if ($action === 'class_list_pdf') {
    /* v4.146.0 — نمای چاپی برای PDF.
       خروجی HTML است و کاربر با «Save as PDF» مرورگر فایل را
       می‌گیرد؛ این تنها راهی بود که فونت تیتر تضمینی درست دربیاید،
       چون TCPDF در بسته نیست و برای فارسی به فونت تبدیل‌شده نیاز
       دارد. */
    $className = trim($_GET['class'] ?? '');
    if ($className === '') { set_flash_message('error', 'کلاس انتخاب نشده است.'); redirect('reports-lists.php'); }

    $grade = '';
    foreach ($classes as $c) if ($c['class_name'] === $className) { $grade = $c['grade_level']; break; }

    /* v4.148.0 — پیش‌فرض: ویرایشگر/پیش‌نمایش زنده باز می‌شود و چاپ
       خودکار نمی‌آید، تا کاربر اول همه‌چیز را ببیند. با auto=1 مستقیم
       پنجرهٔ چاپ باز می‌شود. */
    $autoPrint = (($_GET['auto'] ?? '0') === '1');

    echo dcl_render_print_html(
        dcl_class_code($className, $grade),
        dcl_students_of_class($className, $year),
        get_setting('school_name', ''),
        $autoPrint
    );
    exit;
}

if ($action === 'photo_album_pdf') {
    /* v4.170.0 — گزارش «آلبوم عکس»: نمای چاپی HTML (مثل class_list_pdf)؛
       عکس‌ها data-URI جاسازی می‌شوند و کاربر با Save as PDF خروجی می‌گیرد. */
    $className = trim($_GET['class'] ?? '');
    if ($className === '') { set_flash_message('error', 'کلاس انتخاب نشده است.'); redirect('reports-lists.php?tab=album'); }

    $grade = '';
    foreach ($classes as $c) if ($c['class_name'] === $className) { $grade = $c['grade_level']; break; }

    $autoPrint = (($_GET['auto'] ?? '0') === '1');
    echo pab_render_print_html(
        $className,
        $grade,
        pab_students_of_class($className, $year),
        get_setting('school_name', ''),
        $autoPrint
    );
    exit;
}

/* ═══ v4.176.0: فرم‌های اداری (بازسازی قالب‌های .mrt مدرسه) ═══
   هر چهار فرم خروجی HTML چاپ‌محور دارند؛ کاربر با Save as PDF فایل می‌گیرد.

   v4.177.0: دو حالت چاپ —
     mode=blank    → «چاپ پایه»: برگهٔ خالی (بدون نام دانش‌آموز)
     mode=students → «چاپ کل دانش‌آموزان»: نام دانش‌آموزان روی برگه
   و دو گستره:
     class=… → یک کلاس   |   grade=… → یک پایه   |   scope=all → کل مدرسه */
if (in_array($action, ['absents_form', 'amanat_form', 'anjoman_letter', 'camp_consent'], true)) {
    $mode    = (trim($_GET['mode'] ?? 'students') === 'blank') ? 'blank' : 'students';
    $scope   = trim($_GET['scope'] ?? '');
    $gradeQ  = trim($_GET['grade'] ?? '');
    $className = trim($_GET['class'] ?? '');
    $ctx = sf_context();
    $autoPrint = (($_GET['auto'] ?? '0') === '1');
    $blank = ($mode === 'blank');

    /* گسترهٔ کل مدرسه یا یک پایه → برای فرم‌های نامه‌ای یک برگه برای هر دانش‌آموز */
    if ($scope === 'all' || $gradeQ !== '') {
        $students = $scope === 'all' ? sf_all_students($year) : sf_students_of_grade($gradeQ, $year);
        if (!$students) {
            set_flash_message('error', 'دانش‌آموز فعالی برای این گستره پیدا نشد.');
            redirect('reports-lists.php?tab=forms');
        }
        if ($action === 'absents_form') {
            /* برگهٔ حضور و غیاب برای هر کلاس یک برگه است */
            $byClass = [];
            foreach ($students as $st) $byClass[(string)$st['class_name']][] = $st;
            $out = '';
            foreach ($byClass as $cn => $list) {
                $g = '';
                foreach ($classes as $c) if ($c['class_name'] === $cn) { $g = $c['grade_level']; break; }
                $out .= sf_render_absents_form($cn, $g, $list, $ctx, $autoPrint, $blank);
            }
            echo $out;
        } elseif ($action === 'amanat_form') {
            echo sf_render_amanat_form($students, $ctx, $autoPrint, $blank, '');
        } elseif ($action === 'anjoman_letter') {
            echo sf_render_anjoman_letter($students, $ctx, $autoPrint, $blank);
        } else {
            echo sf_render_camp_consent($students, $ctx, $autoPrint, $blank);
        }
        exit;
    }

    if ($className === '') { set_flash_message('error', 'کلاس انتخاب نشده است.'); redirect('reports-lists.php?tab=forms'); }
    $grade = '';
    foreach ($classes as $c) if ($c['class_name'] === $className) { $grade = $c['grade_level']; break; }
    $students = sf_students_of_class($className, $year);
    if (!$students && !$blank) { set_flash_message('error', 'برای کلاس ' . $className . ' دانش‌آموز فعالی ثبت نشده است.'); redirect('reports-lists.php?tab=forms'); }
    if ($action === 'absents_form')       echo sf_render_absents_form($className, $grade, $students, $ctx, $autoPrint, $blank);
    elseif ($action === 'amanat_form')    echo sf_render_amanat_form($students, $ctx, $autoPrint, $blank, $className);
    elseif ($action === 'anjoman_letter') echo sf_render_anjoman_letter($students, $ctx, $autoPrint, $blank);
    else                                  echo sf_render_camp_consent($students, $ctx, $autoPrint, $blank);
    exit;
}

if ($action === 'class_list_all') {
    /* همهٔ کلاس‌ها در یک zip — برای وقتی دفتر می‌خواهد یک‌جا چاپ کند. */
    if (!class_exists('ZipArchive')) {
        set_flash_message('error', 'افزونهٔ Zip روی سرور فعال نیست؛ لیست‌ها را تکی دانلود کنید.');
        redirect('reports-lists.php');
    }
    $tmp = tempnam(sys_get_temp_dir(), 'dclzip');
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) {
        set_flash_message('error', 'ساخت فایل فشرده ممکن نشد.');
        redirect('reports-lists.php');
    }
    $added = 0;
    foreach ($classes as $c) {
        $names = dcl_students_of_class($c['class_name'], $year);
        if (!$names) continue;                    /* کلاس بدون دانش‌آموز را نساز */
        $doc = dcl_generate(dcl_class_code($c['class_name'], $c['grade_level']), $names);
        if ($doc === null) continue;
        $zip->addFromString('لیست کلاسی ' . $c['class_name'] . '.docx', $doc);
        $added++;
    }
    $zip->close();

    if ($added === 0) {
        @unlink($tmp);
        set_flash_message('error', 'هیچ کلاسی با دانش‌آموز فعال پیدا نشد.');
        redirect('reports-lists.php');
    }
    $data = @file_get_contents($tmp);
    @unlink($tmp);
    $fname = 'لیست کلاسی همه کلاس‌ها.zip';
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . rawurlencode($fname) . '"; filename*=UTF-8\'\'' . rawurlencode($fname));
    header('Content-Length: ' . strlen($data));
    header('Cache-Control: no-store');
    echo $data;
    exit;
}

/* ───────── شمارش دانش‌آموز هر کلاس، برای نمایش در جدول ───────── */
$counts = [];
foreach ($classes as $c) {
    $counts[$c['class_name']] = count(dcl_students_of_class($c['class_name'], $year));
}

$templateOk = is_file(dcl_template_path());
$zipOk      = class_exists('ZipArchive');

/* v4.176.0: تب «فرم‌های اداری» هم به فهرست تب‌ها اضافه شد. */
$tab = in_array($_GET['tab'] ?? '', ['school', 'album', 'forms'], true) ? $_GET['tab'] : 'teacher';
$photoCounts = [];
if ($tab === 'album') {
    /* فقط در تب آلبوم: شمار عکس‌دارها، با همان کوئری سبک هر کلاس */
    foreach ($classes as $c) {
        $rows = pab_students_of_class($c['class_name'], $year);
        $with = 0;
        foreach ($rows as $r) if (trim((string)($r['photo_url'] ?? '')) !== '') $with++;
        $photoCounts[$c['class_name']] = ['total' => count($rows), 'with' => $with];
    }
}
$schoolData = null; $schoolError = '';
if ($tab === 'school') {
    try { $schoolData = srl_collect($year); }
    catch (RuntimeException $e) { $schoolError = $e->getMessage(); }
}
$schoolReady = is_file(srl_template_path()) && $zipOk && class_exists('DOMDocument');

require_once __DIR__ . '/includes/header.php';
?>
<div class="space-y-6">
    <div class="page-hero flex justify-between items-center no-print">
        <div>
            <h2 class="text-2xl font-bold">لیست‌ها و گزارشات</h2>
            <p class="text-sm text-muted">تهیهٔ لیست‌های اداری و گزارش‌های آماده برای چاپ — سال تحصیلی <?php echo clean(tr_num($year, 'fa')); ?></p>
        </div>
    </div>

    <nav class="flex gap-2 flex-wrap no-print" aria-label="نوع لیست">
        <a href="reports-lists.php?tab=teacher" class="btn <?php echo $tab === 'teacher' ? 'btn-primary' : 'btn-accent'; ?>" <?php if ($tab === 'teacher') echo 'aria-current="page"'; ?>>لیست کلاسی دبیر</a>
        <a href="reports-lists.php?tab=school" class="btn <?php echo $tab === 'school' ? 'btn-primary' : 'btn-accent'; ?>" <?php if ($tab === 'school') echo 'aria-current="page"'; ?>>لیست دانش‌آموزان کل مدرسه</a>
        <a href="reports-lists.php?tab=album" class="btn <?php echo $tab === 'album' ? 'btn-primary' : 'btn-accent'; ?>" <?php if ($tab === 'album') echo 'aria-current="page"'; ?>>آلبوم عکس کلاس‌ها</a>
        <a href="reports-lists.php?tab=forms" class="btn <?php echo $tab === 'forms' ? 'btn-primary' : 'btn-accent'; ?>" <?php if ($tab === 'forms') echo 'aria-current="page"'; ?>>فرم‌های اداری</a>
    </nav>

    <?php if ($tab === 'teacher'): ?>
    <?php if (!$templateOk || !$zipOk): ?>
    <div class="card" style="border-right:4px solid #dc2626">
        <h3 class="font-bold text-sm" style="color:#b91c1c;margin-bottom:6px">پیش‌نیاز فراهم نیست</h3>
        <ul class="text-xs" style="line-height:1.9;margin-right:18px;list-style:disc">
            <?php if (!$templateOk): ?><li>فایل قالب <code>assets/templates/teacher-class-list.docx</code> پیدا نشد. آن را از بستهٔ بروزرسانی کپی کنید.</li><?php endif; ?>
            <?php if (!$zipOk): ?><li>افزونهٔ <code>ZipArchive</code> در PHP فعال نیست. برای ساخت فایل Word لازم است؛ از میزبان بخواهید فعالش کند.</li><?php endif; ?>
        </ul>
    </div>
    <?php endif; ?>

    <!-- ═══ گزارش ۱: لیست کلاسی دبیر ═══ -->
    <div class="card">
        <div class="flex justify-between items-center flex-wrap gap-2" style="margin-bottom:12px">
            <div>
                <h3 class="font-bold text-sm">لیست کلاسی دبیر</h3>
                <p class="text-xs text-muted">
                    دو صفحه در قالب رسمی مدرسه: جدول حضور و غیاب و ارزشیابی (۳۰ ردیف) و جدول ثبت میزان تدریس.
                    اسامی به ترتیب الفبا و با فونت تیتر، در دو ستون «نام خانوادگی» و «نام» درج می‌شوند.
                    خروجی Word برای ویرایش، و خروجی PDF برای چاپ مستقیم.
                </p>
            </div>
            <?php if ($templateOk && $zipOk): ?>
                <a href="reports-lists.php?action=class_list_all" class="btn btn-accent text-xs">دانلود همهٔ کلاس‌ها (ZIP)</a>
            <?php endif; ?>
        </div>

        <?php if (!$classes): ?>
            <div class="text-center text-muted" style="font-size:13px;padding:16px">
                هیچ کلاسی برای سال تحصیلی <?php echo clean(tr_num($year, 'fa')); ?> ثبت نشده است.
            </div>
        <?php else: ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>کلاس</th>
                        <th>پایه</th>
                        <th>کد روی لیست</th>
                        <th>تعداد دانش‌آموز</th>
                        <th>دریافت</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($classes as $c):
                    $cn = $c['class_name'];
                    $n  = (int)($counts[$cn] ?? 0);
                    $code = dcl_class_code($cn, $c['grade_level']);
                ?>
                    <tr>
                        <td class="font-bold"><?php echo clean($cn); ?></td>
                        <td><?php echo clean($c['grade_level'] ?: '—'); ?></td>
                        <td class="font-mono dir-ltr text-left"><?php echo clean($code); ?></td>
                        <td>
                            <?php echo clean(tr_num($n, 'fa')); ?>
                            <?php if ($n > 30): ?>
                                <span class="badge" style="background:#fef3c7;color:#92400e;font-size:.65rem">بیش از ۳۰ نفر</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($n === 0): ?>
                                <span class="text-xs text-muted">دانش‌آموزی ندارد</span>
                            <?php else: ?>
                                <?php if ($templateOk && $zipOk): ?>
                                    <a class="btn btn-primary text-xs" href="reports-lists.php?action=class_list_docx&class=<?php echo urlencode($cn); ?>">Word</a>
                                <?php endif; ?>
                                <?php /* PDF به قالب docx وابسته نیست، پس همیشه در دسترس است */ ?>
                                <a class="btn btn-accent text-xs" target="_blank" rel="noopener"
                                   href="reports-lists.php?action=class_list_pdf&class=<?php echo urlencode($cn); ?>">پیش‌نمایش و PDF</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <p class="text-xs text-muted" style="margin-top:10px">
            جدول لیست ۳۰ ردیف دارد. اگر کلاسی بیش از ۳۰ دانش‌آموز داشته باشد، نام‌های بعدی در فایل جا نمی‌شوند
            و باید برای آن کلاس یک برگهٔ دوم جداگانه چاپ شود.
        </p>
        <?php endif; ?>
    </div>

    <?php elseif ($tab === 'album'): ?>
    <!-- ═══ گزارش ۳: آلبوم عکس کلاس‌ها (v4.170.0) ═══ -->
    <div class="card">
        <div style="margin-bottom:12px">
            <h3 class="font-bold text-sm">آلبوم عکس کلاس‌ها</h3>
            <p class="text-xs text-muted">
                v4.176.0 — آلبوم به شکل <b>لیست</b> (نه شبکه) و <b>هر کلاس روی یک صفحهٔ A4</b>:
                ردیف | عکس | نام و نام خانوادگی | نام پدر | کد ملی | یادداشت.
                ارتفاع ردیف‌ها خودکار با تعداد دانش‌آموز تنظیم می‌شود تا کلاس همیشه در یک برگه جا شود
                (کلاس کم‌جمع‌تر ردیف بلندتر و خوانا، کلاس پُرجمع‌تر ردیف کوتاه‌تر).
            </p>
        </div>

        <?php if (!$classes): ?>
            <div class="text-center text-muted" style="font-size:13px;padding:16px">
                هیچ کلاسی برای سال تحصیلی <?php echo clean(tr_num($year, 'fa')); ?> ثبت نشده است.
            </div>
        <?php else: ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>کلاس</th>
                        <th>پایه</th>
                        <th>تعداد دانش‌آموز</th>
                        <th>عکس‌دار</th>
                        <th>برگه</th>
                        <th>دریافت</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($classes as $c):
                    $cn = $c['class_name'];
                    $pc = $photoCounts[$cn] ?? ['total' => 0, 'with' => 0];
                ?>
                    <tr>
                        <td class="font-bold"><?php echo clean($cn); ?></td>
                        <td><?php echo clean($c['grade_level'] ?: '—'); ?></td>
                        <td><?php echo clean(tr_num($pc['total'], 'fa')); ?></td>
                        <td>
                            <?php echo clean(tr_num($pc['with'], 'fa')); ?>
                            <?php if ($pc['total'] > 0 && $pc['with'] < $pc['total']): ?>
                                <span class="badge" style="background:#fef3c7;color:#92400e;font-size:.65rem">بدون عکس: <?php echo clean(tr_num($pc['total'] - $pc['with'], 'fa')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo clean(tr_num('1', 'fa')); ?><span class="text-muted" style="font-size:.65rem"> (یک برگه برای هر کلاس)</span></td>
                        <td>
                            <?php if ($pc['total'] === 0): ?>
                                <span class="text-xs text-muted">دانش‌آموزی ندارد</span>
                            <?php else: ?>
                                <a class="btn btn-accent text-xs" target="_blank" rel="noopener"
                                   href="reports-lists.php?action=photo_album_pdf&class=<?php echo urlencode($cn); ?>">پیش‌نمایش و PDF</a>
                                <a class="btn btn-outline text-xs" target="_blank" rel="noopener"
                                   href="reports-lists.php?action=photo_album_pdf&class=<?php echo urlencode($cn); ?>&auto=1">چاپ مستقیم</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <p class="text-xs text-muted" style="margin-top:10px">
            هر کلاس روی یک برگه A4 چاپ می‌شود؛ کلاسی که در یک برگه جا نشود (بسیار پُرجمع‌تر از ظرفیت خوانا) با یک هشدار روی برگه مشخص می‌شود. دانش‌آموز بدون عکس هم ردیف دارد و جای عکس خالی می‌ماند تا چاپ دستی کامل باشد.
            در پنجرهٔ چاپ، کاغذ A4 و مقصد «Save as PDF» را انتخاب کنید.
            </p>
        <?php endif; ?>
    </div>

    <?php elseif ($tab === 'forms'): ?>
    <!-- ═══ v4.176.0/v4.177.0: فرم‌های اداری — بازسازی چهار قالب .mrt مدرسه ═══ -->
    <div class="card">
        <div style="margin-bottom:12px">
            <h3 class="font-bold text-sm">فرم‌های اداری مدرسه</h3>
            <p class="text-xs text-muted">
                چهار فرم پرکاربرد، بازسازی‌شده از قالب‌های اصلی مدرسه (پوشهٔ <code>school-reports-raw-files</code>) با دادهٔ
                دانش‌آموزان، کلاس و نام مدرسهٔ خودمان. هر فرم دو حالت دارد:
                <b>«پایه»</b> یعنی برگهٔ خالی برای نوشتن با دست، و
                <b>«کل دانش‌آموزان»</b> یعنی نام دانش‌آموزان روی برگه چاپ می‌شود.
                خروجی HTML چاپ‌محور است؛ با «Save as PDF» به PDF تبدیل می‌شود.
            </p>
        </div>

        <!-- ═══ چاپ دسته‌جمعی: یک پایه یا کل مدرسه ═══ -->
        <?php if ($classes): ?>
        <div style="border:0.3mm solid #cbd5e1;border-radius:2mm;padding:10px;margin-bottom:14px">
            <div class="text-xs font-bold" style="margin-bottom:8px">چاپ دسته‌جمعی</div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                <select id="bulkGrade" class="form-select" style="max-width:180px">
                    <?php foreach (array_unique(array_filter(array_column($classes, 'grade_level'))) as $g): ?>
                        <option value="<?php echo clean($g); ?>">پایهٔ <?php echo clean($g); ?></option>
                    <?php endforeach; ?>
                </select>
                <a class="btn btn-outline text-xs" target="_blank" rel="noopener" id="bulkGradeBtn" href="#">چاپ پایهٔ انتخابی</a>
                <?php foreach ([
                    'absents_form'   => 'حضور و غیاب',
                    'amanat_form'    => 'فرم کتاب',
                    'anjoman_letter' => 'دعوتنامهٔ انجمن',
                    'camp_consent'   => 'رضایت‌نامهٔ اردو',
                ] as $act => $lbl): ?>
                    <a class="btn btn-accent text-xs" target="_blank" rel="noopener"
                       href="reports-lists.php?action=<?php echo $act; ?>&amp;scope=all&amp;mode=students"
                       title="یک برگه برای هر دانش‌آموز مدرسه"><?php echo $lbl; ?> — کل مدرسه</a>
                <?php endforeach; ?>
            </div>
            <div class="text-xs text-muted" style="margin-top:6px;line-height:2">
                «کل مدرسه» برای هر دانش‌آموز یک برگه می‌سازد (دعوتنامه دو تا و رضایت‌نامه چهار تا در هر برگه).
                برای یک پایهٔ مشخص، پایه را انتخاب و دکمهٔ «چاپ پایهٔ انتخابی» را بزنید؛ برگهٔ حضور و غیاب برای
                هر کلاس آن پایه یک برگه است.
            </div>
        </div>
        <?php endif; ?>

        <?php if (!$classes): ?>
            <div class="text-center text-muted" style="font-size:13px;padding:16px">هیچ کلاسی برای سال تحصیلی <?php echo clean(tr_num($year, 'fa')); ?> ثبت نشده است.</div>
        <?php else: ?>
            <div class="table-container">
                <table>
                    <thead><tr><th>کلاس</th><th>پایه</th><th>تعداد دانش‌آموز</th><th>برگهٔ حضور و غیاب</th><th>فرم کتاب</th><th>دعوتنامهٔ انجمن</th><th>رضایت‌نامهٔ اردو</th></tr></thead>
                    <tbody>
                    <?php foreach ($classes as $c):
                        $cn = $c['class_name'];
                        $n = 0;
                        try { $n = (int)(DB::fetch("SELECT COUNT(*) c FROM students s WHERE s.status='active' AND s.class_name = ? AND (s.academic_year = ? OR s.academic_year IS NULL OR s.academic_year = '')", [$cn, $year])['c'] ?? 0); } catch (Throwable $e) { $n = 0; }
                        $link = function ($act) use ($cn) { return 'reports-lists.php?action=' . $act . '&amp;class=' . urlencode($cn); };
                    ?>
                        <tr>
                            <td class="font-bold"><?php echo clean($cn); ?></td>
                            <td><?php echo clean($c['grade_level'] ?: '—'); ?></td>
                            <td><?php echo clean(tr_num($n, 'fa')); ?></td>
                            <?php if ($n === 0): ?>
                                <td colspan="4" class="text-xs text-muted">دانش‌آموزی ندارد</td>
                            <?php else: ?>
                                <td>
                                    <a class="btn btn-outline text-xs" target="_blank" rel="noopener" href="<?php echo $link('absents_form'); ?>&amp;mode=blank" title="برگهٔ خالی برای نوشتن با دست">پایه</a>
                                    <a class="btn btn-accent text-xs" target="_blank" rel="noopener" href="<?php echo $link('absents_form'); ?>&amp;mode=students" title="با نام دانش‌آموزان">کل دانش‌آموزان</a>
                                </td>
                                <td>
                                    <a class="btn btn-outline text-xs" target="_blank" rel="noopener" href="<?php echo $link('amanat_form'); ?>&amp;mode=blank">پایه</a>
                                    <a class="btn btn-accent text-xs" target="_blank" rel="noopener" href="<?php echo $link('amanat_form'); ?>&amp;mode=students">کل دانش‌آموزان</a>
                                </td>
                                <td>
                                    <a class="btn btn-outline text-xs" target="_blank" rel="noopener" href="<?php echo $link('anjoman_letter'); ?>&amp;mode=blank">پایه</a>
                                    <a class="btn btn-accent text-xs" target="_blank" rel="noopener" href="<?php echo $link('anjoman_letter'); ?>&amp;mode=students">کل دانش‌آموزان</a>
                                </td>
                                <td>
                                    <a class="btn btn-outline text-xs" target="_blank" rel="noopener" href="<?php echo $link('camp_consent'); ?>&amp;mode=blank">پایه</a>
                                    <a class="btn btn-accent text-xs" target="_blank" rel="noopener" href="<?php echo $link('camp_consent'); ?>&amp;mode=students">کل دانش‌آموزان</a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <p class="text-xs text-muted" style="margin-top:10px;line-height:2">
                «برگهٔ حضور و غیاب» یک هفته کامل است: شنبه تا پنجشنبه، هر روز سه زنگ. «دعوتنامهٔ انجمن» دو تا و
                «رضایت‌نامهٔ اردو» چهار تا در هر برگه A4 چاپ می‌شود. «فرم کتاب» یک برگهٔ خالی با ستون
                «نام دریافت کننده» است.
            </p>
        <?php endif; ?>
    </div>
    <script>
    /* پایهٔ انتخابی را به لینک چاپ پایه‌ای اضافه می‌کند */
    (function(){
      var sel = document.getElementById('bulkGrade'), btn = document.getElementById('bulkGradeBtn');
      if(!sel || !btn) return;
      var base = 'reports-lists.php?action=absents_form&mode=blank&grade=';
      function sync(){ btn.href = base + encodeURIComponent(sel.value || ''); }
      sel.addEventListener('change', sync); sync();
    })();
    </script>

    <?php else: ?>
    <section class="card" aria-labelledby="school-list-title">
        <h3 id="school-list-title" class="font-bold text-sm">لیست دانش‌آموزان کل مدرسه</h3>
        <p class="text-sm text-muted" style="line-height:2;margin:12px 0">
            خروجی Word تک‌صفحه‌ای، با انتخاب A4 یا A3 افقی: «نام خانوادگی و نام در یک ستون» مطابق قالب منبع، یا «نام خانوادگی و نام در دو ستون جدا».
            سال تحصیلی، کلاس‌ها، جمع هر پایه و جمع کل به‌صورت خودکار درج می‌شوند.
            فهرست شامل دانش‌آموزان فعالِ ثبت‌شده در سال تحصیلی پیش‌فرض است.
        </p>
        <?php if ($schoolError !== ''): ?><p role="alert"><?php echo clean($schoolError); ?></p><?php endif; ?>
        <?php if (!$schoolReady): ?>
            <p role="alert" style="color:#b91c1c">فایل قالب <code>assets/templates/school-students.docx</code> و افزونه‌های Zip و DOM در PHP لازم است. بستهٔ بروزرسانی را کامل نصب کنید.</p>
        <?php endif; ?>
        <?php if ($schoolData): ?>
            <?php if ($schoolData['missing_class']): ?>
                <p role="alert" style="color:#b91c1c;margin:10px 0"><?php echo clean(tr_num($schoolData['missing_class'], 'fa')); ?> دانش‌آموز سال جاری کلاس ندارند؛ ابتدا کلاس آن‌ها را تعیین کنید. برای جلوگیری از حذف اسامی، دانلود تا آن زمان غیرفعال است.</p>
            <?php endif; ?>
            <?php if ($schoolData['unassigned_year']): ?>
                <p style="color:#92400e;margin:10px 0"><?php echo clean(tr_num($schoolData['unassigned_year'], 'fa')); ?> دانش‌آموز فعال سال تحصیلی مشخص ندارند و در این گزارش نیستند. در صورت تعلق به سال جاری، سال آن‌ها را در مدیریت دانش‌آموزان تعیین کنید.</p>
            <?php endif; ?>
            <div class="table-container"><table>
                <thead><tr><th>پایه</th><th>کلاس‌ها</th><th>جمع دانش‌آموزان</th></tr></thead>
                <tbody>
                <?php foreach ($schoolData['groups'] as $g): ?>
                    <tr><td><?php echo clean(tr_num($g['grade'], 'fa')); ?></td>
                        <td><?php foreach ($g['classes'] as $c): ?><bdi dir="ltr" style="display:inline-block;margin:0 6px"><?php echo clean($c['code']); ?></bdi><?php endforeach; ?></td>
                        <td><?php echo clean(tr_num($g['total'], 'fa')); ?></td></tr>
                <?php endforeach; ?>
                </tbody>
                <tfoot><tr><th colspan="2">جمع کل سال تحصیلی <bdi dir="ltr"><?php echo clean(str_replace('/', ' – ', $schoolData['year'])); ?></bdi></th><th><?php echo clean(tr_num($schoolData['total'], 'fa')); ?> نفر</th></tr></tfoot>
            </table></div>
            <?php if ($schoolReady && $schoolData['groups'] && !$schoolData['missing_class']): ?>
                <?php foreach (['A4','A3'] as $paperOption): ?>
                <div style="margin-top:16px">
                    <strong><?= $paperOption ?> افقی — یک صفحه:</strong>
                    <a class="btn btn-primary" href="reports-lists.php?action=school_list_docx&amp;layout=split&amp;paper=<?= $paperOption ?>">Word <?= $paperOption ?> — نام خانوادگی و نام جدا</a>
                    <a class="btn btn-accent" href="reports-lists.php?action=school_list_docx&amp;layout=combined&amp;paper=<?= $paperOption ?>">Word <?= $paperOption ?> — نام خانوادگی و نام یکجا (قالب اصلی)</a>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        <?php endif; ?>
        <p class="text-xs text-muted" style="line-height:2;margin-top:16px">
            کل فهرست روی یک صفحهٔ A4 یا A3 افقی تنظیم می‌شود؛ حاشیهٔ کاغذ و فاصلهٔ داخلی سلول‌ها صفر است. لیست کلاسی دبیر همچنان A4 عمودی است.
            جدول حداقل ۳۰ ردیف اسامی دارد. ردیف‌های بیشتر از ۳۰ و کلاس‌های بیشتر از سه کلاس در هر پایه، در همان جدول اضافه می‌شوند؛ نامی حذف و صفحهٔ ادامه‌ای ساخته نمی‌شود.
            فونت هدف اسامی حداقل ۸ پوینت است؛ با اولویت حفظ یک صفحه، فقط در صورت کمبود فضا کوچک‌تر می‌شود. AutoFit جدول فعال و فاصلهٔ خط همهٔ متن‌ها Single است. برای خوانایی بیشترِ فهرست‌های پُرتعداد A3 را انتخاب کنید.
            فونت اصلی قالب «2 Titr» باید روی دستگاه نصب باشد. حروف کشیده یا فشرده نمی‌شوند. کاغذ چاپگر را با اندازهٔ دانلود هماهنگ کنید؛ چاپ لب‌به‌لب به پشتیبانی چاپگر نیاز دارد.
        </p>
    </section>
    <?php endif; ?>
    <!-- گزارش‌های بعدی به همین فهرست اضافه می‌شوند. -->
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
