<?php
// File: attendance-tags.php  (v4.55.0)
/**
 * Printable QR attendance tags for students — with a LIVE tag designer.
 * v4.54.0: standalone print view (no site header, correct multi-page pagination).
 * v4.55.0: free size + live customization of all tag elements:
 *          size (20-100mm), gap, page margin, cut frame, center school plate
 *          (custom text + scale), optional student name / class / national id.
 * v4.152.0: «تگ آزمایشی» — one printable test sheet with the two simulated
 *          statuses («حضور به موقع» / «تأخیر») that exercises the real scanner
 *          and notification chain without recording any attendance.
 * QR codes are rendered client-side with the bundled qrcode-generator lib.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/attendance_helpers.php';
require_once __DIR__ . '/includes/school_roles.php';
require_once __DIR__ . '/includes/school_sort.php';

$isAdminAtt = is_admin_logged_in() && has_permission('manage_students');
$isDeputyAtt = is_teacher_logged_in() && teacher_has_deputy($_SESSION['teacher_id'] ?? 0);
if (!$isAdminAtt && !$isDeputyAtt) redirect('admin-login.php?tab=teacher');
ensure_attendance_schema_v2();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['regen_tag'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) { set_flash_message('error', 'خطای CSRF'); redirect('attendance-tags.php'); }
    att_regenerate_tag((int)$_POST['student_id']);
    set_flash_message('success', 'تگ جدید برای دانش‌آموز ساخته شد (تگ قبلی باطل شد).');
    redirect('attendance-tags.php?class=' . urlencode($_POST['back_class'] ?? ''));
}

$fClass = trim($_GET['class'] ?? '');
/* v4.135.0: فیلتر پایه و چاپ تکی */
$fGrade = trim($_GET['grade'] ?? '');
$fOne   = (int)($_GET['student_id'] ?? 0);
/* v4.135.0: ترتیب چیدمان تگ‌ها */
$sortKey = $_GET['sort'] ?? 'class';
if (!in_array($sortKey, ['class', 'name', 'first', 'grade', 'nid'], true)) $sortKey = 'class';

// Printing multiplicity only: tokens and student queries stay unique.
$copiesRaw = $_GET['copies'] ?? '1';
$copiesText = is_scalar($copiesRaw) ? trim(tr_num((string)$copiesRaw, 'en')) : '';
$copiesText = strtr($copiesText, ['٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
$copies = preg_match('/^(?:[1-9]|10)$/D', $copiesText) ? (int)$copiesText : 1;

$year = get_setting('current_academic_year', '1404/1405');
$classes = get_unified_class_options($year);
$where = ["s.status='active'"]; $params = [];
// v4.76.0: QR tags are printed ONLY for students of the default academic year
list($tagYearSql, $tagYearParams) = att_year_sql('s');
$where[] = $tagYearSql; foreach ($tagYearParams as $typ) $params[] = $typ;
if ($fClass !== '') { $where[] = 's.class_name=?'; $params[] = $fClass; }
if ($fGrade !== '') { $where[] = 's.grade_level=?'; $params[] = $fGrade; }
if ($fOne > 0)      { $where[] = 's.id=?';          $params[] = $fOne; }
$students = DB::fetchAll("SELECT s.id, s.first_name, s.last_name, s.national_id, s.class_name, s.grade_level FROM students s WHERE " . implode(' AND ', $where), $params);

/* فهرست پایه‌ها برای فیلتر (مستقل از فیلترهای جاری تا همیشه کامل باشد) */
$gradeRows = DB::fetchAll("SELECT DISTINCT s.grade_level FROM students s WHERE s.status='active' AND $tagYearSql AND s.grade_level<>'' ", $tagYearParams);
persian_usort_grades($gradeRows);

/* همهٔ دانش‌آموزان سال جاری — برای لیست «چاپ تکی» */
$allForPick = DB::fetchAll("SELECT s.id, s.first_name, s.last_name, s.class_name FROM students s WHERE s.status='active' AND $tagYearSql", $tagYearParams);
persian_usort_students($allForPick);

/* ---- چیدمان تگ‌ها ----------------------------------------------
   مرتب‌سازی فارسی است (آ قبل از ا) و در همهٔ حالت‌ها، نام خانوادگی
   به‌عنوان معیار دوم می‌آید تا خروجی پایدار و قابل پیش‌بینی بماند. */
switch ($sortKey) {
    case 'name':   /* نام خانوادگی، سپس نام */
        persian_usort_students($students);
        break;
    case 'first':  /* نام، سپس نام خانوادگی */
        usort($students, function ($a, $b) {
            $c = persian_compare($a['first_name'] ?? '', $b['first_name'] ?? '');
            return $c !== 0 ? $c : persian_compare($a['last_name'] ?? '', $b['last_name'] ?? '');
        });
        break;
    case 'grade':  /* پایه، سپس کلاس، سپس نام خانوادگی */
        usort($students, function ($a, $b) {
            $wa = grade_sort_weight($a['grade_level'] ?? ''); $wb = grade_sort_weight($b['grade_level'] ?? '');
            if ($wa !== $wb) return $wa <=> $wb;
            $c = persian_compare($a['class_name'] ?? '', $b['class_name'] ?? '');
            return $c !== 0 ? $c : persian_compare($a['last_name'] ?? '', $b['last_name'] ?? '');
        });
        break;
    case 'nid':    /* کد ملی — برای تطبیق با فهرست‌های اداری */
        usort($students, function ($a, $b) {
            return strcmp((string)($a['national_id'] ?? ''), (string)($b['national_id'] ?? ''));
        });
        break;
    case 'class':
    default:       /* کلاس، سپس نام خانوادگی (پیش‌فرض قبلی) */
        usort($students, function ($a, $b) {
            $c = persian_compare($a['class_name'] ?? '', $b['class_name'] ?? '');
            if ($c !== 0) return $c;
            $c = persian_compare($a['last_name'] ?? '', $b['last_name'] ?? '');
            return $c !== 0 ? $c : persian_compare($a['first_name'] ?? '', $b['first_name'] ?? '');
        });
        break;
}
foreach ($students as &$s) { $tag = att_get_or_create_tag((int)$s['id']); $s['qr'] = att_qr_payload((int)$s['id'], $tag['token']); }
unset($s);
$schoolName = get_setting('school_name', 'آموزشگاه');
$schoolLabel = get_setting('school_name_short', '') !== '' ? get_setting('school_name_short', '') : $schoolName;

/* ============================================================
 * Standalone print view — NO site template at all (v4.54.0),
 * now fully customizable via query params (v4.55.0):
 * attendance-tags.php?print=1&class=...&size=42&gap=4&margin=8
 *   &frame=none|dashed|solid&plate=1&ptext=...&pscale=40
 *   &sname=1&scls=1&snid=1
 * Plain block-flow HTML => all pages paginate naturally.
 * ============================================================ */
if (isset($_GET['print'])) {
    /* v4.152.0: برگهٔ «تگ آزمایشی» — فقط دو تگ «حضور به موقع» و «تأخیر».
       هیچ دانش‌آموزی خوانده نمی‌شود و هیچ توکنی ساخته نمی‌شود؛ دو بارکد
       آزمایشی چاپ می‌شوند تا مسیر اسکن و اطلاع‌رسانی آزموده شود. */
    $testSheet = (($_GET['test'] ?? '') === '1');
    if ($testSheet) $students = att_test_tag_print_rows();
    $D = [
        'size'   => min(100, max(20, (float)($_GET['size'] ?? 40))),
        'gap'    => min(20, max(0, (float)($_GET['gap'] ?? 4))),
        'margin' => min(25, max(0, (float)($_GET['margin'] ?? 8))),
        'frame'  => in_array(($_GET['frame'] ?? 'none'), ['none', 'dashed', 'solid'], true) ? ($_GET['frame'] ?? 'none') : 'none',
        'plate'  => ($_GET['plate'] ?? '1') === '1',
        'ptext'  => trim((string)($_GET['ptext'] ?? '')),
        'pscale' => min(55, max(25, (int)($_GET['pscale'] ?? 40))),
        'sname'  => ($_GET['sname'] ?? '0') === '1',
        'scls'   => ($_GET['scls'] ?? '0') === '1',
        'snid'   => ($_GET['snid'] ?? '0') === '1',
    ];
    if ($D['ptext'] === '') $D['ptext'] = $schoolLabel;
    if ($testSheet) {
        /* نام تگ و توضیح «بدون ثبت حضور و غیاب» باید همیشه روی کاغذ باشد،
           حتی اگر طراح تگ آن خطوط را خاموش کرده باشد. */
        $D['sname'] = true; $D['scls'] = true; $D['snid'] = true;
    }
    $fsName = max(2.4, $D['size'] * 0.085);
    $fsSub  = max(2.1, $D['size'] * 0.068);

    /* ---- v4.135.0: فونت واقعی سامانه در چاپ ----------------------
       تا پیش از این، صفحهٔ چاپ font-family:Tahoma را ثابت داشت. نتیجه:
       پیش‌نمایش با فونت انتخابی مدرسه دیده می‌شد ولی خروجی چاپ با فونت
       سیستم بیرون می‌آمد. حالا همان فونتِ «سفارشی‌سازی» اینجا هم
       @font-face می‌شود.

       نکتهٔ مهم: این صفحه بدون هدر سایت رندر می‌شود، پس هیچ‌کدام از
       @font-face های header.php را ندارد و باید خودش تعریف کند. */
    $printFont = get_setting('font_family', 'Vazirmatn');
    $customFontUrl = get_setting('custom_font_url', '');
    $fontFaces = '';
    $fontStack = "Tahoma, sans-serif";
    $fontDirs = [
        'Vazirmatn' => [['Vazirmatn/Vazirmatn-Regular', 400], ['Vazirmatn/Vazirmatn-Bold', 700]],
        'Sahel'     => [['Sahel/Sahel', 400]],
        'Yekan'     => [['Yekan/Yekan', 400]],
    ];
    if ($printFont === 'CustomUploadedFont' && $customFontUrl !== '') {
        $fontFaces .= "@font-face{font-family:'CustomUploadedFont';src:url('" . clean($customFontUrl) . "');font-display:block}\n";
        $fontStack = "'CustomUploadedFont', Tahoma, sans-serif";
    } elseif (isset($fontDirs[$printFont])) {
        foreach ($fontDirs[$printFont] as $f) {
            list($base, $weight) = $f;
            $srcs = [];
            /* فقط فایل‌هایی که واقعاً روی دیسک هستند اعلام می‌شوند؛
               یک src شکسته، کل @font-face را بی‌اثر می‌کند. */
            if (is_file(__DIR__ . '/uploads/' . $base . '.woff2')) $srcs[] = "url('uploads/{$base}.woff2') format('woff2')";
            if (is_file(__DIR__ . '/uploads/' . $base . '.ttf'))   $srcs[] = "url('uploads/{$base}.ttf') format('truetype')";
            if ($srcs) {
                $fontFaces .= "@font-face{font-family:'{$printFont}';src:" . implode(',', $srcs)
                            . ";font-weight:{$weight};font-display:block}\n";
            }
        }
        if ($fontFaces !== '') $fontStack = "'{$printFont}', Tahoma, sans-serif";
    }
    ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><meta name=viewport content="width=device-width, initial-scale=1">
<meta charset="UTF-8">
<title><?php echo $testSheet ? 'چاپ تگ آزمایشی' : 'چاپ تگ‌های QR'; ?></title>
<style>
<?php echo $fontFaces; ?>
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:#fff;font-family:<?php echo $fontStack; ?>}
/* Block flow + inline-block = reliable multi-page pagination in every browser
   (flex/grid containers are clipped to one page by some engines). */
.sheet{font-size:0;line-height:0}
.tag{width:<?php echo $D['size']; ?>mm;display:inline-block;vertical-align:top;text-align:center;
     margin:0 0 <?php echo $D['gap']; ?>mm <?php echo $D['gap']; ?>mm;
     page-break-inside:avoid;break-inside:avoid;
     <?php if ($D['frame'] !== 'none'): ?>border:0.3mm <?php echo $D['frame']; ?> #94a3b8;padding:1mm;<?php endif; ?>}
.qr-tag{width:100%;display:block}
.t-name{font-family:<?php echo $fontStack; ?>;font-size:<?php echo round($fsName, 2); ?>mm;font-weight:700;color:#000;line-height:1.3}
.t-sub{font-family:<?php echo $fontStack; ?>;font-size:<?php echo round($fsSub, 2); ?>mm;color:#000;line-height:1.3}
.toolbar{position:fixed;top:10px;left:10px;display:flex;gap:8px;font-family:<?php echo $fontStack; ?>;z-index:9}
.toolbar button{padding:8px 18px;border:0;border-radius:8px;background:#2563eb;color:#fff;font-family:inherit;font-size:13px;cursor:pointer}
.toolbar span{background:#f1f5f9;border-radius:8px;padding:8px 14px;font-size:12px;color:#334155}
@media print{ .toolbar{display:none !important} @page{margin:<?php echo $D['margin']; ?>mm} }
</style>
<?php echo app_appearance_head(); ?>
<link rel=stylesheet href=assets/css/school-ui.css?v20260917d><script defer src=assets/js/school-icons.js?v20260917d></script><script defer src=assets/js/school-ui.js?v20260917d></script></head>
<body data-school-return="preview">
<div class="toolbar no-print">
    <button onclick="appPrint()">چاپ</button>
    <span><?php if ($testSheet): ?>برگهٔ آزمایشی (حضور به موقع و تأخیر) — <?php endif; ?>تعداد تگ: <?php echo tr_num(count($students) * $copies, 'fa'); ?> — <?php echo tr_num($copies, 'fa'); ?> نسخه برای هر تگ — اندازه: <?php echo tr_num($D['size'], 'fa'); ?> میلی‌متر</span>
</div>
<div class="sheet">
<?php foreach ($students as $s): for ($copyNo = 0; $copyNo < $copies; $copyNo++): ?>
    <div class="tag">
        <canvas class="qr-tag" data-qr="<?php echo clean($s['qr']); ?>"></canvas>
        <?php if ($D['sname']): ?><div class="t-name"><?php echo clean(trim($s['first_name'] . ' ' . $s['last_name'])); ?></div><?php endif; ?>
        <?php if ($D['scls']): ?><div class="t-sub"><?php echo clean($s['class_name'] ?: '---'); ?></div><?php endif; ?>
        <?php if ($D['snid']): ?><div class="t-sub"><?php echo clean(tr_num($s['national_id'], 'fa')); ?></div><?php endif; ?>
    </div>
<?php endfor; endforeach; ?>
</div>
<script src="assets/js/qrcode-generator.js"></script>
<script>
(function(){
  var PLATE  = <?php echo $D['plate'] ? 'true' : 'false'; ?>;
  var PSCALE = <?php echo $D['pscale']; ?> / 100;
  var LABEL  = <?php echo json_encode($D['ptext'], JSON_UNESCAPED_UNICODE); ?>;
  /* v4.135.0: پلاک وسط QR هم با فونت مدرسه کشیده می‌شود، نه Tahoma ثابت */
  var PFONT  = <?php echo json_encode($fontStack, JSON_UNESCAPED_UNICODE); ?>;
  function draw(cv){
    var qr = qrcode(0, 'H');
    qr.addData(cv.getAttribute('data-qr'));
    qr.make();
    var count = qr.getModuleCount(), quiet = 4, scale = 16;
    var size = (count + quiet * 2) * scale;
    cv.width = size; cv.height = size;
    var ctx = cv.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = '#000';
    for (var r = 0; r < count; r++)
      for (var c = 0; c < count; c++)
        if (qr.isDark(r, c)) ctx.fillRect((c + quiet) * scale, (r + quiet) * scale, scale, scale);
    if (PLATE && LABEL) {
      var label = LABEL.length > 18 ? LABEL.slice(0, 18) : LABEL;
      var boxW = Math.round(size * PSCALE), boxH = Math.round(boxW * 0.325);
      var bx = Math.round((size - boxW) / 2), by = Math.round((size - boxH) / 2);
      var rad = Math.round(boxH * 0.3);
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.moveTo(bx + rad, by);
      ctx.arcTo(bx + boxW, by, bx + boxW, by + boxH, rad);
      ctx.arcTo(bx + boxW, by + boxH, bx, by + boxH, rad);
      ctx.arcTo(bx, by + boxH, bx, by, rad);
      ctx.arcTo(bx, by, bx + boxW, by, rad);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#000'; ctx.lineWidth = Math.max(2, Math.round(scale / 6)); ctx.stroke();
      ctx.fillStyle = '#000'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      var fs = Math.round(boxH * 0.52);
      ctx.font = '700 ' + fs + 'px ' + PFONT;
      while (ctx.measureText(label).width > boxW * 0.88 && fs > 8) { fs--; ctx.font = '700 ' + fs + 'px ' + PFONT; }
      ctx.fillText(label, size / 2, by + boxH / 2 + fs * 0.06);
    }
  }
  function drawAll(){ document.querySelectorAll('canvas.qr-tag[data-qr]').forEach(draw); }

  /* v4.135.0 — چاپ باید تا لود شدن فونت صبر کند.
     canvas متن را در همان لحظهٔ رسم «قفل» می‌کند؛ اگر فونت هنوز نرسیده
     باشد پلاک با فونت جایگزین کشیده می‌شود و دیگر اصلاح نمی‌شود. پیش از
     این فقط ۴۰۰ میلی‌ثانیه صبر می‌کرد که روی سیستم کند کافی نبود.
     document.fonts.ready دقیقاً همین را تضمین می‌کند؛ روی مرورگر قدیمی
     که این API را ندارد، به همان تأخیر ثابت برمی‌گردیم. */
  function whenFontsReady(cb){
    if (document.fonts && document.fonts.ready && typeof document.fonts.ready.then === 'function') {
      var done = false;
      var go = function(){ if (!done) { done = true; cb(); } };
      document.fonts.ready.then(go);
      setTimeout(go, 3000);          /* اگر فونت اصلاً نیامد، گیر نکنیم */
    } else {
      setTimeout(cb, 600);
    }
  }

  var printed = false;
  function printOnce(){
    if (printed) return;        /* هم load و هم complete ممکن است برسند */
    printed = true;
    setTimeout(function(){ appPrint(); }, 250);
  }
  whenFontsReady(function(){
    drawAll();
    if (document.readyState === 'complete') printOnce();
    else window.addEventListener('load', printOnce);
  });
})();
</script>
</body>
</html>
    <?php
    exit;
}

/* ---- v4.152.0: وضعیت آزمون آزمایشی برای همین صفحه ----------------
   پیش از چاپ برگهٔ «تگ آزمایشی» خوب است بدانیم کدام پیام‌رسان حساب
   مدیریت متصل دارد؛ وگرنه تگ چاپ می‌شود ولی پیامی به کسی نمی‌رسد. */
$testMgState = [];
foreach (['bale' => 'بله', 'telegram' => 'تلگرام'] as $pfKey => $pfFa) {
    try {
        $cntMg = count(att_management_chats($pfKey));
        $testMgState[] = $pfFa . ': ' . ($cntMg > 0
            ? (tr_num($cntMg, 'fa') . ' حساب مدیریت متصل')
            : 'بدون حساب مدیریت متصل');
    } catch (Exception $e) { $testMgState[] = $pfFa . ': نامشخص'; }
}
$lastTest = json_decode((string)get_setting('att_test_last_result', ''), true);
$lastTestLine = '';
if (is_array($lastTest)) {
    $testMissing = array_map('strval', (array)($lastTest['missing'] ?? []));
    $testParts = [];
    foreach (['بله' => 'bale', 'تلگرام' => 'telegram'] as $pfFa => $pfKey) {
        $nMg = (int)($lastTest[$pfKey] ?? 0);
        if ($nMg > 0) $testParts[] = $pfFa . ': ' . tr_num($nMg, 'fa') . ' پیام';
        else $testParts[] = $pfFa . ': ' . (in_array($pfKey, $testMissing, true) ? 'بدون حساب مدیریت متصل' : 'ارسال نشد');
    }
    $lastTestLine = 'آخرین آزمون ' . trim((string)($lastTest['at'] ?? '')) . ' — ' . implode(' | ', $testParts);
}

require_once __DIR__ . '/includes/header.php';
?>
<div class="space-y-6">
    <div class="page-hero flex justify-between items-center no-print">
        <div>
            <h2 class="text-2xl font-bold">تگ‌های QR حضور و غیاب</h2>
            <p class="text-sm text-muted">ویرایشگر زنده — اندازه و عناصر تگ را سفارشی کنید، پیش‌نمایش همان لحظه به‌روز می‌شود</p>
        </div>
        <div class="flex gap-2">
            <a href="entry-cards.php" class="btn btn-accent text-xs">کارت ورود دانش‌آموزان</a>
            <a href="attendance.php" class="btn btn-outline text-xs">بازگشت به حضور و غیاب</a>
            <button type="button" onclick="openTestPrint()" class="btn btn-outline text-xs">تگ آزمایشی</button>
            <button type="button" onclick="openPrintView()" class="btn btn-primary text-xs">چاپ تگ‌ها</button>
        </div>
    </div>

    <!-- ======== v4.152.0: برگهٔ «تگ آزمایشی» ======== -->
    <div class="card no-print" id="testTagCard">
        <div class="flex justify-between items-center" style="margin-bottom:10px">
            <h3 class="font-bold text-sm">تگ آزمایشی (بررسی سامانه)</h3>
            <button type="button" class="btn btn-accent text-xs" onclick="openTestPrint()">چاپ برگهٔ آزمایشی</button>
        </div>
        <div class="text-xs text-muted" style="line-height:2">
            با این گزینه یک برگهٔ کوچک با دو تگ «حضور به موقع» و «تأخیر» چاپ می‌شود. با اسکن هر تگ، همان مسیر واقعی اسکنر طی می‌شود
            (خواندن QR → سامانه → اطلاع‌رسانی) و پیام آزمایشی مربوط به همان وضعیت <b>فقط برای حساب مدیریتی</b> فرستاده می‌شود که خودش از طریق ربات
            با نام کاربری و رمز حسابش را به ربات اضافه کرده است — هم در بله و هم در تلگرام. برای هیچ نقش دیگری (دبیر، معاون/ناظم، معاون اجرایی، مشاور) و
            برای هیچ والدی پیام آزمایشی نمی‌رود؛ هیچ حضور یا غیابی هم ثبت نمی‌شود.
        </div>
        <div class="text-xs" style="margin-top:8px">
            حساب مدیریت: <?php echo clean(implode(' | ', $testMgState)); ?>
            <?php if ($lastTestLine !== ''): ?><br><?php echo clean(tr_num($lastTestLine, 'fa')); ?><?php endif; ?>
        </div>
    </div>

    <div class="card no-print">
        <form method="GET" class="grid grid-cols-4 gap-3 items-end">
            <?php /* v4.135.0: فیلتر پایه + ترتیب چیدمان + چاپ تکی */ ?>
            <div>
                <label class="text-xs">پایه</label>
                <select name="grade" class="form-select" data-no-search="1">
                    <option value="">همه پایه‌ها</option>
                    <?php foreach ($gradeRows as $g): ?><option value="<?php echo clean($g['grade_level']); ?>" <?php echo $fGrade === $g['grade_level'] ? 'selected' : ''; ?>><?php echo clean($g['grade_level']); ?></option><?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="text-xs">کلاس</label>
                <select name="class" class="form-select" data-no-search="1">
                    <option value="">همه کلاس‌ها</option>
                    <?php foreach ($classes as $c): ?><option value="<?php echo clean($c['class_name']); ?>" <?php echo $fClass === $c['class_name'] ? 'selected' : ''; ?>><?php echo clean($c['class_name']); ?></option><?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="text-xs">ترتیب چیدمان تگ‌ها</label>
                <select name="sort" class="form-select" data-no-search="1">
                    <option value="class" <?php echo $sortKey === 'class' ? 'selected' : ''; ?>>کلاس، سپس نام خانوادگی</option>
                    <option value="name"  <?php echo $sortKey === 'name'  ? 'selected' : ''; ?>>نام خانوادگی</option>
                    <option value="first" <?php echo $sortKey === 'first' ? 'selected' : ''; ?>>نام</option>
                    <option value="grade" <?php echo $sortKey === 'grade' ? 'selected' : ''; ?>>پایه، سپس کلاس</option>
                    <option value="nid"   <?php echo $sortKey === 'nid'   ? 'selected' : ''; ?>>کد ملی</option>
                </select>
            </div>
            <div>
                <label class="text-xs">فقط یک دانش‌آموز (چاپ تکی)</label>
                <select name="student_id" id="oneStudent" class="form-select">
                    <option value="">— همهٔ دانش‌آموزان فیلتر شده —</option>
                    <?php foreach ($allForPick as $sp): ?><option value="<?php echo (int)$sp['id']; ?>" <?php echo $fOne === (int)$sp['id'] ? 'selected' : ''; ?>><?php echo clean($sp['last_name'] . '، ' . $sp['first_name'] . ' — ' . ($sp['class_name'] ?: '---')); ?></option><?php endforeach; ?>
                </select>
            </div>
            <button class="btn btn-secondary">نمایش</button>
            <?php if ($fClass !== '' || $fGrade !== '' || $fOne > 0 || $sortKey !== 'class'): ?>
                <a href="attendance-tags.php" class="btn btn-outline text-xs">حذف فیلترها</a>
            <?php endif; ?>
            <label class="flex items-center gap-2 text-xs font-semibold" style="padding-bottom:10px">
                <input type="checkbox" id="showIdent" onchange="toggleIdent()">
                نمایش اطلاعات شناسایی و دکمه «تگ جدید» (فقط روی صفحه)
            </label>
            <div class="text-xs text-muted">تعداد: <?php echo tr_num(count($students), 'fa'); ?> دانش‌آموز</div>
        </form>
    </div>

    <!-- ======== v4.55.0: ویرایشگر زنده تگ ======== -->
    <div class="card no-print" id="tagEditor">
        <div class="flex justify-between items-center" style="margin-bottom:12px">
            <h3 class="font-bold text-sm">ویرایشگر زنده تگ</h3>
            <button type="button" class="btn btn-outline text-xs" onclick="resetDesign()">بازنشانی به پیش‌فرض</button>
        </div>
        <div class="grid grid-cols-4 gap-4">
            <div>
                <label class="text-xs" for="dCopies">تعداد نسخه برای هر دانش‌آموز</label>
                <select id="dCopies" class="form-select" data-no-search="1" onchange="applyDesign()">
                    <?php for ($copyOption = 1; $copyOption <= 10; $copyOption++): ?>
                    <option value="<?php echo $copyOption; ?>" <?php echo $copies === $copyOption ? 'selected' : ''; ?>><?php echo tr_num($copyOption, 'fa'); ?></option>
                    <?php endfor; ?>
                </select>
                <div class="text-xs text-muted">نسخه‌های هر دانش‌آموز پشت سر هم چاپ می‌شوند.</div>
            </div>

            <div>
                <label class="text-xs">اندازه تگ: <b><span id="vSize">۴۰</span> میلی‌متر</b></label>
                <input type="range" id="dSize" min="20" max="100" step="1" value="40" style="width:100%" oninput="applyDesign()">
            </div>
            <div>
                <label class="text-xs">فاصله بین تگ‌ها: <b><span id="vGap">۴</span> میلی‌متر</b></label>
                <input type="range" id="dGap" min="0" max="20" step="1" value="4" style="width:100%" oninput="applyDesign()">
            </div>
            <div>
                <label class="text-xs">حاشیه صفحه چاپ: <b><span id="vMargin">۸</span> میلی‌متر</b></label>
                <input type="range" id="dMargin" min="0" max="25" step="1" value="8" style="width:100%" oninput="applyDesign()">
            </div>
            <div>
                <label class="text-xs">کادر دور تگ (راهنمای برش)</label>
                <select id="dFrame" class="form-select" onchange="applyDesign()">
                    <option value="none">بدون کادر</option>
                    <option value="dashed">خط‌چین</option>
                    <option value="solid">خط ممتد</option>
                </select>
            </div>
            <label class="flex items-center gap-2 text-xs font-semibold">
                <input type="checkbox" id="dPlate" checked onchange="applyDesign()">
                پلاک نام مدرسه در مرکز QR
            </label>
            <div>
                <label class="text-xs">متن پلاک (خالی = نام مدرسه)</label>
                <input type="text" id="dPtext" class="form-input" maxlength="18" placeholder="<?php echo clean(mb_substr($schoolLabel, 0, 18)); ?>" oninput="applyDesign()">
            </div>
            <div>
                <label class="text-xs">اندازه پلاک: <b><span id="vPscale">۴۰</span>٪</b></label>
                <input type="range" id="dPscale" min="25" max="55" step="1" value="40" style="width:100%" oninput="applyDesign()">
            </div>
            <div class="text-xs text-muted" style="align-self:center">پلاک تا ۵۵٪ هم امن است (تصحیح خطای H)</div>
            <label class="flex items-center gap-2 text-xs font-semibold">
                <input type="checkbox" id="dName" onchange="applyDesign()">
                نام دانش‌آموز زیر QR
            </label>
            <label class="flex items-center gap-2 text-xs font-semibold">
                <input type="checkbox" id="dCls" onchange="applyDesign()">
                نام کلاس زیر QR
            </label>
            <label class="flex items-center gap-2 text-xs font-semibold">
                <input type="checkbox" id="dNid" onchange="applyDesign()">
                کد ملی زیر QR
            </label>
            <div class="text-xs text-muted" style="align-self:center">تنظیمات به‌طور خودکار ذخیره می‌شود</div>
        </div>
    </div>

    <p id="copiesNote" class="text-xs text-muted no-print"></p>
    <div class="qr-grid" id="qrGrid">
        <?php foreach ($students as $s): ?>
        <div class="qr-item">
            <div class="tag">
                <canvas class="qr-tag" data-qr="<?php echo clean($s['qr']); ?>"></canvas>
                <div class="t-name"><?php echo clean($s['first_name'] . ' ' . $s['last_name']); ?></div>
                <div class="t-cls t-sub"><?php echo clean($s['class_name'] ?: '---'); ?></div>
                <div class="t-nid t-sub"><?php echo clean(tr_num($s['national_id'], 'fa')); ?></div>
            </div>
            <div class="qr-ident no-print" style="display:none">
                <b><?php echo clean($s['first_name'] . ' ' . $s['last_name']); ?></b>
                <span><?php echo clean($s['class_name'] ?: '---'); ?></span>
                <form method="POST" onsubmit="return confirm('تگ فعلی باطل و تگ جدید ساخته شود؟ (تگ چاپ‌شده قبلی دیگر کار نمی‌کند)')">
                    <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                    <input type="hidden" name="regen_tag" value="1">
                    <input type="hidden" name="student_id" value="<?php echo (int)$s['id']; ?>">
                    <input type="hidden" name="back_class" value="<?php echo clean($fClass); ?>">
                    <button class="btn btn-outline text-xs">تگ جدید</button>
                </form>
                <?php /* v4.135.0: چاپ تکی مستقیم از روی همین کارت */ ?>
                <button type="button" class="btn btn-accent text-xs"
                        onclick="printOne(<?php echo (int)$s['id']; ?>)">چاپ این تگ</button>
            </div>
        </div>
        <?php endforeach; if (!$students): ?>
        <div class="card text-center text-muted">دانش‌آموزی یافت نشد.</div>
        <?php endif; ?>
    </div>
</div>

<style>
:root{--tagmm:40mm;--gapmm:4mm}
/* پیش‌نمایش زنده: تگ‌ها روی صفحه با ابعاد واقعی میلی‌متری نمایش داده می‌شوند */
.qr-grid{display:flex;flex-wrap:wrap;gap:var(--gapmm);align-items:flex-start}
.qr-item{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:8px;text-align:center;page-break-inside:avoid;break-inside:avoid}
.tag{width:var(--tagmm);display:inline-block;vertical-align:top;text-align:center;margin:0 auto}
#qrGrid.f-dashed .tag{border:0.3mm dashed #94a3b8;padding:1mm}
#qrGrid.f-solid .tag{border:0.3mm solid #94a3b8;padding:1mm}
.qr-tag{width:100%;display:block}
.t-name{display:none;font-weight:700;color:#000;line-height:1.3;font-size:max(9px, calc(var(--tagmm) * 0.085))}
.t-sub{display:none;color:#000;line-height:1.3;font-size:max(8px, calc(var(--tagmm) * 0.068))}
#qrGrid.show-name .t-name{display:block}
#qrGrid.show-cls .t-cls{display:block}
#qrGrid.show-nid .t-nid{display:block}
.qr-ident{margin-top:6px;font-size:.68rem;color:#64748b;flex-direction:column;gap:4px;align-items:center}
.qr-ident b{color:#0f172a;font-size:.74rem}
@media print{
  /* v4.54.0: fallback if someone presses Ctrl+P on the admin view —
     hide the site chrome AND unlock the template's flex/overflow chain
     so every page paginates (the layout normally clips to one page). */
  .no-print,.sidebar,.navbar,header,nav,.page-hero,footer,.card,.qr-ident{display:none !important}
  body,html{background:#fff !important;margin:0 !important;padding:0 !important;height:auto !important;min-height:0 !important;overflow:visible !important}
  body{display:block !important}
  body > .flex{display:block !important;height:auto !important;overflow:visible !important}
  main.flex-1{display:block !important;height:auto !important;max-height:none !important;overflow:visible !important;padding:0 !important;flex:none !important;width:auto !important}
  .space-y-6{display:block !important}
  .space-y-6>*+*{margin:0 !important}
  .qr-grid{display:block !important;font-size:0;line-height:0}
  .qr-item{display:inline-block !important;border:0 !important;padding:0 !important;background:none !important;border-radius:0 !important;box-shadow:none !important;margin:0 0 var(--gapmm) var(--gapmm) !important}
  @page{margin:8mm}
}
</style>
<script src="assets/js/qrcode-generator.js"></script>
<script>
var SCHOOL = <?php echo json_encode(mb_substr($schoolLabel, 0, 18), JSON_UNESCAPED_UNICODE); ?>;
var LS_KEY = 'mtag_tag_design_v1';
/* v4.135.0: فونت انتخابی مدرسه، برای هماهنگی پیش‌نمایش با چاپ نهایی */
var PREVIEW_FONT = <?php echo json_encode("'" . get_setting('font_family','Vazirmatn') . "', Tahoma, sans-serif", JSON_UNESCAPED_UNICODE); ?>;
var QRCACHE = {};
var _redrawT = null;

function $id(i){ return document.getElementById(i); }
function faNum(n){ return String(n).replace(/[0-9]/g, function(d){ return '۰۱۲۳۴۵۶۷۸۹'[+d]; }); }

function printCopies(value){
  if (typeof value !== 'string' && typeof value !== 'number') return 1;
  var text = String(value).replace(/[۰-۹]/g,function(d){return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d);})
      .replace(/[٠-٩]/g,function(d){return '٠١٢٣٤٥٦٧٨٩'.indexOf(d);}).replace(/^\s+|\s+$/g,'');
  return /^(?:[1-9]|10)$/.test(text) ? Number(text) : 1;
}

function getDesign(){
  return {
    copies: printCopies($id('dCopies').value),
    size:   parseInt($id('dSize').value, 10),
    gap:    parseInt($id('dGap').value, 10),
    margin: parseInt($id('dMargin').value, 10),
    frame:  $id('dFrame').value,
    plate:  $id('dPlate').checked,
    ptext:  $id('dPtext').value.trim(),
    pscale: parseInt($id('dPscale').value, 10),
    sname:  $id('dName').checked,
    scls:   $id('dCls').checked,
    snid:   $id('dNid').checked
  };
}

function setDesign(d){
  $id('dCopies').value = printCopies(d.copies);
  $id('dSize').value = d.size; $id('dGap').value = d.gap; $id('dMargin').value = d.margin;
  $id('dFrame').value = d.frame; $id('dPlate').checked = !!d.plate;
  $id('dPtext').value = d.ptext || ''; $id('dPscale').value = d.pscale;
  $id('dName').checked = !!d.sname; $id('dCls').checked = !!d.scls; $id('dNid').checked = !!d.snid;
}

function applyDesign(){
  var d = getDesign();
  $id('copiesNote').textContent = 'فهرست زیر هر دانش‌آموز را یک بار نشان می‌دهد؛ در چاپ، برای هر نفر ' + faNum(d.copies) + ' نسخه متوالی، در مجموع ' + faNum(<?php echo (int)count($students); ?> * d.copies) + ' تگ قرار می‌گیرد.';
  document.documentElement.style.setProperty('--tagmm', d.size + 'mm');
  document.documentElement.style.setProperty('--gapmm', d.gap + 'mm');
  var g = $id('qrGrid');
  g.classList.toggle('show-name', d.sname);
  g.classList.toggle('show-cls', d.scls);
  g.classList.toggle('show-nid', d.snid);
  g.classList.toggle('f-dashed', d.frame === 'dashed');
  g.classList.toggle('f-solid', d.frame === 'solid');
  $id('vSize').textContent = faNum(d.size);
  $id('vGap').textContent = faNum(d.gap);
  $id('vMargin').textContent = faNum(d.margin);
  $id('vPscale').textContent = faNum(d.pscale);
  try { localStorage.setItem(LS_KEY, JSON.stringify(d)); } catch(e) {}
  /* بازترسیم QRها (پلاک) با تاخیر کوتاه تا اسلایدر روان بماند */
  clearTimeout(_redrawT);
  _redrawT = setTimeout(renderAll, 120);
}

function resetDesign(){
  setDesign({copies:1, size:40, gap:4, margin:8, frame:'none', plate:true, ptext:'', pscale:40, sname:false, scls:false, snid:false});
  applyDesign();
}

function renderAll(){
  var d = getDesign();
  var label = d.ptext !== '' ? d.ptext : SCHOOL;
  document.querySelectorAll('canvas.qr-tag[data-qr]').forEach(function(cv){
    drawTag(cv, d.plate, d.pscale / 100, label);
  });
}

function drawTag(cv, plate, pscale, label){
  try {
    var payload = cv.getAttribute('data-qr');
    var qr = QRCACHE[payload];
    if (!qr) {
      /* سطح تصحیح خطای H: تا ۳۰٪ آسیب قابل بازیابی است */
      qr = qrcode(0, 'H');
      qr.addData(payload);
      qr.make();
      QRCACHE[payload] = qr;
    }
    var count = qr.getModuleCount(), quiet = 4, scale = 16;
    var size = (count + quiet * 2) * scale;
    cv.width = size; cv.height = size;
    var ctx = cv.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = '#000';
    for (var r = 0; r < count; r++)
      for (var c = 0; c < count; c++)
        if (qr.isDark(r, c)) ctx.fillRect((c + quiet) * scale, (r + quiet) * scale, scale, scale);
    if (plate && label) {
      var lb = label.length > 18 ? label.slice(0, 18) : label;
      var boxW = Math.round(size * pscale), boxH = Math.round(boxW * 0.325);
      var bx = Math.round((size - boxW) / 2), by = Math.round((size - boxH) / 2);
      var rad = Math.round(boxH * 0.3);
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.moveTo(bx + rad, by);
      ctx.arcTo(bx + boxW, by, bx + boxW, by + boxH, rad);
      ctx.arcTo(bx + boxW, by + boxH, bx, by + boxH, rad);
      ctx.arcTo(bx, by + boxH, bx, by, rad);
      ctx.arcTo(bx, by, bx + boxW, by, rad);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#000'; ctx.lineWidth = Math.max(2, Math.round(scale / 6)); ctx.stroke();
      ctx.fillStyle = '#000'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      var fs = Math.round(boxH * 0.52);
      /* v4.135.0: پیش‌نمایش هم همان فونت سامانه را می‌کشد، وگرنه آنچه
         روی صفحه می‌بینید با خروجی چاپ فرق می‌کرد. */
      ctx.font = '700 ' + fs + 'px ' + PREVIEW_FONT;
      while (ctx.measureText(lb).width > boxW * 0.88 && fs > 8) { fs--; ctx.font = '700 ' + fs + 'px ' + PREVIEW_FONT; }
      ctx.fillText(lb, size / 2, by + boxH / 2 + fs * 0.06);
    }
  } catch(e) {
    var dv = document.createElement('div'); dv.textContent = 'خطا در ساخت QR'; cv.replaceWith(dv);
  }
}

/* چاپ در نمای مستقل — بدون هدر سایت و بدون محدودیت یک‌صفحه‌ای قالب (v4.54.0)
   همه تنظیمات ویرایشگر عیناً به نمای چاپ منتقل می‌شود (v4.55.0) */
/* v4.135.0: چاپ فقط همین دانش‌آموز — طراحی فعلی حفظ می‌شود */
function printOne(id){ openPrintView(id); }

/* v4.152.0: برگهٔ آزمایشی — دو تگ «حضور به موقع» و «تأخیر» با همان طراحی فعلی */
function openTestPrint(){ openPrintView(null, true); }

function openPrintView(oneId, testTag){
  var d = getDesign();
  var params = new URLSearchParams(window.location.search);
  params.set('print', '1');
  params.set('copies', d.copies);
  if (oneId) params.set('student_id', String(oneId));
  if (testTag) params.set('test', '1');
  params.set('size', d.size); params.set('gap', d.gap); params.set('margin', d.margin);
  params.set('frame', d.frame); params.set('plate', d.plate ? '1' : '0');
  params.set('ptext', d.ptext); params.set('pscale', d.pscale);
  params.set('sname', d.sname ? '1' : '0'); params.set('scls', d.scls ? '1' : '0'); params.set('snid', d.snid ? '1' : '0');
  window.open('attendance-tags.php?' + params.toString(), '_blank');
}

function toggleIdent(){
  var on = document.getElementById('showIdent').checked;
  document.querySelectorAll('.qr-ident').forEach(function(el){
    el.style.display = on ? 'flex' : 'none';
  });
}

document.addEventListener('DOMContentLoaded', function(){
  try {
    var saved = localStorage.getItem(LS_KEY);
    if (saved) setDesign(JSON.parse(saved));
  } catch(e) {}
  <?php if (isset($_GET['copies'])): ?>$id('dCopies').value = <?php echo $copies; ?>;<?php endif; ?>
  applyDesign();
  renderAll();
});
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
