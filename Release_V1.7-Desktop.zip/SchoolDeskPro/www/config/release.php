<?php
return ['release'=>'Release_V1.7','distribution'=>'desktop','site_version'=>'4.214.2','desktop_version'=>'2.138.2'];
