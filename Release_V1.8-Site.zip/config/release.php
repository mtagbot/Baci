<?php
return ['release'=>'Release_V1.8','distribution'=>'site','site_version'=>'4.214.3','desktop_version'=>'2.138.3'];
